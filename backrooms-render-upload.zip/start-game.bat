@echo off
setlocal
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo ERROR: Node.js was not found. Please install Node.js first.
  pause
  exit /b 1
)

echo.
echo Starting Backrooms server...
echo Local: http://localhost:3000
echo LAN: use the IPv4 address printed below with port 3000.
echo If Windows Firewall asks, allow Node.js on private networks.
echo Press Ctrl+C to stop the server.
echo.

node server.js
pause