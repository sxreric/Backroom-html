# 新层级视觉资料与图片署名

本项目的关卡是根据 [The Backrooms Wiki](https://backrooms-wiki.wikidot.com/normal-levels-i) 的英文页面制作的可玩改编，不是页面场景的逐像素/1:1 复刻，也不存在跨所有后室社群通用的唯一官方地图。Level 24–53 的编号、标题和主要环境特征参考对应页面：`https://backrooms-wiki.wikidot.com/level-<编号>`。部分页面在重写或列为过时版本，游戏中的顺序出口为可玩性添加，不应视为原文的官方通路。

游戏内实景参考画面：

| 游戏文件 | 原图作者及许可 | 来源及改动 |
| --- | --- | --- |
| `assets/tex/l24_lunar_reference.jpg` | NASA Johnson Space Center，公有领域 | [NASA 月面照片](https://commons.wikimedia.org/wiki/File:View_form_Lunar_Module_of_surface_of_the_moon_near_where_LM_touched_down_(as11-37-5458).jpg)，见 [Level 24 页面图片署名](https://backrooms-wiki.wikidot.com/level-24)；缩放及黑边排版 |
| `assets/tex/l24_regolith.jpg` | NASA Johnson Space Center，公有领域 | 同一月面照片；裁切为地表材质并缩小 |
| `assets/tex/l31_rink_reference.jpg` | brian，CC BY 2.0；Wiki 版本经 CutTheBirch 编辑 | [Level 31 页面](https://backrooms-wiki.wikidot.com/level-31) 中的 level31.jpg，原图见[作者作品](https://www.flickr.com/photos/brian-m/388191898/in/photostream/)；缩放及黑边排版 |
| `assets/tex/l33_mall_reference.jpg` | Monika，CC BY-SA 2.0 | [Level 33 页面](https://backrooms-wiki.wikidot.com/level-33) 中的 level33good.jpg，原图见[作者作品](https://www.flickr.com/photos/17989497@N00/10357087914/)；缩放及黑边排版，按 [CC BY-SA 2.0](https://creativecommons.org/licenses/by-sa/2.0/) 分享 |
| `assets/tex/l37_pool_reference.jpg` | u/AnarkyMusic，CC BY-SA 4.0 | [Level 37 页面](https://backrooms-wiki.wikidot.com/level-37) 的 Poolrooms-1.jpg；缩放及黑边排版。改编文件按 [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/) 分享 |
| `assets/tex/l52_cavern_reference.jpg` | CamaradeAlbabar，CC BY-SA 4.0；衍生自 Teame01 的 Cavern's Edge（CC BY-SA 4.0）及 Nicolas Guérin 的史前人类复原图（CC BY-SA 3.0） | [Level 52 页面](https://backrooms-wiki.wikidot.com/level-52) 的 fifty-two.jpg；缩放及黑边排版，按 [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/) 分享 |
| `assets/tex/l53_home_reference.jpg` | Rubbermaid Products，CC BY 2.0 | [Level 53 页面](https://backrooms-wiki.wikidot.com/level-53) 的厨房照片，原图见[作者作品](https://www.flickr.com/photos/rubbermaid/4341146900)；缩放及黑边排版，按 [CC BY 2.0](https://creativecommons.org/licenses/by/2.0/) 署名 |

其余墙面、地板、物件和照明使用项目原有材质及代码绘制的 3D 几何；它们是受页面环境描述启发的游戏美术，不是从 Wiki 截图直接复制的照片。玩家看见的实际占地实物（例如车、树、柜、售货机、柱子）有相应碰撞；水、光、薄贴花、出口门不设置实体阻挡。
