@echo off
setlocal
cd /d "%~dp0"

echo Checking JavaScript and building the current version...
node --check js\levels\_later.js
if errorlevel 1 goto :failed

node --check js\levels\_later2.js
if errorlevel 1 goto :failed

node --check js\levels\Lrun.js
if errorlevel 1 goto :failed

node scripts\build-dist.mjs
if errorlevel 1 goto :failed

echo Creating backrooms-render-upload.zip...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\package-render-upload.ps1"
if errorlevel 1 goto :failed

echo.
echo Upload ZIP is ready:
echo %~dp0backrooms-render-upload.zip
pause
exit /b 0

:failed
echo.
echo ERROR: Build or packaging failed. The previous ZIP was not replaced.
pause
exit /b 1
