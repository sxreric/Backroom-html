'use strict';

const http = require('node:http');
const fs = require('node:fs');
const fsp = require('node:fs/promises');
const path = require('node:path');
const os = require('node:os');
const crypto = require('node:crypto');
const { WebSocketServer, WebSocket } = require('ws');

const ROOT = __dirname;
const DIST = path.join(ROOT, 'dist');
const STATIC_ROOT = fs.existsSync(path.join(DIST, 'index.html')) ? DIST : ROOT;
const PORT = Number(process.env.PORT) || 3000;
const ROOM_TTL_MS = 2 * 60 * 60 * 1000;
const MAX_MESSAGES = 512;
const MAX_PLAYERS = 5;
const MAX_BODY_BYTES = 1024 * 1024;

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.gif': 'image/gif',
  '.wav': 'audio/wav',
  '.mp3': 'audio/mpeg',
  '.ogg': 'audio/ogg',
  '.mp4': 'video/mp4',
  '.webm': 'video/webm',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
};

const rooms = new Map();

function cleanName(name) {
  const s = String(name == null ? '' : name).trim().slice(0, 16);
  return s || '匿名流浪者';
}

function normalizeCode(value) {
  return String(value == null ? '' : value).toUpperCase().replace(/[^A-Z0-9]/g, '');
}

function memberId() {
  return crypto.randomBytes(10).toString('hex').slice(0, 16);
}

function messageId() {
  return String(Date.now()).padStart(13, '0') + '-' + crypto.randomBytes(8).toString('hex');
}

function newCode() {
  let code = '';
  do {
    code = crypto.randomBytes(4).toString('hex').slice(0, 6).toUpperCase();
  } while (rooms.has(code));
  return code;
}

function publicMembers(room) {
  return room.members.map(m => ({ id: m.id, role: m.role, name: m.name }));
}

function json(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
  });
  res.end(body);
}

function ok(res, data) {
  json(res, 200, Object.assign({ ok: true }, data || {}));
}

function fail(res, status, error) {
  json(res, status, { ok: false, error });
}

function isExpired(room) {
  return !room || room.closed || Date.now() - room.updatedAt > ROOM_TTL_MS;
}

function getRoom(code) {
  const room = rooms.get(code);
  if (isExpired(room)) {
    if (room) closeRoomSockets(room, 1001, 'room_expired');
    rooms.delete(code);
    return null;
  }
  return room;
}

function touch(room) {
  room.updatedAt = Date.now();
}

function allSockets(room) {
  const list = [];
  for (const set of room.sockets.values()) {
    for (const ws of set) list.push(ws);
  }
  return list;
}

function sendSocket(ws, packet) {
  try {
    if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(packet));
  } catch (_) {}
}

function broadcastMembers(room) {
  const packet = { t: 'members', members: publicMembers(room) };
  for (const ws of allSockets(room)) sendSocket(ws, packet);
}

function broadcastRelay(room, from, payload) {
  const packet = { t: 'relay', from: String(from || ''), m: payload };
  for (const ws of allSockets(room)) {
    if (String(ws._memberId) === String(from)) continue;
    sendSocket(ws, packet);
  }
}

function closeRoomSockets(room, code, reason) {
  for (const ws of allSockets(room)) {
    try { ws.close(code || 1000, reason || 'room_closed'); } catch (_) {}
  }
  room.sockets.clear();
}

function addSocket(room, member, ws) {
  ws._roomCode = room.code;
  ws._memberId = member.id;
  ws.isAlive = true;
  let set = room.sockets.get(member.id);
  if (!set) room.sockets.set(member.id, set = new Set());
  set.add(ws);
  ws.on('pong', () => { ws.isAlive = true; });
  ws.on('message', data => {
    let packet;
    try {
      packet = JSON.parse(Buffer.isBuffer(data) ? data.toString('utf8') : String(data));
    } catch (_) {
      return;
    }
    const payload = packet && packet.t === 'relay' && packet.m && typeof packet.m === 'object'
      ? packet.m
      : packet;
    if (!payload || typeof payload !== 'object') return;
    const current = getRoom(room.code);
    if (!current || !current.members.some(m => m.id === member.id)) {
      try { ws.close(1008, 'not_in_room'); } catch (_) {}
      return;
    }
    touch(current);
    broadcastRelay(current, member.id, payload);
  });
  ws.on('close', () => {
    const current = rooms.get(room.code);
    const currentSet = current && current.sockets.get(member.id);
    if (currentSet) {
      currentSet.delete(ws);
      if (!currentSet.size) current.sockets.delete(member.id);
    }
  });
  ws.on('error', () => {});
}

async function readJson(req) {
  let raw = '';
  for await (const chunk of req) {
    raw += chunk;
    if (Buffer.byteLength(raw, 'utf8') > MAX_BODY_BYTES) throw new Error('body_too_large');
  }
  if (!raw) return {};
  return JSON.parse(raw);
}

function roomOrFail(res, code) {
  if (!code || code.length !== 6) {
    fail(res, 400, 'bad_code');
    return null;
  }
  const room = getRoom(code);
  if (!room) {
    fail(res, 404, 'room_not_found');
    return null;
  }
  return room;
}

async function roomApi(req, res, url) {
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': 'Content-Type',
      'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
    });
    res.end();
    return;
  }

  const action = url.searchParams.get('action') || '';
  const code = normalizeCode(url.searchParams.get('code'));

  try {
    if (action === 'create') {
      let body = {};
      try { body = await readJson(req); }
      catch (err) {
        fail(res, 400, err.message === 'body_too_large' ? 'body_too_large' : 'bad_json');
        return;
      }
      const host = {
        id: memberId(),
        role: 'host',
        name: cleanName(body.name),
        joinedAt: Date.now(),
      };
      const room = {
        code: newCode(),
        hostId: host.id,
        hostName: host.name,
        members: [host],
        messages: [],
        sockets: new Map(),
        updatedAt: Date.now(),
        closed: false,
      };
      rooms.set(room.code, room);
      ok(res, {
        code: room.code,
        id: host.id,
        role: 'host',
        members: publicMembers(room),
        cursor: String(Date.now()),
      });
      return;
    }

    if (action === 'ws') {
      fail(res, 426, 'websocket_required');
      return;
    }

    const room = roomOrFail(res, code);
    if (!room) return;

    if (action === 'status') {
      const firstGuest = room.members.find(m => m.role === 'guest');
      touch(room);
      ok(res, {
        state: room.members.length > 1 ? 'joined' : 'waiting',
        host_name: room.hostName,
        guest_name: firstGuest ? firstGuest.name : '',
        members: publicMembers(room),
        count: room.members.length,
        max: MAX_PLAYERS,
        full: room.members.length >= MAX_PLAYERS,
      });
      return;
    }

    if (action === 'join') {
      let body = {};
      try { body = await readJson(req); }
      catch (err) {
        fail(res, 400, err.message === 'body_too_large' ? 'body_too_large' : 'bad_json');
        return;
      }
      if (room.members.length >= MAX_PLAYERS) {
        fail(res, 409, 'room_full');
        return;
      }
      const guest = {
        id: memberId(),
        role: 'guest',
        name: cleanName(body.name),
        joinedAt: Date.now(),
      };
      room.members.push(guest);
      touch(room);
      broadcastMembers(room);
      ok(res, {
        host: room.hostName,
        id: guest.id,
        role: 'guest',
        members: publicMembers(room),
        cursor: String(Date.now()),
      });
      return;
    }

    if (action === 'close') {
      let body = {};
      try { body = await readJson(req); } catch (_) {}
      const id = String(body.id || '');
      const index = room.members.findIndex(m => m.id === id);
      if (index < 0) {
        ok(res);
        return;
      }
      const left = room.members[index];
      if (left.role === 'host') {
        broadcastRelay(room, id, { t: 'peerLeft', id, name: left.name });
        closeRoomSockets(room, 1000, 'room_closed');
        rooms.delete(room.code);
        ok(res);
        return;
      }
      room.members.splice(index, 1);
      broadcastRelay(room, id, { t: 'peerLeft', id, name: left.name });
      room.sockets.delete(id);
      touch(room);
      broadcastMembers(room);
      ok(res);
      return;
    }

    if (action === 'poll') {
      const me = String(url.searchParams.get('me') || '');
      if (!room.members.some(m => m.id === me)) {
        fail(res, 403, 'not_in_room');
        return;
      }
      const cursor = Number(url.searchParams.get('since')) || 0;
      const from = cursor > 0 ? Math.max(0, cursor - 12000) : 0;
      const msgs = [];
      let last = cursor;
      for (const packet of room.messages) {
        if (packet.to !== 'broadcast' && packet.to !== me) continue;
        if (packet.to === 'broadcast' && packet.from === me) continue;
        const at = Number(packet.createdAt) || 0;
        if (at < from) continue;
        msgs.push({ id: packet.id, from: packet.from || '', payload: packet.payload });
        if (at > last) last = at;
      }
      touch(room);
      ok(res, { last: String(last), msgs });
      return;
    }

    if (action === 'signal') {
      let body = {};
      try { body = await readJson(req); }
      catch (err) {
        fail(res, 400, err.message === 'body_too_large' ? 'body_too_large' : 'bad_json');
        return;
      }
      if (!body.payload || typeof body.payload !== 'object') {
        fail(res, 400, 'bad_signal');
        return;
      }
      const from = String(body.from || '');
      if (!room.members.some(m => m.id === from)) {
        fail(res, 403, 'not_in_room');
        return;
      }
      const requested = String(url.searchParams.get('to') || '');
      let to = requested === 'broadcast' ? 'broadcast' : requested;
      const roleTarget = room.members.find(m => m.role === requested);
      if (roleTarget) to = roleTarget.id;
      if (to !== 'broadcast' && !room.members.some(m => m.id === to)) {
        fail(res, 400, 'bad_target');
        return;
      }
      room.messages.push({
        id: messageId(),
        from,
        to,
        payload: body.payload,
        createdAt: Date.now(),
      });
      if (room.messages.length > MAX_MESSAGES) room.messages.splice(0, room.messages.length - MAX_MESSAGES);
      touch(room);
      ok(res);
      return;
    }

    fail(res, 400, 'bad_action');
  } catch (err) {
    console.error('[room]', err);
    if (!res.headersSent) fail(res, 503, 'room_unavailable');
  }
}

function forbiddenPath(pathname) {
  return /^\/(?:backups|\.git|\.codex|\.agents|\.aws|node_modules)(?:\/|$)/i.test(pathname);
}

async function sendFile(req, res, url) {
  let pathname;
  try { pathname = decodeURIComponent(url.pathname); }
  catch (_) { res.writeHead(400); res.end('Bad URL'); return; }
  if (pathname === '/') pathname = '/index.html';
  if (forbiddenPath(pathname)) {
    res.writeHead(403);
    res.end('Forbidden');
    return;
  }
  const file = path.resolve(STATIC_ROOT, '.' + pathname);
  const root = path.resolve(STATIC_ROOT);
  if (file !== root && !file.startsWith(root + path.sep)) {
    res.writeHead(403);
    res.end('Forbidden');
    return;
  }
  try {
    const stat = await fsp.stat(file);
    if (!stat.isFile()) throw new Error('not_file');
    res.writeHead(200, {
      'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream',
      'Cache-Control': 'no-cache',
    });
    if (req.method !== 'HEAD') fs.createReadStream(file).pipe(res);
    else res.end();
  } catch (_) {
    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('Not found');
  }
}

const server = http.createServer((req, res) => {
  const url = new URL(req.url || '/', 'http://' + (req.headers.host || 'localhost'));
  if (url.pathname === '/room' || url.pathname === '/room.php' || url.pathname === '/.netlify/functions/room') {
    roomApi(req, res, url);
    return;
  }
  if (req.method !== 'GET' && req.method !== 'HEAD') {
    res.writeHead(405);
    res.end();
    return;
  }
  sendFile(req, res, url);
});

const wss = new WebSocketServer({ noServer: true, perMessageDeflate: false });

server.on('upgrade', (req, socket, head) => {
  const url = new URL(req.url || '/', 'http://' + (req.headers.host || 'localhost'));
  if (url.pathname !== '/room' || url.searchParams.get('action') !== 'ws') {
    socket.destroy();
    return;
  }
  const code = normalizeCode(url.searchParams.get('code'));
  const me = String(url.searchParams.get('me') || '');
  const room = getRoom(code);
  const member = room && room.members.find(m => m.id === me);
  if (!room || !member) {
    socket.write('HTTP/1.1 404 Not Found\r\nConnection: close\r\n\r\n');
    socket.destroy();
    return;
  }
  wss.handleUpgrade(req, socket, head, ws => {
    addSocket(room, member, ws);
    sendSocket(ws, { t: 'members', members: publicMembers(room) });
  });
});

const heartbeat = setInterval(() => {
  for (const ws of wss.clients) {
    if (ws.isAlive === false) {
      try { ws.terminate(); } catch (_) {}
      continue;
    }
    ws.isAlive = false;
    try { ws.ping(); } catch (_) {}
  }
}, 30000);
heartbeat.unref();

const cleanup = setInterval(() => {
  const now = Date.now();
  for (const [code, room] of rooms) {
    if (now - room.updatedAt > ROOM_TTL_MS) {
      closeRoomSockets(room, 1001, 'room_expired');
      rooms.delete(code);
    }
  }
}, 10 * 60 * 1000);
cleanup.unref();

function shutdown() {
  clearInterval(heartbeat);
  clearInterval(cleanup);
  for (const room of rooms.values()) closeRoomSockets(room, 1001, 'server_shutdown');
  server.close(() => process.exit(0));
}
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

server.on('error', err => {
  if (err && err.code === 'EADDRINUSE') {
    console.error('端口 ' + PORT + ' 已被占用，请先关闭旧的服务器后再试。');
    process.exitCode = 1;
    return;
  }
  throw err;
});

server.listen(PORT, '0.0.0.0', () => {
  console.log('后室 Render/Node 服务器已启动，端口 ' + PORT);
  console.log('静态目录: ' + STATIC_ROOT);
  console.log('HTTP: /room');
  console.log('WebSocket: /room?action=ws');
  const nets = os.networkInterfaces();
  const seen = new Set();
  for (const list of Object.values(nets)) {
    for (const n of (list || [])) {
      if (n.family === 'IPv4' && !n.internal && !seen.has(n.address)) {
        seen.add(n.address);
        console.log('局域网访问: http://' + n.address + ':' + PORT);
      }
    }
  }
});
