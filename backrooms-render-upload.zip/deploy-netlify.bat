@echo off
setlocal
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo ERROR: Node.js was not found.
  pause
  exit /b 1
)

echo Building dist...
node scripts\build-dist.mjs
if errorlevel 1 (
  echo ERROR: dist build failed.
  pause
  exit /b 1
)

if exist ".netlify\state.json" goto deploy

echo.
echo This script creates a NEW Netlify project.
set "SITE_NAME="
set /p "SITE_NAME=Enter a new project name (example: backrooms-online): "
if not defined SITE_NAME set "SITE_NAME=backrooms-online"

echo Creating new Netlify project: %SITE_NAME%
call npx --yes netlify-cli sites:create --name "%SITE_NAME%"
if errorlevel 1 (
  echo ERROR: Could not create the new Netlify project.
  echo The project name may already be taken. Run again with another name.
  pause
  exit /b 1
)

:deploy
echo Deploying site and Edge Functions...
call npx --yes netlify-cli deploy --prod --dir=dist
if errorlevel 1 (
  echo ERROR: Netlify deploy failed.
  pause
  exit /b 1
)

echo Deploy complete.
pause