$ErrorActionPreference = 'Stop'

$projectRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$outputPath = Join-Path $projectRoot 'backrooms-render-upload.zip'
$temporaryPath = Join-Path $projectRoot 'backrooms-render-upload.tmp.zip'

$excludedRootNames = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
@(
    '.git', '.codex', '.agents', '.aws', '.netlify', '$tmp',
    'backups', 'dist', 'node_modules',
    'github-admin-command-fix-upload', 'github-render-upload',
    'github-update-files', 'github-upload-flat'
) | ForEach-Object { [void]$excludedRootNames.Add($_) }

$excludedFileNames = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
@(
    'backrooms-render-upload.zip',
    'backrooms-render-upload.tmp.zip',
    'github-admin-command-fix-upload.zip'
) | ForEach-Object { [void]$excludedFileNames.Add($_) }

if (Test-Path -LiteralPath $temporaryPath) {
    Remove-Item -LiteralPath $temporaryPath -Force
}

Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem

$archive = [System.IO.Compression.ZipFile]::Open(
    $temporaryPath,
    [System.IO.Compression.ZipArchiveMode]::Create
)

$fileCount = 0
try {
    foreach ($entry in Get-ChildItem -LiteralPath $projectRoot -Force) {
        if ($excludedRootNames.Contains($entry.Name) -or $excludedFileNames.Contains($entry.Name)) {
            continue
        }

        $files = if ($entry.PSIsContainer) {
            Get-ChildItem -LiteralPath $entry.FullName -Recurse -Force -File
        } else {
            @($entry)
        }

        foreach ($file in $files) {
            $relativePath = $file.FullName.Substring($projectRoot.Length).TrimStart('\', '/').Replace('\', '/')
            # Original reference downloads are kept locally for audit; only optimized in-game JPGs ship.
            if ($relativePath.StartsWith('tools/textures/reference-downloads/', [System.StringComparison]::OrdinalIgnoreCase)) {
                continue
            }
            if ($relativePath.StartsWith('tests/output/', [System.StringComparison]::OrdinalIgnoreCase)) {
                continue
            }
            [void][System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile(
                $archive,
                $file.FullName,
                $relativePath,
                [System.IO.Compression.CompressionLevel]::Optimal
            )
            $fileCount++
        }
    }
}
finally {
    $archive.Dispose()
}

if ($fileCount -lt 20 -or -not (Test-Path -LiteralPath $temporaryPath)) {
    throw "Package validation failed: only $fileCount files were written."
}

$temporarySize = (Get-Item -LiteralPath $temporaryPath).Length
if ($temporarySize -lt 500000) {
    throw "Package validation failed: ZIP is unexpectedly small ($temporarySize bytes)."
}

Move-Item -LiteralPath $temporaryPath -Destination $outputPath -Force
$sizeMb = [Math]::Round((Get-Item -LiteralPath $outputPath).Length / 1MB, 2)
Write-Host "Packed $fileCount files ($sizeMb MB)."
