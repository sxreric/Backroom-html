import { cp, mkdir, readdir, rm } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const dist = path.join(root, 'dist');
const excluded = new Set([
  '.git', '.codex', '.agents', '.aws', '$tmp', 'backups', 'node_modules',
  'dist', 'netlify', 'cloudflare', 'scripts', 'package.json', 'package-lock.json',
  'netlify.toml', 'wrangler.jsonc', 'render.yaml', 'server.js', 'start-game.bat', 'deploy-netlify.bat',
  'deploy-cloudflare.bat',
  'backrooms-render-upload.zip', 'backrooms-render-upload.tmp.zip', 'github-admin-command-fix-upload.zip',
  'github-admin-command-fix-upload', 'github-render-upload', 'github-update-files', 'github-upload-flat',
]);

await rm(dist, { recursive: true, force: true });
await mkdir(dist, { recursive: true });

for (const entry of await readdir(root, { withFileTypes: true })) {
  if (excluded.has(entry.name)) continue;
  await cp(path.join(root, entry.name), path.join(dist, entry.name), { recursive: true });
}

console.log(`dist build complete: ${dist}`);
