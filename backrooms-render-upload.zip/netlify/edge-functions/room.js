import { getStore } from 'https://esm.sh/@netlify/blobs@11.1.4?target=deno';

const ROOM_TTL_MS = 2 * 60 * 60 * 1000;

function store() {
  return getStore({ name: 'backrooms-rooms', consistency: 'strong' });
}

function cleanName(name) {
  const s = String(name == null ? '' : name).trim().slice(0, 16);
  return s || 'anonymous';
}

const CORS = {
  'Content-Type': 'application/json; charset=utf-8',
  'Cache-Control': 'no-store',
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
};

function response(status, data) {
  return new Response(JSON.stringify(data), { status, headers: CORS });
}
function ok(data = {}) { return response(200, { ok: true, ...data }); }
function fail(status, error) { return response(status, { ok: false, error }); }
function options() { return new Response(null, { status: 204, headers: CORS }); }

async function readJson(request) {
  const raw = await request.text();
  if (!raw) return {};
  if (raw.length > 1024 * 1024) throw new Error('body_too_large');
  return JSON.parse(raw);
}

function normalizeCode(value) {
  return String(value == null ? '' : value).toUpperCase().replace(/[^A-Z0-9]/g, '');
}
function roomKey(code) { return 'room/' + code + '/meta'; }
function messagePrefix(code) { return 'room/' + code + '/msg/'; }
function newCode() {
  return crypto.randomUUID().replace(/-/g, '').slice(0, 6).toUpperCase();
}
function messageId() {
  // key 仍保持唯一；排序不再承担游标职责，poll 用 createdAt + 短回放窗口，避免
  // 同一毫秒内随机后缀的字典序让后来的 offer/ICE 被漏掉。
  return String(Date.now()).padStart(13, '0') + '-' + crypto.randomUUID().replace(/-/g, '');
}

async function readRoom(code) {
  const room = await store().get(roomKey(code), { type: 'json', consistency: 'strong' });
  if (!room || room.closed || Date.now() - room.updatedAt > ROOM_TTL_MS) {
    if (room) await store().delete(roomKey(code));
    return null;
  }
  return room;
}
async function saveRoom(room) {
  room.updatedAt = Date.now();
  await store().setJSON(roomKey(room.code), room);
}

async function createRoom(body) {
  for (let attempt = 0; attempt < 8; attempt++) {
    const code = newCode();
    const existing = await store().get(roomKey(code), { type: 'json', consistency: 'strong' });
    if (existing) continue;
    await store().setJSON(roomKey(code), {
      code,
      hostName: cleanName(body.name),
      guestName: '',
      updatedAt: Date.now(),
      closed: false,
    });
    return ok({ code });
  }
  return fail(503, 'code_exhausted');
}

async function pollRoom(room, me, since) {
  const prefix = messagePrefix(room.code);
  const rawCursor = Number(since);
  const cursor = Number.isFinite(rawCursor) && rawCursor > 0 ? rawCursor : 0;
  // Blobs 的 key 后缀是随机 UUID：同一毫秒里后写入的消息可能排在游标之前。
  // 回看 12 秒，再由客户端按消息 id 去重，确保 offer / answer / ICE 一条不漏。
  const from = cursor > 0 ? Math.max(0, cursor - 12000) : 0;
  const listed = await store().list({ prefix });
  const keys = (listed.blobs || [])
    .map(entry => entry.key.slice(prefix.length))
    .sort();
  // Blob get 是网络 I/O，不能逐条 await；ICE 候选多时会把下一次轮询拖到超时。
  // 先筛掉回放窗口外的 key，再并发读取最近消息，最后按 key 顺序交给客户端去重。
  const recent = keys.filter(id => {
    const keyTime = Number(id.slice(0, 13));
    return !Number.isFinite(keyTime) || keyTime >= from;
  });
  const packets = await Promise.all(recent.map(async id => ({
    id,
    packet: await store().get(prefix + id, { type: 'json', consistency: 'strong' }),
  })));
  const msgs = [];
  let last = cursor;
  for (const { id, packet } of packets) {
    const keyTime = Number(id.slice(0, 13));
    if (packet && packet.to === me && packet.payload) {
      const at = Number(packet.createdAt) || (Number.isFinite(keyTime) ? keyTime : 0);
      if (at < from) continue;
      msgs.push({ id, payload: packet.payload });
      if (at > last) last = at;
    }
  }
  return ok({ last: String(last), msgs });
}

async function route(request) {
  if (request.method === 'OPTIONS') return options();
  const url = new URL(request.url);
  const action = url.searchParams.get('action') || '';
  const code = normalizeCode(url.searchParams.get('code'));
  if (!action) return fail(400, 'bad_action');

  try {
    if (action === 'create') {
      let body;
      try { body = await readJson(request); }
      catch (err) { return fail(400, err.message === 'body_too_large' ? 'body_too_large' : 'bad_json'); }
      return createRoom(body);
    }

    if (action === 'status') {
      const room = await readRoom(code);
      if (!room) return fail(404, 'room_not_found');
      return ok({
        state: room.guestName ? 'joined' : 'waiting',
        host_name: room.hostName,
        guest_name: room.guestName,
      });
    }

    if (action === 'join') {
      let body;
      try { body = await readJson(request); }
      catch (err) { return fail(400, err.message === 'body_too_large' ? 'body_too_large' : 'bad_json'); }
      const room = await readRoom(code);
      if (!room) return fail(404, 'room_not_found');
      if (room.guestName) return fail(409, 'room_full');
      room.guestName = cleanName(body.name);
      await saveRoom(room);
      return ok({ host: room.hostName });
    }

    if (action === 'poll') {
      const room = await readRoom(code);
      if (!room) return fail(404, 'room_not_found');
      const me = url.searchParams.get('me') === 'host' ? 'host' : 'guest';
      return pollRoom(room, me, url.searchParams.get('since'));
    }

    if (action === 'signal') {
      let body;
      try { body = await readJson(request); }
      catch (err) { return fail(400, err.message === 'body_too_large' ? 'body_too_large' : 'bad_json'); }
      const room = await readRoom(code);
      if (!room) return fail(404, 'room_not_found');
      const to = url.searchParams.get('to') === 'host' ? 'host' : 'guest';
      if (!body.payload || typeof body.payload !== 'object') return fail(400, 'bad_signal');
      const id = messageId();
      await store().setJSON(messagePrefix(code) + id, { to, payload: body.payload, createdAt: Number(id.slice(0, 13)) || Date.now() });
      return ok();
    }

    if (action === 'close') {
      if (code) await store().delete(roomKey(code));
      return ok();
    }

    return fail(400, 'bad_action');
  } catch (err) {
    console.error('[room]', err);
    return fail(503, 'db_unavailable');
  }
}

export default route;
export const config = {
  path: ['/.netlify/functions/room', '/room.php'],
};
