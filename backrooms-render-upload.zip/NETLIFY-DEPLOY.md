# Netlify 部署

这个项目的网页在 `dist`，房间号接口在 `netlify/edge-functions/room.js`。只上传 `dist` 会缺少联机接口，所以推荐从项目根目录部署：

```powershell
npx netlify-cli login
.\deploy-netlify.bat
```

第一次部署按 Netlify 提示选择或创建站点。之后把 Netlify 生成的同一个网址发给朋友：一人点“创建房间”，其他人输入同一个 6 位房间号点“加入房间”。

如果使用 Netlify 的 Git 仓库部署，项目根目录的 `netlify.toml` 会自动使用 `dist` 作为发布目录，同时部署 `netlify/edge-functions`。