@echo off
setlocal
cd /d "%~dp0"

echo Building site...
call node scripts\build-dist.mjs
if errorlevel 1 goto :failed

where npx >nul 2>nul
if errorlevel 1 (
  echo Node.js and npx are required. Please install Node.js first.
  goto :failed
)

call npx --yes wrangler whoami >nul 2>nul
if errorlevel 1 (
  echo Opening Cloudflare login...
  call npx --yes wrangler login
  if errorlevel 1 goto :failed
)

echo Deploying site and room server...
call npx --yes wrangler deploy
if errorlevel 1 goto :failed

echo.
echo Cloudflare deployment complete.
echo Use the workers.dev URL shown above, or add a custom domain in Cloudflare.
pause
exit /b 0

:failed
echo.
echo Cloudflare deployment failed.
pause
exit /b 1