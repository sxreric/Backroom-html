// 可选浏览器回归：设置 PLAYWRIGHT_CORE_PATH / CHROME_PATH 后运行 node tests/guns-browser.mjs。
import assert from 'node:assert/strict';
import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';

const require = createRequire(import.meta.url);
const { chromium } = require(process.env.PLAYWRIGHT_CORE_PATH || 'playwright-core');
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const mime = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.glb': 'model/gltf-binary', '.png': 'image/png', '.jpg': 'image/jpeg' };
const server = http.createServer((req, res) => {
  let pathname;
  try { pathname = decodeURIComponent(new URL(req.url, 'http://localhost').pathname); } catch { res.writeHead(400).end(); return; }
  const file = path.resolve(root, '.' + (pathname === '/' ? '/index.html' : pathname));
  if (!file.startsWith(root + path.sep) || !fs.existsSync(file) || !fs.statSync(file).isFile()) { res.writeHead(404).end(); return; }
  res.writeHead(200, { 'Content-Type': mime[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-store' });
  fs.createReadStream(file).pipe(res);
});

await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
const base = 'http://127.0.0.1:' + server.address().port;
let browser;
try {
  browser = await chromium.launch({
    executablePath: process.env.CHROME_PATH || 'C:/Program Files/Google/Chrome/Application/chrome.exe',
    headless: true,
    args: ['--use-gl=swiftshader', '--enable-unsafe-swiftshader'],
  });
  const page = await browser.newPage({ viewport: { width: 1120, height: 700 } });
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  await page.route(/https?:\/\/api\.ovobot\.ai\//, route => route.fulfill({ status: 200, contentType: 'application/json', body: '{"ok":false}' }));
  await page.goto(base + '/index.html');
  await page.waitForFunction(() => window.BR && BR.home && BR.home.shown && BR.guns, null, { timeout: 30000 });
  const models = await page.evaluate(async () => {
    const result = [];
    for (const spec of BR.guns.list) {
      const response = await fetch('assets/models/' + spec.model + '.glb');
      result.push({ type: spec.type, status: response.status });
    }
    return result;
  });
  assert.equal(models.length, 5);
  assert.ok(models.every(x => x.status === 200), JSON.stringify(models));
  await page.evaluate(() => BR.bus.emit('game:start', {
    mode: 'test', levelId: '0', seed: 72341,
    settings: { ...BR.game.settings, startLevel: '0' }, coop: null,
  }));
  await page.waitForFunction(() => BR.game.screen === 'playing' && BR.player && BR.input.enabled, null, { timeout: 30000 });
  const fired = await page.evaluate(() => {
    BR.player.addItem('weapon_attacker_rifle', 1);
    const slot = BR.player.inventory.findIndex(s => s && s.type === 'weapon_attacker_rifle');
    BR.player.select(slot);
    const before = BR.guns.state().mag;
    BR.guns.fire('weapon_attacker_rifle');
    return { before, after: BR.guns.state().mag, slot, model: BR.guns.spec(1).model };
  });
  assert.equal(fired.after, fired.before - 1, JSON.stringify(fired));
  assert.equal(fired.model, 'weapon_attacker_rifle');
  await page.keyboard.press('r');
  await page.waitForFunction(() => BR.guns.state('weapon_attacker_rifle')?.reloading === true, null, { timeout: 3000 });
  const ui = await page.evaluate(() => ({ ammo: document.querySelector('.hud-gun-ammo')?.textContent, reloading: BR.guns.state().reloading }));
  assert.equal(ui.reloading, true);
  assert.match(ui.ammo || '', /装弹中/);
  await page.waitForFunction(() => !BR.guns.state('weapon_attacker_rifle').reloading, null, { timeout: 5000 });
  await page.evaluate(() => {
    BR.guns.fire('weapon_attacker_rifle');
    BR.input.setBinding('reload', 'KeyH');
  });
  await page.keyboard.press('r');
  assert.equal(await page.evaluate(() => BR.guns.state().reloading), false);
  await page.keyboard.press('h');
  await page.waitForFunction(() => BR.guns.state().reloading && document.querySelector('.hud-inv-name')?.textContent.includes('H 装弹'), null, { timeout: 3000 });
  assert.deepEqual(errors, []);
  console.log('Browser gun smoke passed:', models.length, 'GLB files, firing, R reload, ammo HUD');
} finally {
  if (browser) await browser.close();
  await new Promise(resolve => server.close(resolve));
}
