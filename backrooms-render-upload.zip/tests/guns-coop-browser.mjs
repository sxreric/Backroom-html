// 本地真实中继双页测试：先 npm run build，再设置 PLAYWRIGHT_CORE_PATH 并运行本文件。
import assert from 'node:assert/strict';
import net from 'node:net';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';

const require = createRequire(import.meta.url);
const { chromium } = require(process.env.PLAYWRIGHT_CORE_PATH || 'playwright-core');
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const probe = net.createServer();
await new Promise(resolve => probe.listen(0, '127.0.0.1', resolve));
const port = probe.address().port;
await new Promise(resolve => probe.close(resolve));
const base = 'http://127.0.0.1:' + port;
const server = spawn(process.execPath, ['server.js'], { cwd: root, env: { ...process.env, PORT: String(port) }, stdio: ['ignore', 'pipe', 'pipe'] });
let serverLog = '';
server.stderr.on('data', data => { serverLog += data.toString(); });
server.stdout.on('data', data => { serverLog += data.toString(); });
let browser;

async function openLobby(page, name) {
  await page.click('.home-play');
  await page.click('.home-menu-btn.is-casual');
  await page.locator('.home-dialog-casual .home-actions .home-btn', { hasText: /^联机$/ }).first().click();
  await page.locator('.coop-lobby .coop-field .coop-input').fill(name);
}
async function sendCommand(page, command) {
  await page.evaluate(() => BR.coop.toggleChat());
  await page.locator('.coop-chat-input').fill(command);
  await page.locator('.coop-chat-input').press('Enter');
  await page.evaluate(() => BR.coop.toggleChat());
}

try {
  for (let i = 0; i < 60; i++) {
    if (server.exitCode != null) throw new Error('Server exited: ' + serverLog);
    try { if ((await fetch(base + '/index.html')).ok) break; } catch { /* startup */ }
    if (i === 59) throw new Error('Server did not start: ' + serverLog);
    await new Promise(resolve => setTimeout(resolve, 100));
  }
  browser = await chromium.launch({
    executablePath: process.env.CHROME_PATH || 'C:/Program Files/Google/Chrome/Application/chrome.exe',
    headless: true,
    args: ['--use-gl=swiftshader', '--enable-unsafe-swiftshader'],
  });
  const host = await browser.newPage({ viewport: { width: 960, height: 620 } });
  const guest = await browser.newPage({ viewport: { width: 960, height: 620 } });
  const errors = [];
  host.on('pageerror', err => errors.push('host: ' + err));
  guest.on('pageerror', err => errors.push('guest: ' + err));
  await Promise.all([host.goto(base), guest.goto(base)]);
  await Promise.all([host.waitForFunction(() => BR.home?.shown && BR.coop), guest.waitForFunction(() => BR.home?.shown && BR.coop)]);
  await openLobby(host, '房主A');
  await host.locator('.coop-lobby button', { hasText: /^创建房间$/ }).first().click();
  await host.waitForFunction(() => BR.coop.phase === 'hosting' && /^[A-Z0-9]{6}$/.test(BR.coop.code || ''), null, { timeout: 15000 });
  const code = await host.evaluate(() => BR.coop.code);
  await openLobby(guest, '客机B');
  await guest.locator('.coop-code-input').fill(code);
  await guest.locator('.coop-lobby button', { hasText: /^加入$/ }).first().click();
  await guest.locator('.coop-lobby button', { hasText: /^同意加入$/ }).first().click();
  await Promise.all([host.waitForFunction(() => BR.coop.active, null, { timeout: 30000 }), guest.waitForFunction(() => BR.coop.active, null, { timeout: 30000 })]);
  const started = await host.evaluate(() => BR.coop.startGame({ mode: 'casual', levelId: '0', seed: 8910, settings: { ...BR.game.settings, startLevel: '0' } }));
  assert.equal(started, true);
  await Promise.all([host.waitForFunction(() => BR.game.screen === 'playing', null, { timeout: 30000 }), guest.waitForFunction(() => BR.game.screen === 'playing', null, { timeout: 30000 })]);
  await host.evaluate(() => {
    window.__gunReceived = [];
    const original = BR.guns.remoteFire;
    BR.guns.remoteFire = (...args) => { const result = original(...args); window.__gunReceived.push({ args, result }); return result; };
  });
  const shot = await guest.evaluate(() => {
    BR.player.addItem('weapon_attacker_rifle', 1);
    BR.player.select(BR.player.inventory.findIndex(x => x?.type === 'weapon_attacker_rifle'));
    BR.guns.fire('weapon_attacker_rifle');
    return BR.guns.state('weapon_attacker_rifle').mag;
  });
  assert.equal(shot, 29);
  await host.waitForFunction(() => window.__gunReceived?.length > 0, null, { timeout: 10000 });
  const remote = await host.evaluate(() => window.__gunReceived[0]);
  assert.equal(remote.result.rejected, undefined);
  assert.equal(remote.result.ammo.mag, 29);
  const reloading = await guest.evaluate(() => BR.guns.reload());
  assert.equal(reloading, true);
  await guest.waitForFunction(() => BR.guns.state('weapon_attacker_rifle').mag === 30 && BR.guns.state('weapon_attacker_rifle').reserve === 119, null, { timeout: 7000 });
  const supplied = await guest.evaluate(() => BR.itemTypes.get('ammo_rifle').use());
  assert.equal(supplied, true);
  await guest.waitForFunction(() => BR.guns.state('weapon_attacker_rifle').reserve === 179, null, { timeout: 5000 });
  await sendCommand(host, '/auth gugugu');
  await sendCommand(host, '/fly 客机B 1');
  await guest.waitForFunction(() => BR.admin?.flightGranted && BR.player.flight, null, { timeout: 10000 });
  await sendCommand(host, '/fly 客机B 0');
  await guest.waitForFunction(() => !BR.admin?.flightGranted && !BR.player.flight, null, { timeout: 10000 });
  assert.deepEqual(errors, []);
  console.log('Coop gun and /fly smoke passed:', code);
} finally {
  if (browser) await browser.close();
  server.kill();
}
