import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { test } from 'node:test';
import vm from 'node:vm';

const source = readFileSync(new URL('../js/items/guns.js', import.meta.url), 'utf8');

function makeGame() {
  let time = 1000;
  const registered = new Map();
  const hit = { id: 'monster-1', x: 0, y: 0, z: -5, r: 0.5, h: 2 };
  const damage = [];
  const sent = [];
  const BR = {
    itemKit: {
      icon: () => 'icon',
      livingEntities: () => [hit],
      damageEntity: (entity, amount) => { damage.push([entity.id, amount]); return true; },
      toast() {},
    },
    itemTypes: { register: def => registered.set(def.type, def) },
    player: {
      x: 0, y: 1.62, z: 0, yaw: 0, pitch: 0, selected: 0, dead: false,
      inventory: [{ type: 'weapon_attacker_rifle', count: 1 }],
    },
    phys: { raycast: () => ({ dist: 50 }) },
    entities: { makeNoise() {} },
    bus: { on() {}, emit() {} },
    input: { haptic() {}, refreshButtons() {} },
    audio: { play() {} },
    game: { screen: 'playing' },
    coop: { active: false, role: null, requestGunFire: p => (sent.push(p), true) },
  };
  const performance = { now: () => time };
  vm.runInNewContext(source, { window: { BR, THREE: {}, performance }, performance, console });
  return { BR, registered, damage, sent, advance: ms => { time += ms; } };
}

test('single-player rifle consumes ammo, respects rate limit and hits the monster', () => {
  const g = makeGame();
  g.BR.guns.equip('weapon_attacker_rifle');
  g.BR.guns.fire('weapon_attacker_rifle');
  assert.equal(g.BR.guns.state().mag, 29);
  assert.equal(g.damage.length, 1);
  assert.equal(g.damage[0][0], 'monster-1');
  g.BR.guns.fire('weapon_attacker_rifle');
  assert.equal(g.BR.guns.state().mag, 29);
  g.advance(106);
  g.BR.guns.fire('weapon_attacker_rifle');
  assert.equal(g.BR.guns.state().mag, 28);
});

test('reload transfers reserve into magazine only when its timer finishes', () => {
  const g = makeGame();
  g.BR.guns.equip('weapon_attacker_rifle');
  g.BR.guns.fire('weapon_attacker_rifle');
  assert.equal(g.BR.guns.reload(), true);
  assert.equal(g.BR.guns.state().mag, 29);
  assert.equal(g.BR.guns.state().reloading, true);
  g.advance(1999);
  assert.equal(g.BR.guns.state().mag, 29);
  g.advance(1);
  assert.equal(g.BR.guns.state().mag, 30);
  assert.equal(g.BR.guns.state().reserve, 119);
});

test('guest predicts feedback while host is sole authority for damage', () => {
  const g = makeGame();
  g.BR.guns.equip('weapon_attacker_rifle');
  g.BR.coop.active = true;
  g.BR.coop.role = 'guest';
  g.BR.guns.fire('weapon_attacker_rifle');
  assert.equal(g.sent.length, 1);
  assert.equal(g.damage.length, 0);
  assert.equal(g.BR.guns.state().mag, 29);
  const packet = { ...g.sent[0], sourceId: 'guest-1' };
  const accepted = g.BR.guns.remoteFire(packet.type, packet);
  assert.equal(accepted.hit, true);
  assert.equal(g.damage.length, 1);
  assert.equal(accepted.ammo.mag, 29);
  assert.equal(g.BR.guns.remoteFire(packet.type, packet).rejected, true);
  assert.equal(g.damage.length, 1);
  g.BR.guns.reconcile(accepted.ammo, packet.shotId);
  assert.equal(g.BR.guns.state().mag, 29);
});

test('ammunition item replenishes reserve without changing GLB weapon type', () => {
  const g = makeGame();
  g.BR.guns.equip('weapon_attacker_rifle');
  const rifle = g.registered.get('weapon_attacker_rifle');
  const box = g.registered.get('ammo_rifle');
  assert.equal(g.BR.guns.spec(1).model, 'weapon_attacker_rifle');
  assert.equal(typeof rifle.build, 'function');
  assert.equal(box.use(), true);
  assert.equal(g.BR.guns.state().reserve, 180);
});
