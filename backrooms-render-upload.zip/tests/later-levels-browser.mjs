// Browser regression for the newly extended level range. Run with PLAYWRIGHT_CORE_PATH and CHROME_PATH.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';

const require = createRequire(import.meta.url);
const { chromium } = require(process.env.PLAYWRIGHT_CORE_PATH || 'playwright-core');
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const mime = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.jpg': 'image/jpeg', '.png': 'image/png', '.json': 'application/json', '.glb': 'model/gltf-binary' };
const server = http.createServer((req, res) => {
  let url;
  try { url = decodeURIComponent(new URL(req.url, 'http://localhost').pathname); } catch { res.writeHead(400).end(); return; }
  const file = path.resolve(root, '.' + (url === '/' ? '/index.html' : url));
  if (!file.startsWith(root + path.sep) || !fs.existsSync(file) || !fs.statSync(file).isFile()) { res.writeHead(404).end(); return; }
  res.writeHead(200, { 'Content-Type': mime[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-store' });
  fs.createReadStream(file).pipe(res);
});

await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
let browser;
try {
  browser = await chromium.launch({ executablePath: process.env.CHROME_PATH || 'C:/Program Files/Google/Chrome/Application/chrome.exe', headless: true, args: ['--use-gl=swiftshader', '--enable-unsafe-swiftshader'] });
  const page = await browser.newPage({ viewport: { width: 900, height: 600 } });
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  await page.route(/https?:\/\/api\.ovobot\.ai\//, route => route.fulfill({ status: 200, contentType: 'application/json', body: '{"ok":false}' }));
  await page.goto(`http://127.0.0.1:${server.address().port}/index.html`);
  await page.waitForFunction(() => window.BR && BR.home && BR.home.shown && BR.kit, null, { timeout: 30000 });
  const results = await page.evaluate(() => {
    const errors = [], rows = [];
    for (let n = 24; n <= 53; n++) {
      const id = String(n), lv = BR.levels.get(id);
      if (!lv) { errors.push(`L${id}: not registered`); continue; }
      const ctx = { THREE, BR, level: lv, levelSeed: 30261, assets: BR.assets, game: BR.game, scene: BR.gfx?.scene };
      const spawn = lv.spawn(ctx);
      const cx = Math.floor(spawn.x / lv.chunkSize), cz = Math.floor(spawn.z / lv.chunkSize);
      let res;
      try { res = lv.buildChunk(ctx, cx, cz, BR.util.rng(ctx.levelSeed, cx, cz)); }
      catch (e) { errors.push(`L${id}: ${e.message}`); continue; }
      const playerBlocked = res.solids.some(s => spawn.x > s.minX - 0.23 && spawn.x < s.maxX + 0.23 && spawn.z > s.minZ - 0.23 && spawn.z < s.maxZ + 0.23 && s.minY < 1.5 && s.maxY > 0.4);
      if (playerBlocked) errors.push(`L${id}: spawn inside collision`);
      if (!res.spawnPoints.length && id !== '53') errors.push(`L${id}: no item spawn points`);
      if (res.solids.length < 1) errors.push(`L${id}: no solids`);
      rows.push({ id, solids: res.solids.length, items: res.spawnPoints.length, exits: res.exits.length });
      res.group.traverse(o => { if (o.geometry && !o.geometry.userData?.shared) o.geometry.dispose(); });
      res.dispose?.();
    }
    for (const tex of ['l24_lunar_reference', 'l24_regolith', 'l31_rink_reference', 'l33_mall_reference', 'l37_pool_reference', 'l52_cavern_reference', 'l53_home_reference']) {
      if (BR.assets.sourceOf(tex) === 'missing') errors.push(`missing texture ${tex}`);
    }
    for (const id of ['50', '51', '52']) {
      const lv = BR.levels.get(id), ctx = { THREE, BR, level: lv, levelSeed: 30261, assets: BR.assets, game: BR.game, scene: BR.gfx?.scene };
      const rng = BR.util.rng(ctx.levelSeed, 'L' + id + ':route-v1');
      const cells = [[1, 1], [1, 6], [6, 1], [6, 6]];
      const dirs = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]];
      rng(); // starting cell
      const dir = dirs[Math.floor(rng() * dirs.length) % dirs.length];
      const radius = 4 + Math.floor(rng() * 3);
      const end = cells[Math.floor(rng() * cells.length) % cells.length];
      const res = lv.buildChunk(ctx, dir[0] * radius, dir[1] * radius, BR.util.rng(ctx.levelSeed, dir[0] * radius, dir[1] * radius));
      if (res.exits.length !== 1 || res.exits[0].to !== String(Number(id) + 1)) errors.push(`L${id}: exit missing or wrong destination`);
      const x = (dir[0] * radius * lv.chunkSize) + (end[0] + 0.5) * 3;
      const z = (dir[1] * radius * lv.chunkSize) + (end[1] + 0.5) * 3;
      if (res.solids.some(s => x > s.minX - 0.25 && x < s.maxX + 0.25 && z > s.minZ - 0.25 && z < s.maxZ + 0.25 && s.minY < 1.5 && s.maxY > 0.4))
        errors.push(`L${id}: exit inside collision`);
      res.group.traverse(o => { if (o.geometry && !o.geometry.userData?.shared) o.geometry.dispose(); });
      res.dispose?.();
    }
    return { errors, rows };
  });
  assert.deepEqual(errors, []);
  assert.deepEqual(results.errors, [], JSON.stringify(results, null, 2));
  await page.waitForFunction(() => ['l24_lunar_reference', 'l24_regolith', 'l31_rink_reference', 'l33_mall_reference', 'l37_pool_reference', 'l52_cavern_reference', 'l53_home_reference'].every(name => BR.assets.sourceOf(name) === 'file'), null, { timeout: 10000 });
  console.log(`PASS ${results.rows.length} levels (24–53); representative solid counts:`, results.rows.filter(r => ['24', '35', '37', '51', '52', '53'].includes(r.id)));
  for (const id of ['51', '52', '53']) {
    await page.evaluate(id => BR.bus.emit('game:start', { mode: 'test', levelId: id, seed: 30261, settings: { ...BR.game.settings, startLevel: id }, coop: null }), id);
    await page.waitForFunction(id => BR.game.screen === 'playing' && BR.game.levelId === id && BR.world.current, id, { timeout: 30000 });
    assert.deepEqual(errors, []);
    await page.waitForTimeout(1500);
    await page.screenshot({ path: path.join(root, 'tests', 'output', `level${id}-visual-check.png`) });
    console.log(`PASS L${id} actual game transition`);
    await page.evaluate(() => BR.bus.emit('game:home'));
    await page.waitForFunction(() => BR.game.screen === 'home', null, { timeout: 30000 });
  }
} finally {
  await browser?.close();
  server.close();
}
