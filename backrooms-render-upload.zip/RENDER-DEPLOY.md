# Render 免费部署

项目已经准备好 Render 配置：`render.yaml` 会创建一个新加坡区域的免费 Node.js Web Service。
它同时提供网页和 `/room` WebSocket 房间接口，不需要 Cloudflare Durable Objects。

## 部署

1. 把当前项目的新增/修改文件同步到 GitHub 仓库 `Vibetool/backrooms`。
2. 登录 Render，选择 `New` → `Web Service` → `Public Git Repository`。
3. 填入 `https://github.com/Vibetool/backrooms`，选择 `main` 分支。
4. Render 读取根目录 `render.yaml`；区域选 `Singapore`，计划选 `Free`。
5. 部署完成后使用 Render 给出的 `https://sx-backroom.onrender.com` 地址。

如果希望使用自己的域名，在 Service → Settings → Custom Domains 添加域名，再按 Render 提示添加 CNAME。没有自己购买的域名时，不能把 `backrooms.workers.dev` 这个 Cloudflare 子域名搬到 Render。

## 免费版注意事项

- 空闲 15 分钟后会休眠，下一次打开可能要等待几十秒启动。
- 服务重启后临时房间会消失；房间号和聊天本来就是临时数据。
- 单个服务最多 5 人房间；游戏连接期间 WebSocket 会保持服务活跃。