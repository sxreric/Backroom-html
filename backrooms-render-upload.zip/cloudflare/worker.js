import { DurableObject } from 'cloudflare:workers';

const ROOM_TTL_MS = 2 * 60 * 60 * 1000;
const MAX_MESSAGES = 2048;
const MAX_PLAYERS = 5;
const MAX_BODY_BYTES = 1024 * 1024;

const CORS = {
  'Content-Type': 'application/json; charset=utf-8',
  'Cache-Control': 'no-store',
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
};

function response(status, data) {
  return new Response(JSON.stringify(data), { status, headers: CORS });
}
function ok(data = {}) { return response(200, { ok: true, ...data }); }
function fail(status, error) { return response(status, { ok: false, error }); }
function options() { return new Response(null, { status: 204, headers: CORS }); }

function cleanName(name) {
  const s = String(name == null ? '' : name).trim().slice(0, 16);
  return s || 'anonymous';
}
function normalizeCode(value) {
  return String(value == null ? '' : value).toUpperCase().replace(/[^A-Z0-9]/g, '');
}
function newCode() {
  return crypto.randomUUID().replace(/-/g, '').slice(0, 6).toUpperCase();
}
function messageId() {
  return String(Date.now()).padStart(13, '0') + '-' + crypto.randomUUID().replace(/-/g, '');
}
function memberId() {
  return crypto.randomUUID().replace(/-/g, '').slice(0, 16);
}
function publicMembers(room) {
  return (room.members || []).map(m => ({ id: m.id, role: m.role, name: m.name }));
}
async function readJson(request) {
  const raw = await request.text();
  if (!raw) return {};
  if (raw.length > MAX_BODY_BYTES) throw new Error('body_too_large');
  return JSON.parse(raw);
}

/*
 * One code maps to one Durable Object. All join, close and message operations
 * are serialized here, so five clients can safely share the same room.
 */
export class RoomDurableObject extends DurableObject {
  async clearRoom() {
    await this.ctx.storage.delete('room');
    await this.ctx.storage.delete('messages');
  }

  async readRoom() {
    const room = await this.ctx.storage.get('room');
    if (!room || room.closed || Date.now() - room.updatedAt > ROOM_TTL_MS) {
      if (room) await this.clearRoom();
      return null;
    }
    // 兼容从旧版两人协议留下的 Durable Object 房间
    if (!Array.isArray(room.members)) {
      const host = { id: room.hostId || memberId(), role: 'host', name: cleanName(room.hostName), joinedAt: room.updatedAt || Date.now() };
      room.hostId = host.id;
      room.members = [host];
      if (room.guestName) room.members.push({ id: memberId(), role: 'guest', name: cleanName(room.guestName), joinedAt: room.updatedAt || Date.now() });
      await this.ctx.storage.put('room', room);
    }
    return room;
  }

  async saveRoom(room) {
    room.updatedAt = Date.now();
    await this.ctx.storage.put('room', room);
  }

  async createRoom(code, body) {
    const old = await this.readRoom();
    if (old) return fail(409, 'room_exists');
    const host = { id: memberId(), role: 'host', name: cleanName(body.name), joinedAt: Date.now() };
    const room = {
      code,
      hostId: host.id,
      hostName: host.name,
      members: [host],
      updatedAt: Date.now(),
      closed: false,
    };
    await this.ctx.storage.put('room', room);
    await this.ctx.storage.put('messages', []);
    return ok({ code, id: host.id, role: 'host', members: publicMembers(room), cursor: String(Date.now()) });
  }

  async pollRoom(room, me, since, fresh) {
    const rawCursor = Number(since);
    const cursor = Number.isFinite(rawCursor) && rawCursor > 0 ? rawCursor : 0;
    const from = fresh ? cursor : (cursor > 0 ? Math.max(0, cursor - 12000) : 0);
    const all = (await this.ctx.storage.get('messages')) || [];
    const msgs = [];
    let last = cursor;
    for (const packet of all) {
      if (!packet || !packet.payload) continue;
      if (packet.to !== 'broadcast' && packet.to !== me) continue;
      if (packet.to === 'broadcast' && packet.from === me) continue;
      const at = Number(packet.createdAt) || 0;
      if (at < from) continue;
      msgs.push({ id: packet.id, from: packet.from || '', payload: packet.payload });
      if (at > last) last = at;
    }
    return ok({ last: String(last), msgs });
  }

  async saveSignal(room, to, body) {
    const id = messageId();
    const all = (await this.ctx.storage.get('messages')) || [];
    all.push({
      id,
      to,
      from: String(body.from || ''),
      payload: body.payload,
      createdAt: Number(id.slice(0, 13)) || Date.now(),
    });
    if (all.length > MAX_MESSAGES) all.splice(0, all.length - MAX_MESSAGES);
    await this.ctx.storage.put('messages', all);
    await this.saveRoom(room);
    return ok();
  }

  async broadcastMembers(room) {
    const packet = JSON.stringify({ t: 'members', members: publicMembers(room) });
    for (const ws of this.ctx.getWebSockets()) {
      try { if (ws.readyState === 1) ws.send(packet); } catch (err) { /* 断开的连接由运行时清理 */ }
    }
  }

  async broadcastRelay(from, payload) {
    const packet = JSON.stringify({ t: 'relay', from: String(from || ''), m: payload });
    for (const ws of this.ctx.getWebSockets()) {
      let state = null;
      try { state = ws.deserializeAttachment(); } catch (err) { state = null; }
      if (state && String(state.memberId) === String(from)) continue;
      try { if (ws.readyState === 1) ws.send(packet); } catch (err) { /* 断开的连接由运行时清理 */ }
    }
  }

  async webSocketMessage(ws, message) {
    let state = null;
    try { state = ws.deserializeAttachment(); } catch (err) { state = null; }
    const room = await this.readRoom();
    if (!room || !state || !(room.members || []).some(m => String(m.id) === String(state.memberId))) {
      try { ws.close(1008, 'room closed'); } catch (err) { /* 已关闭 */ }
      return;
    }
    let packet;
    try {
      const text = typeof message === 'string' ? message : new TextDecoder().decode(message);
      packet = JSON.parse(text);
    } catch (err) { return; }
    const payload = packet && packet.t === 'relay' && packet.m && typeof packet.m === 'object' ? packet.m : packet;
    if (!payload || typeof payload !== 'object') return;
    await this.broadcastRelay(state.memberId, payload);
  }

  async webSocketClose(ws) {
    // 不在 WebSocket 断开时删除房间成员：短暂断网需要允许客户端重连。
  }

  async fetch(request) {
    if (request.method === 'OPTIONS') return options();
    const url = new URL(request.url);
    const action = url.searchParams.get('action') || '';
    const code = normalizeCode(url.searchParams.get('code'));
    if (!action || !code) return fail(400, 'bad_action');

    try {
      if (action === 'create') {
        let body;
        try { body = await readJson(request); }
        catch (err) {
          return fail(400, err.message === 'body_too_large' ? 'body_too_large' : 'bad_json');
        }
        return await this.createRoom(code, body);
      }

      if (action === 'close') {
        const room = await this.readRoom();
        if (!room) return ok();
        let body = {};
        try { body = await readJson(request); } catch (err) { body = {}; }
        const id = String(body.id || '');
        if (id && id === room.hostId) {
          await this.broadcastRelay(id, { t: 'peerLeft', id, name: room.hostName });
          await this.clearRoom();
          return ok();
        }
        const left = (room.members || []).find(m => m.id === id);
        if (left) {
          await this.saveSignal(room, 'broadcast', {
            from: id,
            payload: { t: 'peerLeft', id, name: left.name },
          });
          room.members = room.members.filter(m => m.id !== id);
          await this.saveRoom(room);
          await this.broadcastMembers(room);
        }
        return ok();
      }

      if (action === 'ws') {
        if (request.headers.get('Upgrade') !== 'websocket') return fail(426, 'websocket_required');
        const room = await this.readRoom();
        if (!room) return fail(404, 'room_not_found');
        const me = String(url.searchParams.get('me') || '');
        if (!(room.members || []).some(m => String(m.id) === me)) return fail(403, 'not_in_room');
        const pair = new WebSocketPair();
        const [client, server] = Object.values(pair);
        this.ctx.acceptWebSocket(server);
        server.serializeAttachment({ memberId: me });
        try { server.send(JSON.stringify({ t: 'members', members: publicMembers(room) })); } catch (err) { /* 客户端马上断开 */ }
        return new Response(null, { status: 101, webSocket: client });
      }

      const room = await this.readRoom();
      if (!room) return fail(404, 'room_not_found');

      if (action === 'status') {
        const members = publicMembers(room);
        const firstGuest = members.find(m => m.role === 'guest');
        return ok({
          state: members.length > 1 ? 'joined' : 'waiting',
          host_name: room.hostName,
          guest_name: firstGuest ? firstGuest.name : '',
          members,
          count: members.length,
          max: MAX_PLAYERS,
          full: members.length >= MAX_PLAYERS,
        });
      }

      if (action === 'join') {
        let body;
        try { body = await readJson(request); }
        catch (err) {
          return fail(400, err.message === 'body_too_large' ? 'body_too_large' : 'bad_json');
        }
        if ((room.members || []).length >= MAX_PLAYERS) return fail(409, 'room_full');
        const guest = { id: memberId(), role: 'guest', name: cleanName(body.name), joinedAt: Date.now() };
        room.members = (room.members || []).concat(guest);
        await this.saveRoom(room);
        await this.broadcastMembers(room);
        return ok({ host: room.hostName, id: guest.id, role: 'guest', members: publicMembers(room), cursor: String(Date.now()) });
      }

      if (action === 'poll') {
        const me = String(url.searchParams.get('me') || '');
        if (!(room.members || []).some(m => m.id === me)) return fail(403, 'not_in_room');
        return await this.pollRoom(room, me, url.searchParams.get('since'), url.searchParams.get('fresh') === '1');
      }

      if (action === 'signal') {
        let body;
        try { body = await readJson(request); }
        catch (err) {
          return fail(400, err.message === 'body_too_large' ? 'body_too_large' : 'bad_json');
        }
        if (!body.payload || typeof body.payload !== 'object') return fail(400, 'bad_signal');
        const from = String(body.from || '');
        if (!(room.members || []).some(m => m.id === from)) return fail(403, 'not_in_room');
        const target = String(url.searchParams.get('to') || '');
        const to = target === 'broadcast' ? 'broadcast' : target;
        if (to !== 'broadcast' && !(room.members || []).some(m => m.id === to)) return fail(400, 'bad_target');
        return await this.saveSignal(room, to, body);
      }

      return fail(400, 'bad_action');
    } catch (err) {
      console.error('[room]', err);
      return fail(503, 'db_unavailable');
    }
  }
}

async function forwardRoom(env, id, url, request) {
  try {
    return await env.ROOMS.get(id).fetch(new Request(url, request));
  } catch (err) {
    const message = String(err && err.message || err || '');
    if (/Exceeded allowed volume of requests in Durable Objects free tier/i.test(message)) {
      return fail(503, 'quota_exceeded');
    }
    throw err;
  }
}

async function roomRequest(request, env) {
  const url = new URL(request.url);
  const action = url.searchParams.get('action') || '';
  let code = normalizeCode(url.searchParams.get('code'));

  if (action === 'create' && !code) {
    for (let attempt = 0; attempt < 8; attempt++) {
      code = newCode();
      const createUrl = new URL(url);
      createUrl.searchParams.set('code', code);
      const id = env.ROOMS.idFromName(code);
      const result = await forwardRoom(env, id, createUrl, request);
      if (result.status !== 409) return result;
    }
    return fail(503, 'code_exhausted');
  }

  if (!code) return fail(400, 'bad_code');
  url.searchParams.set('code', code);
  const id = env.ROOMS.idFromName(code);
  return forwardRoom(env, id, url, request);
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === '/room' || url.pathname === '/room/') return roomRequest(request, env);
    return env.ASSETS.fetch(request);
  },
};




