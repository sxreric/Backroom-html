// 后室 · 联机网络层：信令走 room.php（和火箭发射共用后端与房号段），接通后游戏消息和语音全部 P2P（WebRTC）
// 只管建连、收发、麦克风；hello 校验、同步、UI 都在 coop.js。接口：
//   BR.net.on(fn(type, data)) → 取消订阅
//     'status' 文案 | 'peerJoined' 对方昵称 | 'connected' | 'disconnected' { reason, wasConnected }
//     'peerLeft' | 'msg' 对方消息（除 bye 外全部） | 'error' { code, text, fatal }
//     'remoteStream' / 'localStream' MediaStream | 'mic' bool（麦克风被系统收回时）
//   createRoom(name) → 房号；joinRoom(code, name) → 房主昵称；roomInfo(code) → { state, host_name, guest_name }
//   send(obj, { lossy }) → bool；setMic(on) → Promise<bool>；leave()；errorText(code)（按微信/QQ、iOS 调整文案）
//   remotePaused：对方语音的 <audio> 有流但被自动播放策略拦着没播；pagehide 时也会发 'disconnected' { reason: 'closed' }
//   语音：建连时就协商一条收发音频的通道（不带轨道），开麦时才申请麦克风并 replaceTrack，不必重新协商
(function () {
'use strict';
const BR = window.BR;

const API_TIMEOUT_MS = 8000;
const POLL_MS = 1200;
const RELAY_POLL_MS = 1000;          // 仅在 WebSocket 不可用时备用；正常游戏中继不再轮询 Durable Object
const STATUS_MS = 1500;
const MAX_API_FAILS = 8;          // 连续失败这么多次（约 10 秒）就认定服务器不可达，停下来报错，不无限转圈
const CONNECT_TIMEOUT_MS = 15000; // 兼容保留：若回退到 P2P，15 秒后切网页中继
const USE_WEB_RELAY = true;          // 多人房间统一走 Durable Object 网页中继，最多 5 人，避免点对点一对一限制
const DISC_GRACE_MS = 6000;       // disconnected 常是网络抖动，宽限期内恢复就不算断线
const MAX_RECONNECTS = 3;          // 首次 ICE 失败后保留房间并自动重建 3 次
const RECONNECT_GAP_MS = 1200;     // 重试间隔逐次增加，给浏览器时间释放旧连接
const MIC_TIMEOUT_MS = 20000;     // 部分内嵌浏览器权限弹窗不出现，Promise 会一直悬着
const LOSSY_BUFFER = 256 * 1024;  // 高频位置/快照在通道积压时直接丢，免得延迟越滚越大
const HINT_KEY = 'backrooms_net_hint';
const MAX_NAME = 16;               // 与 room.php 的截断长度一致

// 国内访问不到 Google STUN，放一个国内可达的在前
const DEFAULT_ICE = [
  { urls: 'stun:stun.miwifi.com:3478' },
  { urls: ['stun:stun.l.google.com:19302', 'stun:stun1.l.google.com:19302'] },
  { urls: 'stun:stun.cloudflare.com:3478' },
];

const N = {
  gen: 0,             // 每次 teardown 自增：旧连接的异步回调靠它发现自己已过期
  active: false, connected: false,
  role: null, code: null, myName: '', peerName: '', peerId: '', members: [], peerJoined: false,
  pc: null, dc: null, stateDc: null, audioTx: null,
  pollTimer: 0, statusTimer: 0, connectTimer: 0, discTimer: 0, retryTimer: 0, relayRetryTimer: 0, relaySocket: null, relayOpening: false, retryCount: 0, retrying: false,
  relay: false, relayLast: new Map(),
  since: 0, fresh: true, pendingIce: [], seenSignals: new Set(), offerSent: false,
  localStream: null, micTrack: null, micOn: false, micWant: false, micPending: null,
  remoteStream: null, remoteAudio: null,
  voicePeers: new Map(),
};
const listeners = new Set();

// ---------- 小工具 ----------
function emit(type, data) {
  for (const fn of Array.from(listeners)) {
    try { fn(type, data); } catch (err) { console.error('[net] 事件处理出错', type, err); }
  }
}
function netError(code, detail) {
  const e = new Error(code);
  e.code = code;
  if (detail) e.detail = detail;
  return e;
}
function cleanName(name) {
  const s = String(name == null ? '' : name).trim().slice(0, MAX_NAME);
  return s || '匿名流浪者';
}
function normCode(code) { return String(code == null ? '' : code).toUpperCase().replace(/[^A-Z0-9]/g, ''); }
function signalUrl() { return (BR.config && BR.config.roomApi) || ''; }
function iceServers() {
  const c = BR.config && BR.config.iceServers;
  return Array.isArray(c) && c.length ? c : DEFAULT_ICE;
}
function stopStream(s) {
  if (!s) return;
  try { s.getTracks().forEach(t => t.stop()); } catch (err) { /* 已经停了 */ }
}

const ERROR_TEXT = {
  no_api: '没有配置联机服务器地址（BR.config.roomApi）。',
  unreachable: '连不上联机服务器（房间号接口不可达）。请检查网络后重试；如果是双击打开的本地文件，服务器会拒绝跨域请求，请用网页地址打开游戏。',
  timeout: '联机服务器响应超时，请稍后重试。',
  bad_response: '联机服务器返回了无法识别的内容，请稍后重试。',
  db_unavailable: '联机服务器暂时故障（数据库不可用），请稍后再试。',
  quota_exceeded: '联机服务器今日免费额度已用完，Cloudflare 会在每日 00:00 UTC 自动恢复；请稍后刷新页面。',
  bad_code: '房号应为 6 位字母或数字。',
  room_not_found: '房间不存在，请核对房号。',
  room_full: '房间已满，已经有人加入了。',
  room_closed: '房间已关闭。',
  code_exhausted: '服务器暂时分配不出房号，请重试。',
  no_webrtc: '当前浏览器不支持 WebRTC，无法联机。请换用新版 Chrome / Edge / Safari。',
  p2p_failed: '和对方的点对点连接没有建立起来（常见于公司/校园网或运营商 NAT 限制）。请重试，或换个网络（比如手机热点）。',
  lost: '和对方的连接断开了。',
  closed: '连接已关闭。',
  mic_noconn: '还没和对方连上，暂时不能开麦。',
  mic_denied: '麦克风权限被拒绝。请在浏览器地址栏左侧的站点设置里允许使用麦克风，然后再点开麦。',
  mic_notfound: '没有找到可用的麦克风设备。',
  mic_busy: '麦克风被其他程序占用，打不开。',
  mic_insecure: '浏览器只允许在 https 或 localhost 页面使用麦克风，当前页面地址不满足。',
  mic_unsupported: '当前浏览器不支持联机语音。',
  mic_relay: '多人语音连接还没有建立，请稍后再试。',
  mic_timeout: '麦克风权限请求没有响应，请检查浏览器是否拦截了权限弹窗。',
  mic_failed: '打开麦克风失败。',
};
// 微信 / QQ 内置浏览器没有地址栏，这几类问题的出路是换到系统浏览器
const IN_APP_CODES = { no_webrtc: 1, mic_unsupported: 1, mic_denied: 1 };
function inAppBrowser() { return /MicroMessenger|QQ\//i.test(navigator.userAgent || ''); }
// iPadOS 默认发桌面 UA（Macintosh），靠多点触控区分
function isIOS() {
  const ua = navigator.userAgent || '';
  return /iPhone|iPad|iPod/.test(ua) || (/Macintosh/.test(ua) && navigator.maxTouchPoints > 1);
}
function errorText(code) {
  if (!code) return '联机出错。';
  if (ERROR_TEXT[code]) {
    const inApp = inAppBrowser();
    let t = ERROR_TEXT[code];
    if (code === 'mic_denied') {
      // 默认文案按桌面 Chrome 写的；内置浏览器的权限归宿主应用管，iOS Safari 的入口不在地址栏左侧
      if (inApp) t = '麦克风权限被拒绝。请在系统设置里允许微信 / QQ 使用麦克风，然后再点开麦。';
      else if (isIOS()) t = '麦克风权限被拒绝。请在 Safari 的网站设置里允许使用麦克风（或到系统设置里的 Safari → 麦克风），然后再点开麦。';
    }
    if (inApp && IN_APP_CODES[code]) t += '可点右上角「…」选择「在浏览器打开」。';
    return t;
  }
  if (/^http_\d+$/.test(code)) return '联机服务器出错（HTTP ' + code.slice(5) + '），请稍后再试。';
  return '联机出错：' + code;
}

// ---------- room.php ----------
function api(action, params, body) {
  const base = signalUrl();
  if (!base) return Promise.reject(netError('no_api'));
  let url;
  try { url = new URL(base, location.href); } catch (err) { return Promise.reject(netError('no_api')); }
  url.searchParams.set('action', action);
  for (const k in (params || {})) url.searchParams.set(k, params[k]);
  const opt = body
    ? { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }
    : { method: action === 'status' || action === 'poll' ? 'GET' : 'POST' };
  const ctl = typeof AbortController === 'function' ? new AbortController() : null;
  if (ctl) opt.signal = ctl.signal;

  let timer = 0;
  const timeout = new Promise((_, rej) => {
    timer = setTimeout(() => { if (ctl) ctl.abort(); rej(netError('timeout')); }, API_TIMEOUT_MS);
  });
  const run = (async () => {
    let r;
    try { r = await fetch(url.toString(), opt); }
    catch (err) { throw netError('unreachable', err && err.message); }   // DNS、断网、CORS 拒绝都长这样
    const d = await r.json().catch(() => null);
    if (!d) throw netError(r.ok ? 'bad_response' : 'http_' + r.status);
    if (!d.ok) throw netError(d.error || 'http_' + r.status);
    return d;
  })();
  run.catch(() => {});   // 超时先赢时，被 abort 的请求别变成未处理的 rejection
  return Promise.race([run, timeout]).finally(() => clearTimeout(timer));
}

function sendSignal(payload) {
  if (N.relay) return Promise.resolve(true);
  const to = N.role === 'host' ? 'guest' : 'host';
  return api('signal', { code: N.code, to }, { from: N.peerId, payload });
}

// 服务器连续不可达：停下来明确报错，而不是让界面一直显示"连接中"

function relayWsUrl() {
  const base = signalUrl();
  const u = new URL(base, location.href);
  u.protocol = u.protocol === 'https:' ? 'wss:' : 'ws:';
  u.searchParams.set('action', 'ws');
  u.searchParams.set('code', N.code);
  u.searchParams.set('me', N.peerId);
  return u.toString();
}

function relayAnnounce(reason) {
  if (!N.active || !N.relay || N.connected) return;
  N.connected = true;
  stopPolling();
  emit('connected');
  emit('status', reason === 'relay_first'
    ? '已进入网页中继房间。'
    : '网页中继已恢复。');
}

function onRelaySocketMessage(e, gen) {
  if (gen !== N.gen) return;
  let packet;
  try { packet = JSON.parse(e.data); } catch (err) { return; }
  if (!packet || typeof packet !== 'object') return;
  if (packet.t === 'relay' && packet.m && typeof packet.m === 'object') {
    const inner = packet.from && !packet.m._from
      ? Object.assign({}, packet.m, { _from: String(packet.from) }) : packet.m;
    handlePeerMessage(inner);
    return;
  }
  handlePeerMessage(packet);
}

function openRelaySocket(reason) {
  if (!N.active || !N.relay || N.relaySocket || N.relayOpening) return false;
  if (typeof WebSocket !== 'function') {
    startPolling();
    relayAnnounce(reason);
    return false;
  }
  let url;
  try { url = relayWsUrl(); } catch (err) { startPolling(); relayAnnounce(reason); return false; }
  const gen = N.gen;
  let ws;
  try { ws = new WebSocket(url); } catch (err) { startPolling(); relayAnnounce(reason); return false; }
  N.relayOpening = true;
  N.relaySocket = ws;
  ws.onopen = () => {
    if (gen !== N.gen || !N.active || !N.relay) { try { ws.close(); } catch (err) {} return; }
    N.relayOpening = false;
    relayAnnounce(reason);
    syncVoiceMembers(N.members);
  };
  ws.onmessage = e => onRelaySocketMessage(e, gen);
  ws.onerror = () => {};
  ws.onclose = e => {
    if (gen !== N.gen || !N.active || !N.relay) return;
    if (N.relaySocket === ws) N.relaySocket = null;
    N.relayOpening = false;
    const wasConnected = N.connected;
    N.connected = false;
    closeVoicePeers();
    // 房主主动关闭联机时，服务器会用这个原因关闭所有客机；不要再把已经不存在的房间无限重连。
    if (e && e.code === 1000 && e.reason === 'room_closed') {
      teardown(false);
      emit('disconnected', { reason: 'room_closed', wasConnected });
      return;
    }
    if (N.relayRetryTimer) clearTimeout(N.relayRetryTimer);
    N.relayRetryTimer = setTimeout(() => {
      N.relayRetryTimer = 0;
      if (gen === N.gen && N.active && N.relay) openRelaySocket('relay_retry');
    }, 1200);
  };
  return true;
}
function fatal(err) {
  const code = (err && err.code) || 'unreachable';
  teardown(true);
  emit('error', { code, text: errorText(code), fatal: true });
}

// 带失败计数的轮询；busy 防止慢服务器上请求叠加
function loop(ms, gen, fn) {
  let busy = false, fails = 0;
  return setInterval(async () => {
    if (busy || gen !== N.gen) return;
    busy = true;
    try {
      await fn();
      fails = 0;
    } catch (err) {
      if (gen !== N.gen) return;
      if (err && err.code === 'room_not_found' || err && err.code === 'room_closed') { fatal(err); return; }
      fails++;
      if (fails === 2) emit('status', '房间服务暂时没有回应，继续重试…');
      if (fails >= MAX_API_FAILS) fatal(err);
    } finally {
      busy = false;
    }
  }, ms);
}

function startPolling() {
  stopPolling();
  const gen = N.gen;
  N.pollTimer = loop(N.relay ? RELAY_POLL_MS : POLL_MS, gen, async () => {
    const params = { code: N.code, me: N.peerId || N.role, since: N.since };
    if (N.fresh) params.fresh = '1';
    const d = await api('poll', params);
    if (gen !== N.gen) return;
    N.since = d.last;
    N.fresh = false;
    for (const m of (d.msgs || [])) {
      if (gen !== N.gen) return;
      // SDP 出错不算网络失败，记日志继续
      try { await onSignal(m); } catch (err) { console.warn('[net] 处理信令出错', m && m.t, err); }
    }
    // 不因 DataChannel 短暂 connected 就停信令轮询。直连失败后，轮询还要负责重连、切中继和补发 ICE。
  });
}
function stopPolling() { if (N.pollTimer) { clearInterval(N.pollTimer); N.pollTimer = 0; } }

function startStatusWait() {
  stopStatusWait();
  const gen = N.gen;
  N.statusTimer = loop(STATUS_MS, gen, async () => {
    const s = await api('status', { code: N.code });
    if (gen !== N.gen) return;
    if (s.state === 'joined') onGuestJoined(s.guest_name);
    else if (s.state === 'closed') throw netError('room_closed');
  });
}
function stopStatusWait() { if (N.statusTimer) { clearInterval(N.statusTimer); N.statusTimer = 0; } }

// ---------- WebRTC ----------
function setupPeer(isHost) {
  if (typeof RTCPeerConnection !== 'function') return false;
  const gen = N.gen;
  const pc = new RTCPeerConnection({ iceServers: iceServers() });
  N.pc = pc;
  pc.onicecandidate = e => {
    if (e.candidate && gen === N.gen) sendSignal({ t: 'ice', c: e.candidate }).catch(() => {});
  };
  pc.onconnectionstatechange = () => { if (gen === N.gen) onPcState(); };
  pc.oniceconnectionstatechange = () => { if (gen === N.gen) onPcState(); };   // 老 Firefox 没有 connectionState
  pc.ontrack = e => { if (gen === N.gen) attachRemote(e); };
  if (isHost) {
    // 先占一条收发音频的通道：之后开麦用 replaceTrack 填轨道，不必重新协商
    try { N.audioTx = pc.addTransceiver('audio', { direction: 'sendrecv' }); } catch (err) { N.audioTx = null; }
    bindChannel(pc.createDataChannel('game', { ordered: true }));
    try { bindStateChannel(pc.createDataChannel('state', { ordered: false, maxRetransmits: 0 })); } catch (err) { /* 浏览器不支持不可靠通道时回退可靠通道 */ }
  } else {
    pc.ondatachannel = e => { if (gen === N.gen) {
      if (e.channel && e.channel.label === 'state') bindStateChannel(e.channel);
      else bindChannel(e.channel);
    } }
  }
  return true;
}

function activateRelay(reason) {
  if (!N.active || N.relay || N.connected) return false;
  const pc = N.pc, dc = N.dc, stateDc = N.stateDc;
  ++N.gen;
  stopPolling();
  stopStatusWait();
  if (N.connectTimer) { clearTimeout(N.connectTimer); N.connectTimer = 0; }
  if (N.discTimer) { clearTimeout(N.discTimer); N.discTimer = 0; }
  if (N.retryTimer) { clearTimeout(N.retryTimer); N.retryTimer = 0; }
  if (dc) { dc.onopen = dc.onclose = dc.onmessage = null; try { dc.close(); } catch (err) { /* 已关闭 */ } }
  if (stateDc) { stateDc.onopen = stateDc.onclose = stateDc.onmessage = null; try { stateDc.close(); } catch (err) { /* 已关闭 */ } }
  if (pc) {
    pc.onicecandidate = pc.ontrack = pc.onconnectionstatechange = pc.oniceconnectionstatechange = pc.ondatachannel = null;
    try { pc.close(); } catch (err) { /* 已关闭 */ }
  }
  N.pc = null;
  N.dc = null;
  N.stateDc = null;
  N.audioTx = null;
  N.pendingIce = [];
  N.offerSent = false;
  N.retryCount = 0;
  N.retrying = false;
  N.relay = true;
  N.connected = false;
  N.relayLast.clear();
  openRelaySocket(reason);
  return true;
}
function retryPeer(reason) {
  if (!N.active || N.retrying) return;
  if (!N.connected) { activateRelay(reason || 'p2p_failed'); return; }
  if (N.retryCount >= MAX_RECONNECTS) {
    lost(reason || 'p2p_failed');
    return;
  }
  N.retryCount++;
  N.retrying = true;
  const token = ++N.gen;
  const role = N.role;
  const pc = N.pc, dc = N.dc, stateDc = N.stateDc;
  stopPolling();
  if (N.connectTimer) { clearTimeout(N.connectTimer); N.connectTimer = 0; }
  if (N.discTimer) { clearTimeout(N.discTimer); N.discTimer = 0; }
  if (dc) { dc.onopen = dc.onclose = dc.onmessage = null; try { dc.close(); } catch (err) { /* 已关闭 */ } }
  if (stateDc) { stateDc.onopen = stateDc.onclose = stateDc.onmessage = null; try { stateDc.close(); } catch (err) { /* 已关闭 */ } }
  if (pc) {
    pc.onicecandidate = pc.ontrack = pc.onconnectionstatechange = pc.oniceconnectionstatechange = pc.ondatachannel = null;
    try { pc.close(); } catch (err) { /* 已关闭 */ }
  }
  N.pc = null;
  N.dc = null;
  N.stateDc = null;
  N.audioTx = null;
  N.pendingIce = [];
  N.offerSent = false;
  N.connected = false;
  emit('status', '点对点连接中断，正在自动重试（' + N.retryCount + '/' + MAX_RECONNECTS + '）…');
  const wait = RECONNECT_GAP_MS * N.retryCount;
  N.retryTimer = setTimeout(() => {
    N.retryTimer = 0;
    if (token !== N.gen || !N.active) return;
    N.retrying = false;
    try {
      setupPeer(role === 'host');
      startPolling();
      armConnectTimeout();
      if (role === 'host') hostOffer();
      else sendSignal({ t: 'joined', name: N.myName }).catch(() => {});
    } catch (err) {
      retryPeer('p2p_failed');
    }
  }, wait);
}
function onPcState() {
  const pc = N.pc;
  if (!pc) return;
  const st = pc.connectionState || pc.iceConnectionState;
  const iceFailed = pc.iceConnectionState === 'failed';
  const iceDisconnected = pc.iceConnectionState === 'disconnected';
  if (st === 'connected' || st === 'completed') {
    if (N.discTimer) { clearTimeout(N.discTimer); N.discTimer = 0; }
  } else if (st === 'failed' || iceFailed) {
    retryPeer(N.connected ? 'lost' : 'p2p_failed');
  } else if ((st === 'disconnected' || iceDisconnected) && N.connected && !N.discTimer) {
    const gen = N.gen;
    N.discTimer = setTimeout(() => {
      N.discTimer = 0;
      if (gen !== N.gen || !N.pc) return;
      const s = N.pc.connectionState || N.pc.iceConnectionState;
      if (s === 'disconnected' || s === 'failed') retryPeer('lost');
    }, DISC_GRACE_MS);
  }
}

function parseChannelMessage(e, gen) {
  if (gen !== N.gen) return;
  let m;
  try { m = JSON.parse(e.data); } catch (err) { return; }
  if (m && typeof m === 'object') handlePeerMessage(m);
}

function bindChannel(dc) {
  const gen = N.gen;
  N.dc = dc;
  dc.onopen = () => {
    if (gen !== N.gen) return;
    N.connected = true;
    N.retryCount = 0;
    N.retrying = false;
    if (N.retryTimer) { clearTimeout(N.retryTimer); N.retryTimer = 0; }
    if (N.connectTimer) { clearTimeout(N.connectTimer); N.connectTimer = 0; }
    stopStatusWait();
    emit('connected');
  };
  dc.onclose = () => { if (gen === N.gen && N.active) retryPeer(N.connected ? 'lost' : 'p2p_failed'); };
  dc.onmessage = e => parseChannelMessage(e, gen);
}

// 高频位置 / 实体快照使用无序、零重传通道：丢一个旧位置不能阻塞后面的新位置。
function bindStateChannel(dc) {
  const gen = N.gen;
  N.stateDc = dc;
  dc.onopen = () => { if (gen === N.gen) N.stateDc = dc; };
  dc.onclose = () => { if (gen === N.gen && N.stateDc === dc) N.stateDc = null; };
  dc.onmessage = e => parseChannelMessage(e, gen);
}
// 游戏语义全交给 coop.js；bye 在这一层处理，免得随后的通道关闭再报一次断线
// ---------- 多人网页中继语音 ----------
// 游戏状态走 WebSocket 中继；语音仍用每个玩家之间的一条小型 WebRTC 音频连接。
// 这样 5 人房不需要服务器转发音频，也不会因为中继模式直接禁用麦克风。
function voiceAudioPlay(a) {
  if (!a || !a.srcObject || !a.paused) return;
  try { const p = a.play(); if (p && typeof p.catch === 'function') p.catch(() => {}); }
  catch (err) { /* 自动播放策略拦截，下一次用户手势会重试 */ }
}
function closeVoicePeer(id) {
  id = String(id || '');
  const v = N.voicePeers.get(id);
  if (!v) return;
  N.voicePeers.delete(id);
  if (v.pc) {
    v.pc.onicecandidate = v.pc.ontrack = v.pc.onconnectionstatechange = null;
    try { v.pc.close(); } catch (err) { /* 已关闭 */ }
  }
  if (v.audio) {
    try { v.audio.pause(); } catch (err) {}
    v.audio.srcObject = null;
    if (v.audio.parentNode) v.audio.parentNode.removeChild(v.audio);
  }
}
function closeVoicePeers() {
  for (const id of Array.from(N.voicePeers.keys())) closeVoicePeer(id);
  N.voicePeers.clear();
}
function voiceSignal(to, body) {
  if (!N.relay || !to || !body) return false;
  return send(Object.assign({ t: 'voice', to: String(to) }, body));
}
function attachVoiceRemote(id, e) {
  if (!e || !e.track || e.track.kind !== 'audio') return;
  const v = N.voicePeers.get(String(id));
  if (!v) return;
  let stream = e.streams && e.streams[0];
  if (!stream && typeof MediaStream === 'function') stream = new MediaStream([e.track]);
  if (!stream) return;
  if (!v.audio) {
    const a = document.createElement('audio');
    a.autoplay = true;
    a.setAttribute('playsinline', '');
    a.style.display = 'none';
    document.body.appendChild(a);
    v.audio = a;
  }
  v.audio.srcObject = stream;
  voiceAudioPlay(v.audio);
  emit('remoteStream', stream);
}
function replaceVoiceTrack(track) {
  const jobs = [];
  for (const v of N.voicePeers.values()) {
    const tx = v.tx || (v.pc && v.pc.getSenders && v.pc.getSenders().find(s => s.track && s.track.kind === 'audio'));
    if (!tx || typeof tx.replaceTrack !== 'function') continue;
    v.tx = tx;
    jobs.push(Promise.resolve(tx.replaceTrack(track)).catch(() => {}));
  }
  return Promise.all(jobs);
}
function ensureVoicePeer(id) {
  id = String(id || '');
  if (!id || id === String(N.peerId || '') || typeof RTCPeerConnection !== 'function') return null;
  let v = N.voicePeers.get(id);
  if (v) return v;
  let pc;
  try { pc = new RTCPeerConnection({ iceServers: iceServers() }); }
  catch (err) { return null; }
  v = { id, pc, tx: null, ice: [], offered: false, audio: null };
  N.voicePeers.set(id, v);
  try { v.tx = pc.addTransceiver('audio', { direction: 'sendrecv' }); } catch (err) { v.tx = null; }
  const gen = N.gen;
  pc.onicecandidate = e => {
    if (gen === N.gen && e.candidate) voiceSignal(id, { kind: 'ice', candidate: e.candidate });
  };
  pc.ontrack = e => { if (gen === N.gen) attachVoiceRemote(id, e); };
  pc.onconnectionstatechange = () => {
    const state = pc.connectionState || pc.iceConnectionState;
    if (state !== 'failed' && state !== 'closed') return;
    closeVoicePeer(id);
    if (gen === N.gen && N.active && N.relay) setTimeout(() => syncVoiceMembers(N.members), 800);
  };
  if (N.micTrack && N.micTrack.readyState === 'live') replaceVoiceTrack(N.micTrack);
  return v;
}
async function flushVoiceIce(v) {
  const pending = v.ice.splice(0);
  for (const c of pending) {
    try { await v.pc.addIceCandidate(c); } catch (err) { /* 过期候选 */ }
  }
}
async function voiceOffer(id) {
  const v = N.voicePeers.get(String(id));
  if (!v || v.offered || !N.relay || !N.connected || !N.relaySocket || N.relaySocket.readyState !== 1) return;
  // 只让 id 较小的一方发 offer，避免两边同时协商导致语音连接卡在 have-local-offer。
  if (String(N.peerId).localeCompare(String(id)) >= 0) return;
  v.offered = true;
  try {
    const offer = await v.pc.createOffer();
    if (N.relaySocket && N.relaySocket.readyState === 1) {
      await v.pc.setLocalDescription(offer);
      voiceSignal(id, { kind: 'offer', sdp: v.pc.localDescription || offer });
    }
  } catch (err) {
    v.offered = false;
    console.warn('[net] 多人语音 offer 失败', err);
  }
}
async function onVoiceSignal(m) {
  if (!N.relay || !m || !m._from || (m.to && String(m.to) !== String(N.peerId))) return;
  const id = String(m._from);
  const v = ensureVoicePeer(id);
  if (!v) return;
  try {
    if (m.kind === 'ice' && m.candidate) {
      if (v.pc.remoteDescription && v.pc.remoteDescription.type) {
        await v.pc.addIceCandidate(m.candidate);
      } else v.ice.push(m.candidate);
      return;
    }
    if (m.kind === 'offer' && m.sdp) {
      if (v.pc.signalingState !== 'stable') return;
      await v.pc.setRemoteDescription(m.sdp);
      await flushVoiceIce(v);
      const answer = await v.pc.createAnswer();
      await v.pc.setLocalDescription(answer);
      voiceSignal(id, { kind: 'answer', sdp: v.pc.localDescription || answer });
      if (N.micTrack) await replaceVoiceTrack(N.micTrack);
      return;
    }
    if (m.kind === 'answer' && m.sdp && v.pc.signalingState === 'have-local-offer') {
      await v.pc.setRemoteDescription(m.sdp);
      await flushVoiceIce(v);
      if (N.micTrack) await replaceVoiceTrack(N.micTrack);
    }
  } catch (err) {
    console.warn('[net] 多人语音信令失败', id, err);
  }
}
function syncVoiceMembers(list) {
  if (!N.relay || !N.active || typeof RTCPeerConnection !== 'function') return;
  const ids = new Set((Array.isArray(list) ? list : []).map(m => m && String(m.id || '')).filter(id => id && id !== String(N.peerId || '')));
  for (const id of Array.from(N.voicePeers.keys())) if (!ids.has(id)) closeVoicePeer(id);
  for (const id of ids) ensureVoicePeer(id);
  if (!N.connected || !N.relaySocket || N.relaySocket.readyState !== 1) return;
  for (const id of ids) voiceOffer(id);
}

function handlePeerMessage(m) {
  if (m.t === 'voice') {
    onVoiceSignal(m);
    return;
  }
  if (m.t === 'bye') {
    teardown(false);
    emit('peerLeft');
    return;
  }
  if (m.t === 'peerLeft') {
    emit('peerLeft', m);
    return;
  }
  if (m.t === 'members' && Array.isArray(m.members)) {
    const wasJoined = N.peerJoined;
    N.members = m.members.slice();
    const host = N.members.find(x => x && x.role === 'host');
    const guests = N.members.filter(x => x && x.role === 'guest');
    if (host && N.role === 'guest') N.peerName = cleanName(host.name || '房主');
    if (N.role === 'host') N.peerName = guests.length ? cleanName(guests[0].name || '对方') : '';
    N.peerJoined = guests.length > 0;
    const key = N.members.map(x => String(x && x.id || '') + ':' + String(x && x.name || '')).join('|');
    const changed = key !== N.memberKey;
    N.memberKey = key;
    if (guests.length) stopStatusWait();
    syncVoiceMembers(N.members);
    emit('members', N.members);
    if (N.role === 'host' && guests.length && !wasJoined) emit('peerJoined', { name: N.peerName, members: N.members });
    return;
  }
  emit('msg', m);
}

function lost(reason) {
  if (!N.active) return;
  const wasConnected = N.connected;
  teardown(false);
  emit('disconnected', { reason, wasConnected });
}

function armConnectTimeout() {
  if (N.connectTimer) clearTimeout(N.connectTimer);
  const gen = N.gen;
  N.connectTimer = setTimeout(() => {
    N.connectTimer = 0;
    if (gen === N.gen && !N.connected) retryPeer('p2p_failed');
  }, CONNECT_TIMEOUT_MS);
}

function attachRemote(e) {
  if (!e.track || e.track.kind !== 'audio') return;
  let stream = e.streams && e.streams[0];
  if (!stream && typeof MediaStream === 'function') stream = new MediaStream([e.track]);   // 对端 transceiver 没绑 stream
  if (!stream) return;
  N.remoteStream = stream;
  if (!N.remoteAudio) {
    const a = document.createElement('audio');
    a.autoplay = true;
    a.setAttribute('playsinline', '');
    N.remoteAudio = a;
  }
  N.remoteAudio.srcObject = stream;
  resumeAudio();
  emit('remoteStream', stream);
}

// 自动播放被拦时，coop 在下一次用户手势里再调一次
function resumeAudio() {
  const a = N.remoteAudio;
  if (a && a.srcObject) voiceAudioPlay(a);
  for (const v of N.voicePeers.values()) if (v.audio && v.audio.srcObject) voiceAudioPlay(v.audio);
}

async function flushIce() {
  const pc = N.pc, buf = N.pendingIce;
  N.pendingIce = [];
  for (const c of buf) { try { await pc.addIceCandidate(c); } catch (err) { /* 过期候选 */ } }
}

// 客机：把对方 offer 里的音频通道改成收发，应答里才会带上"我也会发"，之后开麦不用重新协商
function prepareGuestAudio(pc) {
  if (typeof pc.getTransceivers !== 'function') return;
  const tx = pc.getTransceivers().find(t => t.receiver && t.receiver.track && t.receiver.track.kind === 'audio');
  if (!tx) return;
  try { tx.direction = 'sendrecv'; N.audioTx = tx; } catch (err) { N.audioTx = null; }
}

async function onSignal(packet) {
  const wrapped = packet && packet.payload && packet.id ? packet : null;
  const id = wrapped ? String(wrapped.id) : '';
  const m = wrapped ? wrapped.payload : packet;
  if (id) {
    if (N.seenSignals.has(id)) return;
    N.seenSignals.add(id);
    if (N.seenSignals.size > 512) N.seenSignals.delete(N.seenSignals.values().next().value);
  }
  if (!m) return;
  if (m.t === 'relay') {
    if (m.m) {
      if (!N.relay && !N.connected) activateRelay('peer_relay');
      const inner = wrapped && wrapped.from && !m.m._from
        ? Object.assign({}, m.m, { _from: String(wrapped.from) })
        : m.m;
      handlePeerMessage(inner);
    }
    return;
  }
  const pc = N.pc;
  if (!pc) return;
  if (m.t === 'offer' && N.role === 'guest') {
    if (pc.remoteDescription && pc.remoteDescription.type) return;   // 重复投递
    await pc.setRemoteDescription(m.sdp);
    prepareGuestAudio(pc);
    await flushIce();
    const ans = await pc.createAnswer();
    await pc.setLocalDescription(ans);
    await sendSignal({ t: 'answer', sdp: ans });
  } else if (m.t === 'answer' && N.role === 'host') {
    if (!pc.currentRemoteDescription && pc.signalingState === 'have-local-offer') {
      await pc.setRemoteDescription(m.sdp);
      await flushIce();
    }
  } else if (m.t === 'ice') {
    // 远端描述还没设好时直接 add 会抛错，先缓冲
    if (pc.remoteDescription && pc.remoteDescription.type) {
      try { await pc.addIceCandidate(m.c); } catch (err) { /* 过期候选 */ }
    } else {
      N.pendingIce.push(m.c);
    }
  } else if (m.t === 'joined' && N.role === 'host') {
    onGuestJoined(m.name, m.members, m._from);
  }
}

// 状态轮询持续观察房间成员，网页中继房间最多 5 人
function onGuestJoined(name, members, fromId) {
  if (N.role !== 'host') return;
  let list = Array.isArray(members) ? members.slice() : N.members.slice();
  if (!list.some(m => m && m.id === N.peerId)) {
    list.unshift({ id: N.peerId, role: 'host', name: N.myName });
  }
  if (fromId && !list.some(m => m && m.id === String(fromId))) {
    list.push({ id: String(fromId), role: 'guest', name: cleanName(name || '对方') });
  }
  N.members = list;
  const guests = list.filter(m => m && m.role === 'guest');
  N.peerJoined = guests.length > 0;
  N.peerName = guests.length ? cleanName(guests[0].name || '对方') : '';
  const key = list.map(m => String(m.id) + ':' + String(m.name || '')).join('|');
  if (key !== N.memberKey) {
    N.memberKey = key;
    if (guests.length > 0) {
      emit('peerJoined', { name: N.peerName, members: list });
      if (N.relay) send({ t: 'members', members: list });
    }
  }
  if (!N.relay) {
    stopStatusWait();
    armConnectTimeout();
    hostOffer();
  }
}

async function hostOffer() {
  const pc = N.pc;
  if (!pc || N.offerSent || pc.signalingState !== 'stable') return;
  N.offerSent = true;
  const gen = N.gen;
  try {
    const offer = await pc.createOffer();
    if (gen !== N.gen) return;
    await pc.setLocalDescription(offer);
    await sendSignal({ t: 'offer', sdp: offer });
  } catch (err) {
    if (gen !== N.gen) return;
    N.offerSent = false;   // 允许下一次 status 轮询重试
    console.warn('[net] 发 offer 失败，稍后重试', err);
  }
}

// ---------- 麦克风 ----------
function micErrCode(err) {
  if (err && err.code) return err.code;
  const n = err && err.name;
  if (n === 'NotAllowedError' || n === 'PermissionDeniedError') return 'mic_denied';
  if (n === 'NotFoundError' || n === 'DevicesNotFoundError' || n === 'OverconstrainedError') return 'mic_notfound';
  if (n === 'NotReadableError' || n === 'TrackStartError' || n === 'AbortError') return 'mic_busy';
  if (n === 'SecurityError') return 'mic_insecure';
  return 'mic_failed';
}

async function ensureMic() {
  if (N.micTrack && N.micTrack.readyState === 'live') return N.micTrack;
  if (N.micPending) return N.micPending;
  const md = navigator.mediaDevices;
  if (!md || typeof md.getUserMedia !== 'function') {
    throw netError(window.isSecureContext === false ? 'mic_insecure' : 'mic_unsupported');
  }
  const gen = N.gen;
  N.micPending = (async () => {
    const gum = md.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true } });
    let timer = 0, timedOut = false;
    const timeout = new Promise((_, rej) => { timer = setTimeout(() => { timedOut = true; rej(netError('mic_timeout')); }, MIC_TIMEOUT_MS); });
    let stream;
    try {
      stream = await Promise.race([gum, timeout]);
    } catch (err) {
      // 超时后用户才点允许：拿到的流立刻停掉，别让录音指示灯亮着
      if (timedOut) gum.then(stopStream, () => {});
      throw netError(micErrCode(err));
    } finally {
      clearTimeout(timer);
    }
    if (gen !== N.gen) { stopStream(stream); throw netError('cancelled'); }
    const track = stream.getAudioTracks()[0];
    if (!track) { stopStream(stream); throw netError('mic_notfound'); }
    track.enabled = false;
    try {
      let attached = false;
      if (N.audioTx && N.audioTx.sender && typeof N.audioTx.sender.replaceTrack === 'function') {
        await N.audioTx.sender.replaceTrack(track);
        attached = true;
      }
      if (N.relay) {
        await replaceVoiceTrack(track);
        attached = true;
      }
      if (!attached) throw netError('mic_unsupported');
    } catch (err) {
      stopStream(stream);
      throw netError('mic_unsupported');
    }
    if (gen !== N.gen) { stopStream(stream); throw netError('cancelled'); }
    N.localStream = stream;
    N.micTrack = track;
    // 拔掉耳机麦、系统收回权限：轨道结束，界面要跟着变回闭麦
    track.onended = () => {
      if (N.micTrack !== track) return;
      N.micTrack = null;
      N.localStream = null;
      N.micOn = false;
      emit('mic', false);
    };
    emit('localStream', stream);
    return track;
  })();
  try { return await N.micPending; } finally { N.micPending = null; }
}

// 开麦/闭麦切换：只启用/禁用音轨，流保留到退出联机，免得每次开麦都重新弹权限
async function setMic(on) {
  on = !!on;
  N.micWant = on;
  if (!on) {
    N.micOn = false;
    if (N.micTrack) N.micTrack.enabled = false;
    return false;
  }
  if (!N.active || !N.connected) throw netError('mic_noconn');
  if (!N.relay && (!N.pc || !N.audioTx || !N.audioTx.sender || typeof N.audioTx.sender.replaceTrack !== 'function')) throw netError('mic_unsupported');
  const track = await ensureMic();
  // 等权限期间可能已经点了闭麦
  if (!N.micWant || track !== N.micTrack) { track.enabled = false; N.micOn = false; return false; }
  track.enabled = true;
  N.micOn = true;
  return true;
}

// ---------- 收发与生命周期 ----------
function send(obj, opts) {
  if (N.relay) {
    const key = obj && obj.t ? String(obj.t) : 'message';
    const now = Date.now();
    if (opts && opts.lossy) {
      // Durable Objects 会按 WebSocket 消息计费。远端位置包保留速度和时间戳，
      // 客户端会在两次快照之间预测/插值，所以不需要把 20Hz 全部送到服务器。
      const gap = key === 'me' ? 65 : (key === 'ents' ? 140 : 120);
      const prev = N.relayLast.get(key) || 0;
      if (now - prev < gap) return true;
      N.relayLast.set(key, now);
    }
    const ws = N.relaySocket;
    if (!ws || ws.readyState !== 1) return false;
    try { ws.send(JSON.stringify({ t: 'relay', m: obj })); return true; } catch (err) { return false; }
  }
  const dc = opts && opts.lossy && N.stateDc && N.stateDc.readyState === 'open' ? N.stateDc : N.dc;
  if (!dc || dc.readyState !== 'open') return false;
  if (opts && opts.lossy && dc.bufferedAmount > LOSSY_BUFFER) return false;
  try { dc.send(JSON.stringify(obj)); return true; } catch (err) { return false; }
}

function teardown(sendBye) {
  N.gen++;
  const pc = N.pc, dc = N.dc, stateDc = N.stateDc, relaySocket = N.relaySocket, code = N.code, wasActive = N.active;
  let byeSent = false;
  if (sendBye && dc && dc.readyState === 'open') {
    try { dc.send(JSON.stringify({ t: 'bye' })); byeSent = true; } catch (err) { /* 通道已坏 */ }
  }
  stopPolling();
  stopStatusWait();
  if (N.connectTimer) clearTimeout(N.connectTimer);
  if (N.discTimer) clearTimeout(N.discTimer);
  if (N.retryTimer) clearTimeout(N.retryTimer);
  if (dc) { dc.onopen = dc.onclose = dc.onmessage = null; }
  if (stateDc) { stateDc.onopen = stateDc.onclose = stateDc.onmessage = null; }
  if (N.relayRetryTimer) { clearTimeout(N.relayRetryTimer); N.relayRetryTimer = 0; }
  if (relaySocket) { relaySocket.onopen = relaySocket.onclose = relaySocket.onmessage = null; try { relaySocket.close(); } catch (err) { /* 已关闭 */ } }
  if (pc) {
    pc.onicecandidate = pc.ontrack = pc.onconnectionstatechange = pc.oniceconnectionstatechange = pc.ondatachannel = null;
  }
  // 立刻关 pc 会丢掉还在缓冲里的 bye，稍等一下再关
  const closeAll = () => {
    try { if (dc) dc.close(); } catch (err) { /* 已关闭 */ }
    try { if (stateDc) stateDc.close(); } catch (err) { /* 已关闭 */ }
    try { if (pc) pc.close(); } catch (err) { /* 已关闭 */ }
  };
  if (byeSent) setTimeout(closeAll, 200); else closeAll();
  closeVoicePeers();
  stopStream(N.localStream);
  if (N.remoteAudio) {
    try { N.remoteAudio.pause(); } catch (err) { /* 忽略 */ }
    N.remoteAudio.srcObject = null;
  }
  if (code && wasActive) api('close', { code }).catch(() => {});
  Object.assign(N, {
    active: false, connected: false, role: null, code: null, peerName: '', peerId: '', members: [], peerJoined: false,
    pc: null, dc: null, stateDc: null, audioTx: null, connectTimer: 0, discTimer: 0, retryTimer: 0, retryCount: 0, retrying: false,
    relay: false, relayLast: new Map(), relaySocket: null, relayOpening: false, voicePeers: new Map(),
    since: 0, fresh: true, pendingIce: [], seenSignals: new Set(), offerSent: false, relayRetryTimer: 0,
    localStream: null, micTrack: null, micOn: false, micWant: false, micPending: null, remoteStream: null,
  });
  clearHint();
}

async function createRoom(name) {
  if (N.active) teardown(true);
  // 和 joinRoom 一样先查：不然会先在服务器上建好房，到 setupPeer 才失败再关房
  const canP2P = typeof RTCPeerConnection === 'function';
  const gen = N.gen;
  N.myName = cleanName(name);
  const d = await api('create', {}, { name: N.myName });
  if (gen !== N.gen) {
    api('close', { code: d.code }, { id: d.id }).catch(() => {});   // 等待期间点了取消：服务器上的空房顺手关掉
    throw netError('cancelled');
  }
  Object.assign(N, { code: d.code, role: 'host', active: true, connected: false, since: Number(d.cursor) || Date.now(), fresh: true,
    offerSent: false, pendingIce: [], peerName: '', peerId: String(d.id || ''), members: Array.isArray(d.members) ? d.members : [], memberKey: '', peerJoined: false });
  try { if (canP2P) setupPeer(true); } catch (err) { teardown(false); throw err; }
  if (USE_WEB_RELAY) {
    activateRelay('relay_first');
    startStatusWait();
  } else { startPolling(); startStatusWait(); }
  saveHint();
  return d.code;
}

async function joinRoom(code, name) {
  if (N.active) teardown(true);
  const gen = N.gen;
  const c = normCode(code);
  if (c.length !== 6) throw netError('bad_code');
  const canP2P = typeof RTCPeerConnection === 'function';
  N.myName = cleanName(name);
  const d = await api('join', { code: c }, { name: N.myName });
  if (gen !== N.gen) {
    api('close', { code: c }, { id: d && d.id }).catch(() => {});
    throw netError('cancelled');
  }
  Object.assign(N, { code: c, role: 'guest', active: true, connected: false, since: Number(d.cursor) || Date.now(), fresh: true,
    offerSent: false, pendingIce: [], peerName: cleanName(d.host || '房主'), peerId: String(d.id || ''), members: Array.isArray(d.members) ? d.members : [], memberKey: '', peerJoined: true });
  try { if (canP2P) setupPeer(false); } catch (err) { teardown(true); throw err; }
  if (USE_WEB_RELAY) activateRelay('relay_first');
  else { startPolling(); armConnectTimeout(); }
  saveHint();
  try {
    await sendSignal({ t: 'joined', name: N.myName });
  } catch (err) {
    // 房主那边的 status 轮询也能发现有人进来，这条失败不致命
    console.warn('[net] joined 信令发送失败', err);
  }
  return N.peerName;
}

function roomInfo(code) {
  const c = normCode(code);
  if (c.length !== 6) return Promise.reject(netError('bad_code'));
  return api('status', { code: c }).then(d => ({ state: d.state, host_name: d.host_name, guest_name: d.guest_name }));
}

function leave() { teardown(true); }

// 会话提示：刷新后大厅能预填上次的房号/昵称（连接本身无法跨刷新保留）
function saveHint() {
  try { sessionStorage.setItem(HINT_KEY, JSON.stringify({ code: N.code, role: N.role, name: N.myName })); } catch (err) { /* 存不了就算了 */ }
}
function readHint() {
  try { const r = sessionStorage.getItem(HINT_KEY); return r ? JSON.parse(r) : null; } catch (err) { return null; }
}
function clearHint() {
  try { sessionStorage.removeItem(HINT_KEY); } catch (err) { /* 忽略 */ }
}

// 关页面时尽量通知对方，对方不必等 ICE 超时才知道人走了；
// 同时告诉 coop.js 连接没了：页面万一从往返缓存恢复，不会卡在"联机中、实体不归本机管"的状态
window.addEventListener('pagehide', () => {
  if (N.active) {
    const was = N.connected;
    teardown(true);
    emit('disconnected', { reason: 'closed', wasConnected: was });
  }
});

BR.net = {
  on(fn) { listeners.add(fn); return () => listeners.delete(fn); },
  off(fn) { listeners.delete(fn); },
  available() { return !!signalUrl(); },
  createRoom, joinRoom, roomInfo, leave, send, setMic, resumeAudio, errorText,
  readHint, clearHint,
  get active() { return N.active; },
  get connected() { return N.connected; },
  get relay() { return N.relay; },
  get role() { return N.role; },
  get code() { return N.code; },
  get myName() { return N.myName; },
  get peerId() { return N.peerId || ''; },
  get members() { return Array.isArray(N.members) ? N.members : []; },
  get peerName() { return N.peerName; },
  get micOn() { return N.micOn; },
  get micPending() { return !!N.micPending; },
  get localStream() { return N.localStream; },
  get remoteStream() { return N.remoteStream; },
  // 对方语音已接上却没在播（自动播放被拦着）：coop.js 据此把说话角标换成"轻触收听"
  get remotePaused() {
    if (N.remoteAudio && N.remoteAudio.srcObject && N.remoteAudio.paused) return true;
    for (const v of N.voicePeers.values()) if (v.audio && v.audio.srcObject && v.audio.paused) return true;
    return false;
  },
};
})();









