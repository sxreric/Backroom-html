// 后室 · Level 35–50 公共生成器
//
// 设计目标：
// - 每层都有自己的空间骨架与大型地标，不是只换墙面颜色；
// - 出生点与出口由 levelSeed 决定，联机双方生成完全相同的地图；
// - 主出口离出生区块 4–6 个区块，避免“走几步就过关”；
// - 装饰默认不参与碰撞，主结构先 carve 再 gridWalls，避免看得见的门被隐形墙堵住。
(function () {
'use strict';
const BR = window.BR;
const kit = BR.kit;
const U = BR.util;

const CELL = 3;
const N = 8;
const SIZE = CELL * N;
const SPAWNS = [[1, 1], [1, 6], [6, 1], [6, 6]];
const DIRECTIONS = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]];

const SPECS = {
  '35': {
    title: 'An Empty Car Park', nickname: '空停车场', survivalClass: '2 · Unsafe / Secure / Low Entity Count',
    theme: 'garage', indoor: true, wall: 0x787b78, floor: 0x4d5050, ceil: 0x777a78,
    bg: 0x14191b, fog: 54, ambient: 0xced6d3, intensity: 0.28, audio: 'electrical',
    exitTo: '36', exitLabel: '亮着航班编号的停车场闸门', accent: [1.2, 0.82, 0.18],
    entities: [{ type: 'hound', officialPer1000m2: 0.8 }, { type: 'death_rat', officialPer1000m2: 1.0 }],
  },
  '36': {
    title: 'Timeless Airport', nickname: '无时机场', survivalClass: '1 · Safe / Easy Exit / No Hostile Entities',
    theme: 'airport', indoor: true, wall: 0xd4d4ce, floor: 0x8e9699, ceil: 0xd9d9d1,
    bg: 0x83939d, fog: 78, ambient: 0xe8f1f5, intensity: 0.56, audio: 'silence',
    exitTo: '37', exitLabel: 'GATE 37 的登机廊桥', accent: [0.25, 0.85, 1.25], entities: [],
  },
  '37': {
    title: 'Sublimity', nickname: '泳池房', survivalClass: '0 · Safe / Unsecure / Devoid of Entities',
    theme: 'pool', indoor: true, open: true, wall: 0xe8ece8, floor: 0xb8d8d4, ceil: 0xf1f0e8,
    bg: 0xc3e0dc, fog: 72, ambient: 0xe8fff8, intensity: 0.64, audio: 'ocean',
    exitTo: '38', exitLabel: '深水阶梯下的折叠门', accent: [0.18, 0.95, 1.35], entities: [],
  },
  '38': {
    title: 'Fold Point', nickname: '折叠点', survivalClass: '5 · Unsafe / Unstable / Entity Infestation',
    theme: 'fold', indoor: true, wall: 0x74677c, floor: 0x625c67, ceil: 0x8b8290,
    bg: 0x16111d, fog: 34, ambient: 0xd9b7ef, intensity: 0.17, audio: 'dark', darkness: true,
    exitTo: '39', exitLabel: '四种建筑重叠处的林间裂缝', accent: [1.2, 0.18, 1.25],
    entities: [{ type: 'smiler', officialPer1000m2: 2.6 }, { type: 'skin_stealer', officialPer1000m2: 1.5 }, { type: 'wretch', officialPer1000m2: 1.25 }, { type: 'duller', officialPer1000m2: 1.0 }],
  },
  '39': {
    title: 'Enchanted Forest', nickname: '魔法森林', survivalClass: '0 · Safe / Secure / Devoid of Entities',
    theme: 'duskforest', outdoor: true, open: true, wall: 0x334132, floor: 0x4e5638, ceil: 0x2d2940,
    bg: 0x2c2440, fog: 64, ambient: 0xd4b9dd, intensity: 0.34, audio: 'wind-field',
    exitTo: '40', exitLabel: '黄昏林道尽头的霓虹拱门', accent: [0.75, 0.42, 1.25], entities: [],
  },
  '40': {
    title: "Roller Rockin' Pizza!", nickname: '摇滚披萨街机厅', survivalClass: '1 · Safe / Secure / Minimal Entities',
    theme: 'arcade', indoor: true, wall: 0x24305c, floor: 0x1f2244, ceil: 0x17182a,
    bg: 0x090a17, fog: 44, ambient: 0xc4b8ff, intensity: 0.24, audio: 'party',
    exitTo: '41', exitLabel: '维修区后的柏油安全门', accent: [1.2, 0.24, 0.82],
    entities: [{ type: 'faceling', officialPer1000m2: 0.8 }],
    items: [{ type: 'soft_drink', per1000m2: 0.14 }, { type: 'chocolate_bar', per1000m2: 0.10 }],
  },
  '41': {
    title: 'The Black Lake', nickname: '黑湖', survivalClass: 'Environmental · Hostile Environment / Low Entity Count',
    theme: 'tar', outdoor: true, open: true, wall: 0x2d2c2b, floor: 0x181817, ceil: 0x45464a,
    bg: 0x282a2e, fog: 30, ambient: 0xaaa9a3, intensity: 0.16, audio: 'wind-field',
    exitTo: '42', exitLabel: '沥青栈桥尽头的紫色石门', accent: [1.2, 0.38, 0.16],
    entities: [{ type: 'deathmoth_female', officialPer1000m2: 0.55 }, { type: 'smiler', officialPer1000m2: 0.75 }],
  },
  '42': {
    title: 'A Place of Interest', nickname: '悬柱荒原', survivalClass: 'N/A · Uncharted / Environmental Risk',
    theme: 'pillars', outdoor: true, open: true, wall: 0x5c5964, floor: 0x655c52, ceil: 0x2f2541,
    bg: 0x332446, fog: 56, ambient: 0xcbb8e0, intensity: 0.28, audio: 'wind-field',
    exitTo: '43', exitLabel: '浮空石柱间的水世界标志', accent: [0.85, 0.48, 1.25],
    entities: [{ type: 'observer', officialPer1000m2: 0.6 }],
  },
  '43': {
    title: 'Water World', nickname: '水世界', survivalClass: '3 · Unsafe / Unsecure / Moderate Entity Count',
    theme: 'aquarium', indoor: true, wall: 0x58767d, floor: 0x477077, ceil: 0x42636b,
    bg: 0x153c4a, fog: 46, ambient: 0x9ed8df, intensity: 0.31, audio: 'ocean',
    exitTo: '44', exitLabel: '闭园广播旁的员工通道', accent: [0.18, 1.0, 1.25],
    entities: [{ type: 'hound', officialPer1000m2: 1.35 }, { type: 'smiler', officialPer1000m2: 1.05 }, { type: 'skin_stealer', officialPer1000m2: 0.65 }],
  },
  '44': {
    title: 'Corroding Retail Outlet', nickname: '腐蚀零售店', survivalClass: '3 · Unsafe / Secure / Low Entity Count',
    theme: 'retail', indoor: true, wall: 0x7a7873, floor: 0x615e58, ceil: 0x8b8983,
    bg: 0x1b1a18, fog: 38, ambient: 0xd0c7b8, intensity: 0.22, audio: 'electrical',
    exitTo: '45', exitLabel: '显示现实街景的黑色橱窗', accent: [1.15, 0.72, 0.22],
    entities: [{ type: 'duller', officialPer1000m2: 1.2 }, { type: 'death_rat', officialPer1000m2: 1.2 }],
  },
  '45': {
    title: 'Abyss Inc.', nickname: '深渊公司', survivalClass: '1 · Safe Core / Unsecure Perimeter / Low Entity Count',
    theme: 'officevoid', indoor: true, wall: 0x6a7075, floor: 0x495057, ceil: 0x71777d,
    bg: 0x03050a, fog: 72, ambient: 0xb8cee3, intensity: 0.31, audio: 'city',
    exitTo: '46', exitLabel: '零重力会议室的沙色电梯', accent: [0.32, 0.72, 1.3],
    entities: [{ type: 'deathmoth_female', officialPer1000m2: 0.9 }, { type: 'curabitur_bird', officialPer1000m2: 0.35 }],
  },
  '46': {
    title: 'Arabian Desert', nickname: '阿拉伯沙漠', survivalClass: '3 · Unsafe / Unsecure / Environmental Hazard',
    theme: 'desert', outdoor: true, open: true, wall: 0x9e7549, floor: 0xc49758, ceil: 0x39284c,
    bg: 0x392947, fog: 76, ambient: 0xf4cba4, intensity: 0.36, audio: 'wind-field',
    exitTo: '47', exitLabel: '古代遗迹里的苔藓石门', accent: [1.25, 0.58, 0.16],
    entities: [{ type: 'wretch', officialPer1000m2: 1.25 }, { type: 'hound', officialPer1000m2: 1.15 }, { type: 'smiler', officialPer1000m2: 0.8 }],
  },
  '47': {
    title: 'The Adderwood', nickname: '古老森林', survivalClass: '3 · Unsafe / Unsecure / Moderate Entity Count',
    theme: 'oldforest', outdoor: true, open: true, wall: 0x253424, floor: 0x31462e, ceil: 0x18211c,
    bg: 0x18201b, fog: 34, ambient: 0xb9c6b4, intensity: 0.19, audio: 'wind-field',
    exitTo: '48', exitLabel: '银白月光下的海滩木门', accent: [0.74, 1.05, 0.82],
    entities: [{ type: 'woodlin', officialPer1000m2: 1.4 }, { type: 'watcher', officialPer1000m2: 1.0 }, { type: 'hound', officialPer1000m2: 0.8 }],
  },
  '48': {
    title: 'The Sunset Beach', nickname: '落日海滩', survivalClass: 'Habitable · Safe / Secure / Minimal Entities',
    theme: 'beach', outdoor: true, open: true, wall: 0xe1b36c, floor: 0xe3bd75, ceil: 0xf07b54,
    bg: 0xf07a55, fog: 92, ambient: 0xffd2a8, intensity: 0.58, audio: 'ocean',
    exitTo: '49', exitLabel: '度假屋地下的战壕铁门', accent: [1.25, 0.72, 0.2], entities: [],
    items: [{ type: 'canned_food', per1000m2: 0.14 }, { type: 'soft_drink', per1000m2: 0.12 }],
  },
  '49': {
    title: 'The Unfilled River of Phlegethon', nickname: '无尽战壕', survivalClass: '4 · Extreme Environmental Risk / Hostile Infestation',
    theme: 'trench', indoor: false, wall: 0x493c31, floor: 0x514334, ceil: 0x403934,
    bg: 0x302d2a, fog: 32, ambient: 0xc4b39b, intensity: 0.18, audio: 'dark',
    exitTo: '50', exitLabel: '无人区尽头的破损公路牌', accent: [1.25, 0.28, 0.12],
    entities: [{ type: 'wretch', officialPer1000m2: 2.2 }, { type: 'hound', officialPer1000m2: 2.0 }, { type: 'skin_stealer', officialPer1000m2: 1.4 }, { type: 'smiler', officialPer1000m2: 1.3 }],
    items: [{ type: 'bandages', per1000m2: 0.10 }, { type: 'painkillers', per1000m2: 0.08 }],
  },
  '50': {
    title: 'The Moribund Highway', nickname: '垂死公路', survivalClass: '3 · Unsafe / Unsecure / Sparse Resources',
    theme: 'highway', outdoor: true, open: true, wall: 0x5c5248, floor: 0x3d3d3b, ceil: 0x725842,
    bg: 0x5a4437, fog: 84, ambient: 0xe0b992, intensity: 0.31, audio: 'wind-field',
    exitTo: '0', exitLabel: '公路尽头闪烁的黄色出口', accent: [1.35, 1.05, 0.2],
    entities: [{ type: 'hound', officialPer1000m2: 1.3 }, { type: 'skin_stealer', officialPer1000m2: 0.75 }, { type: 'smiler', officialPer1000m2: 0.65 }],
  },
};

function matKeys(s) {
  const p = 'L' + s.id;
  kit.mats({
    [p + ':wall']: { tex: s.theme === 'trench' ? 'l3_brick_brown' : 'concrete', repeatMeters: 2.1, roughness: 0.94, color: s.wall },
    [p + ':floor']: { tex: s.theme === 'garage' || s.theme === 'highway' ? 'concrete_wet' : 'concrete', repeatMeters: 2.4, roughness: 0.98, color: s.floor },
    [p + ':ceil']: { tex: s.theme === 'arcade' ? 'carpet_light' : 'ceiling_tile', repeatMeters: 1.6, roughness: 0.98, color: s.ceil },
    [p + ':tile']: { tex: 'concrete', repeatMeters: 0.48, roughness: 0.74, color: s.theme === 'pool' ? 0xf2f1e9 : s.wall },
    [p + ':tileBlue']: { tex: 'concrete', repeatMeters: 0.52, roughness: 0.72, color: 0xaad8d7 },
    [p + ':deep']: { tex: 'concrete', repeatMeters: 0.5, roughness: 0.82, color: 0x548f95 },
  });
  return p;
}

function reserve(g, i, j, r) {
  const rr = r == null ? 1 : r;
  const i0 = Math.max(0, i - rr), i1 = Math.min(N - 1, i + rr);
  const j0 = Math.max(0, j - rr), j1 = Math.min(N - 1, j + rr);
  g.carve(i0, j0, i1 - i0 + 1, j1 - j0 + 1, { room: true });
  for (let z = j0; z <= j1; z++) for (let x = i0; x <= i1; x++) g.reserve(x, z);
}

function carveRoute(g, i, j) {
  const m = 3;
  g.carve(Math.min(i, m), j, Math.abs(i - m) + 1, 1, { room: true });
  g.carve(m, Math.min(j, m), 1, Math.abs(j - m) + 1, { room: true });
}

function route(seed, s) {
  const rng = U.rng(seed == null ? 0 : seed, 'L' + s.id + ':route-v1');
  const spawn = SPAWNS[Math.floor(rng() * SPAWNS.length) % SPAWNS.length];
  const dir = DIRECTIONS[Math.floor(rng() * DIRECTIONS.length) % DIRECTIONS.length];
  const radius = 4 + Math.floor(rng() * 3);
  const end = SPAWNS[Math.floor(rng() * SPAWNS.length) % SPAWNS.length];
  return { spawnI: spawn[0], spawnJ: spawn[1], exitCx: dir[0] * radius, exitCz: dir[1] * radius, exitI: end[0], exitJ: end[1] };
}

function shape(g, s, cx, cz) {
  const odd = Math.abs(cx + cz) % 2;
  if (s.open || s.outdoor) g.carve(0, 0, N, N, { room: true });
  if (s.theme === 'garage') {
    g.carve(0, 1, N, 2, { room: true }); g.carve(0, 5, N, 2, { room: true }); g.carve(3, 0, 2, N, { room: true });
  } else if (s.theme === 'airport') {
    g.carve(0, 2, N, 4, { room: true }); g.carve(2, 0, 4, N, { room: true });
  } else if (s.theme === 'pool') {
    g.carve(0, 0, N, N, { room: true });
  } else if (s.theme === 'fold') {
    g.carve(1, 1, 2, 2, { room: true }); g.carve(5, 1, 2, 2, { room: true });
    g.carve(1, 5, 2, 2, { room: true }); g.carve(5, 5, 2, 2, { room: true });
    g.carve(3, 0, 2, N, { room: true }); g.carve(0, 3, N, 2, { room: true });
  } else if (s.theme === 'arcade' || s.theme === 'retail') {
    g.carve(0, 3, N, 2, { room: true }); g.carve(3, 0, 2, N, { room: true });
    if (odd) { g.carve(1, 1, 2, 2, { room: true }); g.carve(5, 5, 2, 2, { room: true }); }
    else { g.carve(5, 1, 2, 2, { room: true }); g.carve(1, 5, 2, 2, { room: true }); }
  } else if (s.theme === 'aquarium' || s.theme === 'officevoid') {
    g.carve(1, 1, 6, 6, { room: true }); g.carve(0, 3, N, 2, { room: true });
  } else if (s.theme === 'trench') {
    if (odd) { g.carve(0, 3, N, 2, { room: true }); g.carve(2, 1, 2, 6, { room: true }); }
    else { g.carve(3, 0, 2, N, { room: true }); g.carve(1, 4, 6, 2, { room: true }); }
  }
}

function pickCell(g, rng, used) {
  const cells = g.cells(c => !c.reserved && c.i > 0 && c.i < N - 1 && c.j > 0 && c.j < N - 1 && !used.has(c.i + ':' + c.j));
  if (!cells.length) return null;
  const c = cells[Math.floor(rng() * cells.length) % cells.length];
  used.add(c.i + ':' + c.j); g.reserve(c.i, c.j);
  return c;
}

function glow(b, x, y, z, w, d, color, rotY, power) {
  b.box(x, y, z, w, 0.035, d, 'kit:glow', { color, glow: power == null ? 0.55 : power, solid: false, rotY: rotY || 0 });
}

function arch(b, x, z, color, w, h) {
  const W = w || 2.3, H = h || 2.25, t = 0.12;
  b.box(x - W / 2 + t / 2, 0, z, t, H, t, 'kit:prop', { color, solid: false });
  b.box(x + W / 2 - t / 2, 0, z, t, H, t, 'kit:prop', { color, solid: false });
  b.box(x, H - t, z, W, t, t, 'kit:prop', { color, solid: false });
}

function tree(b, x, z, rng, old) {
  const h = (old ? 2.3 : 1.65) + rng() * (old ? 1.8 : 1.0);
  b.cylinder(x, 0, z, old ? 0.24 : 0.16, h, 'kit:prop', { segments: 7, color: old ? 0x2c2017 : 0x3b2a1b, solid: false });
  for (let k = 0; k < (old ? 3 : 2); k++) {
    b.cylinder(x + (rng() - 0.5) * 0.45, h - 0.15 + k * 0.24, z + (rng() - 0.5) * 0.45,
      0.62 + rng() * 0.28, 0.55, 'kit:prop', { segments: 8, color: old ? 0x19301f : 0x314c2d, solid: false, caps: false });
  }
}

function car(b, x, z, rot, color) {
  b.push(x, z, rot);
  b.box(0, 0.18, 0, 1.2, 0.42, 2.2, 'kit:prop', { color, solid: false });
  b.box(0, 0.58, -0.08, 1.05, 0.42, 1.15, 'kit:glass', { color: 0x76909a, solid: false });
  for (const sx of [-0.56, 0.56]) for (const sz of [-0.72, 0.72]) b.cylinder(sx, 0.22, sz, 0.19, 0.10, 'kit:prop', { axis: 'x', segments: 10, color: 0x151515, solid: false });
  b.pop();
}

function themeDecor(b, s, g, rng, used, cx, cz) {
  const c = pickCell(g, rng, used); if (!c) return;
  const x = c.x, z = c.z, t = s.theme;
  if (t === 'garage') {
    b.box(x, 0, z, 0.55, 2.7, 0.55, 'kit:prop', { color: 0x646766, solid: false });
    glow(b, x, 1.1, z - 0.3, 0.3, 0.05, [1.2, 0.75, 0.15], 0, 0.35);
    if (rng() < 0.22) car(b, x + 0.9, z, Math.PI / 2, [0xa0, 0.25, 0.18]);
    else for (const dx of [-0.72, 0, 0.72]) glow(b, x + dx, 0.012, z + 0.7, 0.05, 1.3, [1.1, 1.1, 0.95]);
  } else if (t === 'airport') {
    b.box(x, 0, z, 2.15, 0.72, 0.58, 'kit:prop', { color: 0x52616a, solid: false });
    for (let k = -2; k <= 2; k++) b.cylinder(x + k * 0.36, 0.22, z, 0.11, 0.42, 'kit:prop', { axis: 'z', segments: 8, color: 0x26333a, solid: false });
    kit.prop.sign(b, x, z - 0.42, 0, { y: 1.7, w: 1.8, h: 0.35, color: 0x73d5ff, backColor: 0x172a35, solid: false });
  } else if (t === 'pool') {
    kit.prop.puddle(b, x, z, 0, { rx: 1.3, rz: 1.05, color: 0x66c9ca, ringColor: 0xe7f4ef });
    for (const dx of [-1.18, 1.18]) b.box(x + dx, 0, z, 0.14, 0.55, 2.0, 'kit:prop', { color: 0xe5ece8, solid: false });
    for (let k = -2; k <= 2; k++) glow(b, x + k * 0.42, 0.025, z, 0.02, 1.45, [0.55, 1.05, 1.15]);
  } else if (t === 'fold') {
    for (let k = -2; k <= 2; k++) b.box(x + k * 0.25, 0.18 + Math.abs(k) * 0.18, z + k * 0.14, 0.16, 1.1 + (k & 1) * 0.55, 1.7, 'kit:glow', { color: k % 2 ? [1.1, 0.16, 0.95] : [0.14, 0.82, 1.1], glow: 0.42, solid: false, rotY: k * 0.1 });
  } else if (t === 'duskforest' || t === 'oldforest') {
    tree(b, x, z, rng, t === 'oldforest');
    if (rng() < 0.45) kit.prop.puddle(b, x + 0.65, z - 0.35, 0, { rx: 0.48, rz: 0.28, color: t === 'oldforest' ? 0x263d31 : 0x493d62 });
  } else if (t === 'arcade') {
    for (const dx of [-0.82, 0, 0.82]) {
      b.box(x + dx, 0, z, 0.66, 1.25, 0.52, 'kit:prop', { color: 0x20202d, solid: false });
      glow(b, x + dx, 0.78, z - 0.28, 0.42, 0.03, dx ? [0.18, 0.8, 1.2] : [1.2, 0.18, 0.85], 0, 0.8);
    }
    glow(b, x, 0.03, z + 0.65, 2.2, 0.05, [1.05, 0.22, 0.92]);
  } else if (t === 'tar') {
    kit.prop.puddle(b, x, z, 0, { rx: 1.35, rz: 0.95, color: 0x090909, ringColor: 0x30251f });
    for (let k = -2; k <= 2; k++) b.box(x + k * 0.45, 0.08, z, 0.34, 0.09, 2.2, 'kit:prop', { color: 0x4b382d, solid: false });
    b.light({ x, y: 0.5, z, color: 0xff6b2d, intensity: 0.25, range: 3.5, flicker: 0.6 });
  } else if (t === 'pillars') {
    for (let k = 0; k < 4; k++) {
      const a = k * Math.PI / 2;
      b.box(x + Math.cos(a) * 0.85, 0.55 + k * 0.15, z + Math.sin(a) * 0.85, 0.46, 2.0, 0.58, 'kit:prop', { color: 0x68666d, solid: false, rotY: a + 0.18 * (k - 1) });
    }
    glow(b, x, 0.04, z, 0.9, 0.9, [0.72, 0.28, 1.05], 0, 0.35);
  } else if (t === 'aquarium') {
    b.box(x, 0, z, 2.5, 1.75, 0.12, 'kit:glass', { color: 0x3186a0, opacity: 0.68, solid: false });
    b.box(x, 0, z + 0.12, 2.6, 0.2, 0.28, 'kit:prop', { color: 0x36545a, solid: false });
    for (let k = 0; k < 6; k++) b.cylinder(x - 1 + k * 0.4, 0.18, z - 0.08, 0.03, 0.22 + rng() * 0.35, 'kit:glow', { segments: 5, color: [0.12, 0.65, 0.82], glow: 0.25, solid: false });
  } else if (t === 'retail') {
    arch(b, x, z, 0x6c6963, 2.45, 2.2);
    for (let k = 0; k < 7; k++) b.box(x, 0.25 + k * 0.25, z + 0.04, 2.1, 0.055, 0.04, 'kit:prop', { color: 0x4b4b48, solid: false });
    if (rng() < 0.45) kit.prop.puddle(b, x - 0.6, z - 0.55, 0, { rx: 0.62, rz: 0.32, color: 0x3e4b48 });
  } else if (t === 'officevoid') {
    kit.prop.desk(b, x, z, Math.PI, { color: 0x555b60, solid: false, detail: true });
    kit.prop.chair(b, x, z - 0.72, 0, { color: 0x24282c, solid: false, detail: true });
    for (const dx of [-1.0, 1.0]) b.plane(x + dx, 0.15, z + 0.62, 0.82, 1.65, 'kit:glass', { facing: '+z', color: 0x172534, solid: false });
  } else if (t === 'desert') {
    for (let k = -2; k <= 2; k++) b.box(x + k * 0.42, 0, z, 0.34, 0.5 + (2 - Math.abs(k)) * 0.28, 1.9, 'kit:prop', { color: 0x8e673f, solid: false });
    arch(b, x, z - 0.88, 0x6d4c31, 1.65, 1.75);
  } else if (t === 'beach') {
    for (let k = -2; k <= 2; k++) b.box(x + k * 0.48, 0.02, z, 0.4, 0.08, 2.3, 'kit:prop', { color: 0x7d5a35, solid: false });
    b.cylinder(x + 0.95, 0, z + 0.65, 0.12, 1.75, 'kit:prop', { segments: 7, color: 0x5a3d24, solid: false });
    for (let k = 0; k < 5; k++) b.box(x + 0.95, 1.38, z + 0.65, 0.08, 0.08, 1.25, 'kit:prop', { color: 0x31552e, solid: false, rotY: k * Math.PI * 0.4 });
  } else if (t === 'trench') {
    b.box(x, 0, z, 2.5, 0.58, 0.22, 'kit:prop', { color: 0x4d3a2b, solid: false });
    for (let k = -3; k <= 3; k++) b.cylinder(x + k * 0.35, 0.48, z, 0.07, 0.18, 'kit:prop', { axis: 'z', segments: 6, color: 0x29231e, solid: false });
    kit.prop.crate(b, x + 0.75, z - 0.62, 0, { size: 0.58, color: 0x5b4937, solid: false });
  } else if (t === 'highway') {
    for (const dx of [-0.72, 0.72]) glow(b, x + dx, 0.012, z, 0.06, 2.4, [1.1, 0.92, 0.45]);
    if (rng() < 0.38) car(b, x, z, rng() < 0.5 ? 0 : Math.PI, rng() < 0.5 ? 0x6b2d27 : 0x2d4f63);
    else kit.prop.streetlight(b, x + 1.05, z, 0, { h: 2.8, color: 0x51504d, light: true, intensity: 0.3, solid: false });
  }
}

function startingLandmark(b, s, g, rng, used) {
  const c = pickCell(g, rng, used); if (!c) return;
  const x = c.x, z = c.z;
  if (s.theme === 'garage') car(b, x, z, Math.PI / 2, 0x7b7366);
  else if (s.theme === 'airport') {
    kit.prop.vending(b, x - 0.55, z, Math.PI, { color: 0x4a6370, solid: false });
    kit.prop.sign(b, x + 0.5, z, Math.PI, { y: 1.8, w: 1.1, h: 0.38, color: 0x68cfff, backColor: 0x172c38, solid: false });
  } else if (s.theme === 'pool') {
    kit.prop.stairwell(b, x, z, 0, { w: 1.4, h: 1.0, steps: 5, down: true, wallColor: 0xe8efec, solid: false });
  } else if (s.theme === 'arcade') {
    kit.prop.vending(b, x, z, Math.PI, { color: 0x622c70, glow: 0xf05cff, light: true, intensity: 0.28, solid: false });
  } else if (s.theme === 'aquarium') {
    arch(b, x, z, 0x4e777e, 2.55, 2.4); glow(b, x, 2.1, z, 1.9, 0.05, [0.18, 0.9, 1.2]);
  } else if (s.theme === 'officevoid') {
    kit.prop.cubicle(b, x, z, 0, { color: 0x6b7074, solid: false });
  } else if (s.theme === 'beach') {
    b.box(x, 0, z, 2.4, 1.55, 1.8, 'kit:prop', { color: 0xe5d4b5, solid: false });
    b.box(x, 1.57, z, 2.7, 0.12, 2.1, 'kit:prop', { color: 0xb97045, solid: false, rotY: 0.12 });
  } else if (s.theme === 'trench') {
    kit.prop.crate(b, x - 0.45, z, 0, { size: 0.72, color: 0x5c4834, solid: false });
    kit.prop.crate(b, x + 0.45, z + 0.2, 0, { size: 0.58, color: 0x574431, solid: false });
  } else if (s.theme === 'highway') {
    kit.prop.sign(b, x, z, 0, { y: 2.0, w: 1.6, h: 0.55, color: 0xf0c44d, backColor: 0x29302d, solid: false });
  } else themeDecor(b, s, g, rng, used, 0, 0);
}

function exitLandmark(b, s, x, z) {
  const color = s.theme === 'trench' ? 0x4f4439 : s.theme === 'beach' ? 0xd8c29f : 0x767b7d;
  arch(b, x, z, color, 2.55, 2.4);
  if (s.theme === 'highway') {
    for (const dx of [-0.72, 0.72]) glow(b, x + dx, 0.02, z - 1.0, 0.08, 2.7, s.accent);
  } else if (s.theme === 'pool') {
    kit.prop.stairwell(b, x, z + 0.35, 0, { w: 1.55, h: 1.0, steps: 5, down: true, wallColor: 0xe8efec, solid: false });
  } else {
    kit.prop.door(b, x, z, 0, { style: s.theme === 'trench' || s.theme === 'retail' ? 'metal' : 'wood', w: 1.35, h: 2.18, wall: false, sign: false, solid: false });
  }
  glow(b, x, 2.16, z - 0.08, 1.65, 0.05, s.accent, 0, 0.9);
  kit.prop.sign(b, x, z - 0.44, 0, { y: 2.52, w: 1.55, h: 0.31, color: s.accent, backColor: 0x17130d, solid: false });
  for (let k = -1; k <= 1; k++) b.cylinder(x + k * 0.7, 0.02, z + 0.72, 0.075, 0.035, 'kit:glow', { segments: 8, color: s.accent, glow: 0.5, solid: false });
}

function poolWater(b, x, z, w, d, deep) {
  const mat = deep ? 'L37:deep' : 'L37:tileBlue';
  b.box(x, 0.002, z, w, 0.055, d, mat, { solid: false, faces: ['py'] });
  b.plane(x, 0.067, z, w - 0.12, d - 0.12, 'kit:water', {
    facing: 'up', color: deep ? [0.06, 0.42, 0.54] : [0.24, 0.78, 0.82], solid: false,
  });
  const rim = 0.16;
  b.box(x, 0.055, z - d / 2, w + rim * 2, 0.11, rim, 'L37:tile', { solid: false });
  b.box(x, 0.055, z + d / 2, w + rim * 2, 0.11, rim, 'L37:tile', { solid: false });
  b.box(x - w / 2, 0.055, z, rim, 0.11, d, 'L37:tile', { solid: false });
  b.box(x + w / 2, 0.055, z, rim, 0.11, d, 'L37:tile', { solid: false });
}

function poolArch(b, x, z, rot, w, h) {
  const W = w || 3.2, HH = h || 3.35, col = 'L37:tile';
  b.push(x, z, rot || 0);
  b.box(-W / 2, 0, 0, 0.34, HH, 0.48, col, { solid: true, bevel: 0.08, bevelEdges: 'vertical' });
  b.box(W / 2, 0, 0, 0.34, HH, 0.48, col, { solid: true, bevel: 0.08, bevelEdges: 'vertical' });
  b.box(0, HH - 0.3, 0, W, 0.3, 0.48, col, { solid: true, bevel: 0.08, bevelEdges: 'horizontal' });
  // 圆弧感用三段逐级缩短的内檐表现，开口仍保持宽阔可走。
  for (let k = 0; k < 3; k++) {
    const yy = HH - 0.55 - k * 0.18;
    const ww = W - 0.72 - k * 0.42;
    b.box(0, yy, 0.04, ww, 0.12, 0.54, col, { solid: false, bevel: 0.055, bevelEdges: 'horizontal' });
  }
  b.pop();
}

function poolColumn(b, x, z, h, lit) {
  const H = h || 4.55;
  b.cylinder(x, 0, z, 0.28, H, 'L37:tile', { segments: 12, color: 0xf4f3eb, solid: true, caps: true });
  b.cylinder(x, 0, z, 0.43, 0.16, 'L37:tile', { segments: 12, color: 0xe6e6df, solid: true, caps: true });
  b.cylinder(x, H - 0.18, z, 0.43, 0.18, 'L37:tile', { segments: 12, color: 0xe6e6df, solid: false, caps: true });
  if (lit) b.light({ x, y: H - 0.5, z, color: 0xc8ffff, intensity: 0.38, range: 5.5 });
}

function poolRoomGeometry(b, cx, cz, rng, H) {
  const v = Math.abs((cx * 31 + cz * 17) % 5);
  // 所有样式都保留中央十字步道，跨区块不会突然断路。
  b.box(12, 0.018, 12, 4.0, 0.055, 24, 'L37:tile', { solid: false });
  b.box(12, 0.02, 12, 24, 0.055, 4.0, 'L37:tile', { solid: false });
  if (v === 0) {
    // 大厅：四池、柱廊与对称拱门。
    for (const [x, z] of [[5.1, 5.1], [18.9, 5.1], [5.1, 18.9], [18.9, 18.9]]) poolWater(b, x, z, 8.9, 8.9, false);
    for (const x of [7.2, 16.8]) for (const z of [7.2, 16.8]) poolColumn(b, x, z, H, false);
    poolArch(b, 12, 3.1, 0, 4.2, 3.6); poolArch(b, 12, 20.9, Math.PI, 4.2, 3.6);
    poolArch(b, 3.1, 12, Math.PI / 2, 4.2, 3.6); poolArch(b, 20.9, 12, -Math.PI / 2, 4.2, 3.6);
  } else if (v === 1) {
    // 长水廊：平行浅池、反常重复拱券。
    poolWater(b, 6.1, 12, 7.4, 20.4, false); poolWater(b, 17.9, 12, 7.4, 20.4, true);
    for (const z of [3.1, 7.6, 12, 16.4, 20.9]) poolArch(b, 12, z, 0, 4.0, 3.5);
    for (const z of [4.5, 10.5, 16.5, 22.0]) { poolColumn(b, 2.1, z, H, false); poolColumn(b, 21.9, z, H, false); }
  } else if (v === 2) {
    // 下沉式中庭：深水环、中央孤岛、两座无意义楼梯。
    poolWater(b, 12, 12, 19.4, 15.8, true);
    b.box(12, 0.075, 12, 5.0, 0.13, 5.0, 'L37:tile', { solid: false, bevel: 0.1, bevelEdges: 'top' });
    b.box(12, 0.08, 12, 19.8, 0.12, 1.7, 'L37:tile', { solid: false });
    kit.prop.stairwell(b, 6.5, 12, -Math.PI / 2, { w: 1.6, depth: 3.0, down: true, solid: false });
    kit.prop.stairwell(b, 17.5, 12, Math.PI / 2, { w: 1.6, depth: 3.0, down: true, solid: false });
    for (const [x, z] of [[3,3], [21,3], [3,21], [21,21]]) poolColumn(b, x, z, H, true);
  } else if (v === 3) {
    // 迷向浴场：短墙与窄水道交错，开口都对齐中央通路。
    for (const z of [4.5, 9.2, 14.8, 19.5]) {
      const flip = (Math.round(z) + cx + cz) & 1;
      const x = flip ? 5.0 : 19.0;
      b.box(x, 0, z, 7.8, 2.55, 0.32, 'L37:tile', { solid: true });
      poolWater(b, flip ? 17.6 : 6.4, z + (flip ? -1.45 : 1.45), 7.0, 2.1, false);
      poolArch(b, 12, z, 0, 4.1, 3.35);
    }
  } else {
    // 梦核大空间：巨大浅池、看不见用途的柱群与一处幽暗深坑。
    poolWater(b, 12, 12, 18.6, 18.6, false);
    poolWater(b, 18.4, 18.4, 5.2, 5.2, true);
    for (const x of [3.0, 7.0, 17.0, 21.0]) for (const z of [3.0, 21.0]) poolColumn(b, x, z, H, false);
    b.box(12, 0.08, 12, 20.0, 0.12, 1.65, 'L37:tile', { solid: false });
    b.box(12, 0.08, 12, 1.65, 0.12, 20.0, 'L37:tile', { solid: false });
    for (const [x,z,r] of [[4.1,12,Math.PI/2],[19.9,12,-Math.PI/2],[12,4.1,0],[12,19.9,Math.PI]]) poolArch(b,x,z,r,3.6,3.7);
  }
  // 冷白天窗与偶发暗角；没有逐格小灯，整体更接近梦核泳池。
  for (const [x, z] of [[5.2,5.2], [18.8,5.2], [5.2,18.8], [18.8,18.8]]) {
    const dark = ((Math.round(x + z) + cx * 3 + cz * 5) % 7) === 0;
    b.box(x, H - 0.035, z, 3.8, 0.045, 3.8, 'kit:glow', { color: dark ? [0.04,0.07,0.075] : [1.1,1.2,1.18], glow: dark ? 0 : 0.6, solid: false });
    if (!dark) b.light({ x, y: H - 0.3, z, color: 0xd8ffff, intensity: 0.58, range: 8.5 });
  }
}

function buildPoolChunk(ctx, cx, cz, rng, spec) {
  const H = 4.65;
  matKeys(spec);
  const b = kit.builder(ctx, cx, cz, rng, { height: H });
  const plan = route(ctx && ctx.levelSeed, spec);
  const isSpawn = cx === 0 && cz === 0;
  const isExit = cx === plan.exitCx && cz === plan.exitCz;
  kit.prop.floor(b, null, null, 0, { matKey: 'L37:tile' });
  kit.prop.ceiling(b, null, null, 0, { matKey: 'L37:ceil', y: H });
  poolRoomGeometry(b, cx, cz, rng, H);
  if (isSpawn) {
    const x = (plan.spawnI + 0.5) * CELL, z = (plan.spawnJ + 0.5) * CELL;
    b.box(x, 0.08, z, 4.2, 0.11, 4.2, 'L37:tile', { solid: false });
    poolArch(b, x, z - 2.0, 0, 3.2, 3.45);
  }
  if (isExit) {
    const x = (plan.exitI + 0.5) * CELL, z = (plan.exitJ + 0.5) * CELL;
    b.box(x, 0.075, z, 4.4, 0.11, 4.4, 'L37:tile', { solid: false });
    kit.prop.stairwell(b, x, z + 1.25, 0, { w: 1.75, depth: 3.2, down: true, railColor: 0xe9efed, solid: false });
    kit.prop.sign(b, x, z - 0.55, 0, { y: 2.55, w: 1.55, h: 0.28, color: spec.accent, backColor: 0x173033, solid: false });
    kit.exit(b, { to: spec.exitTo, kind: 'zone', x, z, radius: 1.1, label: spec.exitLabel + '（沉水出口）', marker: { color: spec.accent, pulse: true } });
  }
  for (let z = 2.0; z < SIZE; z += 2.5) for (let x = 2.0; x < SIZE; x += 2.5) b.spawn(x, z, 'room', { safe: isSpawn });
  return b.finish();
}

function buildFor(spec) {
  function buildChunk(ctx, cx, cz, rng) {
    if (spec.theme === 'pool') return buildPoolChunk(ctx, cx, cz, rng, spec);
    const key = matKeys(spec);
    const H = spec.theme === 'garage' ? 2.7 : spec.theme === 'pool' ? 3.2 : 2.9;
    const b = kit.builder(ctx, cx, cz, rng, { height: H });
    const plan = route(ctx && ctx.levelSeed, spec);
    const isSpawn = cx === 0 && cz === 0;
    const isExit = cx === plan.exitCx && cz === plan.exitCz;
    const dense = spec.theme === 'trench' || spec.theme === 'fold';
    const g = kit.grid(b, N, N, {
      salt: 'L' + spec.id + ':grid-v1', boundaryDensity: spec.open || spec.outdoor ? 0.08 : 0.32,
      wallDensity: spec.open || spec.outdoor ? 0.06 : dense ? 0.58 : 0.34,
      roomChance: spec.open || spec.outdoor ? 0.05 : 0.30, maxRooms: dense ? 1 : 3,
      straightness: spec.theme === 'trench' ? 0.84 : 0.67, loopChance: dense ? 0.24 : 0.48,
      minOpenings: 2, pillarChance: spec.theme === 'garage' ? 0.08 : 0.02,
    });
    shape(g, spec, cx, cz);
    if (isSpawn) { carveRoute(g, plan.spawnI, plan.spawnJ); reserve(g, plan.spawnI, plan.spawnJ, 1); }
    if (isExit) { carveRoute(g, plan.exitI, plan.exitJ); reserve(g, plan.exitI, plan.exitJ, 1); }

    if (!spec.open || spec.theme === 'trench') kit.gridWalls(b, g, { height: H, matKey: key + ':wall', trim: false });
    kit.prop.floor(b, null, null, 0, { matKey: key + ':floor' });
    if (!spec.outdoor) kit.prop.ceiling(b, null, null, 0, { matKey: key + ':ceil', y: H });

    if (spec.indoor) {
      for (let j = 0; j < N; j += 2) for (let i = 0; i < N; i += 2) {
        const c = g.center(i, j), roll = rng(), flicker = rng();
        if (spec.theme === 'fold' && roll < 0.48) continue;
        kit.prop.lightPanel(b, c.x, c.z, 0, {
          y: H, state: roll < (spec.theme === 'retail' ? 0.34 : 0.08) ? 'broken' : roll < 0.2 ? 'flicker' : 'on',
          flicker: flicker * 0.55, color: spec.theme === 'arcade' ? (roll < 0.5 ? 0xff55d7 : 0x55ccff) : 0xe7eee8,
          intensity: spec.darkness ? 0.3 : spec.theme === 'arcade' ? 0.48 : 0.76, range: spec.darkness ? 4.5 : 6.5,
        });
      }
    }

    const used = new Set();
    if (isSpawn) startingLandmark(b, spec, g, rng, used);
    const count = spec.open || spec.outdoor ? 9 : 6;
    for (let k = 0; k < count; k++) themeDecor(b, spec, g, rng, used, cx, cz);

    if (isExit) {
      const c = g.center(plan.exitI, plan.exitJ);
      exitLandmark(b, spec, c.x, c.z);
      kit.exit(b, { to: spec.exitTo, kind: 'zone', x: c.x, z: c.z, radius: 1.0, label: spec.exitLabel + '（远端出口）', marker: { color: spec.accent, pulse: true } });
    }
    kit.gridSpawns(b, g, { safe: isSpawn, every: spec.open || spec.outdoor ? 2 : 1 });
    return b.finish();
  }

  const items = [{ type: 'almond_water', per1000m2: 1.1 }, { type: 'food_ration', per1000m2: 0.55 }].concat(spec.items || []);
  return {
    id: spec.id, name: 'Level ' + spec.id, title: spec.title, nickname: spec.nickname,
    version: 'wikidot-en', survivalClass: spec.survivalClass, chunkSize: SIZE,
    env: {
      background: spec.bg, fogColor: spec.bg, fogNear: spec.darkness ? 2 : 6, fogFar: spec.fog,
      ambient: { color: spec.ambient, intensity: spec.intensity },
      sanityDrainMul: spec.id === '38' || spec.id === '49' ? 1.8 : spec.id === '41' ? 1.35 : 1,
      hungerDrainMul: spec.id === '46' ? 1.25 : 1, audio: spec.audio, darkness: !!spec.darkness,
    },
    spawn(ctx) {
      const p = route(ctx && ctx.levelSeed, spec);
      const yaw = Math.atan2(N / 2 - (p.spawnI + 0.5), N / 2 - (p.spawnJ + 0.5));
      return { x: (p.spawnI + 0.5) * CELL, y: 0, z: (p.spawnJ + 0.5) * CELL, yaw };
    },
    buildChunk, entities: spec.entities || [], items,
    exits: [{ to: spec.exitTo, kind: 'zone', note: spec.exitLabel + '；每局离出生点 4–6 个完整区块，位置由联机地图种子决定。' }],
  };
}

for (const id of Object.keys(SPECS)) {
  SPECS[id].id = id;
  BR.levels.register(buildFor(SPECS[id]));
}
})();
