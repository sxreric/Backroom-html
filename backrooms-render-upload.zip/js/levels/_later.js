// 后室 · Level 24–34 的公共生成器
//
// 这些层使用同一套“确定性区块 + 真实迷宫碰撞 + 非碰撞装饰”的骨架：
// - 两端只要拿到同一个 levelSeed，就会生成完全相同的墙、出口和装饰；
// - 墙体由 kit.gridWalls 统一登记碰撞，装饰默认 solid:false，避免装饰物穿模/卡人；
// - 出口使用发光区域而不是把门嵌进随机墙段，减少多人换层时撞墙和重复触发。
//
// 关卡主题参考 The Backrooms Wiki 的 Level 24–34 页面；没有在当前引擎中实现的特殊实体，
// 不用别的实体冒充，只采用项目中已有且行为相近的实体。
(function () {
'use strict';
const BR = window.BR;
const kit = BR.kit;
const U = BR.util;

const CELL = 3;
const N = 8;
const SIZE = CELL * N;
const SPAWN_CELLS = [[1, 1], [1, 6], [6, 1], [6, 6]];
const EXIT_DIRS = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]];

const SPECS = {
  '24': {
    title: 'The Moon', nickname: '月面模型', survivalClass: '1 · Safe / Secure / Unconfirmed Entities',
    layout: 'open', decor: 'moon', height: 3.4, wallTex: 'concrete', floorTex: 'concrete', ceilTex: 'concrete',
    wallColor: 0x8f9498, floorColor: 0xb8bdc0, ceilColor: 0x252d31,
    background: 0x20292e, fog: 58, ambient: { color: 0xb8dce5, intensity: 0.48 }, audio: 'wind-field',
    exitTo: '25', exitLabel: '通往季度中心的月面升降口', exitColor: [0.35, 1.15, 1.45], exitChance: 0.13,
    entities: [{ type: 'death_rat', officialPer1000m2: 0.45 }],
    extraItems: [{ type: 'water_bottle', per1000m2: 0.12 }, { type: 'canned_food', per1000m2: 0.06 }],
  },
  '25': {
    title: 'The Quarter Hub', nickname: '季度中心', survivalClass: '2 · Safe / Unsecure / Low Entity Count',
    layout: 'hub', decor: 'arcade', wallTex: 'concrete', floorTex: 'carpet_light', ceilTex: 'ceiling_tile',
    wallColor: 0x555862, floorColor: 0x626879, ceilColor: 0xaeb5c0,
    background: 0x20242d, fog: 50, ambient: { color: 0xd6ddff, intensity: 0.31 }, audio: 'electrical',
    exitTo: '26', exitLabel: '闪烁街机后的登船通道', exitColor: [1.25, 0.38, 0.85], exitChance: 0.15,
    entities: [{ type: 'faceling', officialPer1000m2: 0.9 }, { type: 'death_rat', officialPer1000m2: 0.55 }],
    extraItems: [{ type: 'candy', per1000m2: 0.12 }, { type: 'soft_drink', per1000m2: 0.08 }],
  },
  '26': {
    title: 'The SS Fun =)', nickname: '欢乐号', survivalClass: '3 · Unsafe / Unsecure / Entity Infestation',
    layout: 'ship', decor: 'ship', wallTex: 'metal', floorTex: 'carpet_light', ceilTex: 'ceiling_tile',
    wallColor: 0x4f6872, floorColor: 0x6c8a8d, ceilColor: 0x9bb7b8,
    background: 0x163238, fog: 44, ambient: { color: 0xb8f0e2, intensity: 0.28 }, audio: 'party',
    exitTo: '27', exitLabel: '船尾的绿色雾门', exitColor: [0.35, 1.55, 0.58], exitChance: 0.14,
    entities: [{ type: 'partygoer_biped', officialPer1000m2: 4.2 }, { type: 'smiler', officialPer1000m2: 1.0 }, { type: 'hound', officialPer1000m2: 0.75 }],
    extraItems: [{ type: 'candy', per1000m2: 0.12 }, { type: 'partygoer_cake', per1000m2: 0.04 }],
  },
  '27': {
    title: 'The Bunker Springs', nickname: '地堡温泉', survivalClass: '1 · Safe / Secure / Unconfirmed Entities',
    layout: 'open', decor: 'spring', height: 3.6, wallTex: 'concrete', floorTex: 'concrete', ceilTex: 'concrete',
    wallColor: 0x596466, floorColor: 0x657b72, ceilColor: 0x777e7c,
    background: 0x293a35, fog: 54, ambient: { color: 0xb7e7d3, intensity: 0.40 }, audio: 'cave',
    exitTo: '28', exitLabel: '温泉后方的草坡出口', exitColor: [0.28, 1.35, 0.75], exitChance: 0.12,
    entities: [],
    extraItems: [{ type: 'water_bottle', per1000m2: 0.14 }, { type: 'cookies', per1000m2: 0.08 }],
  },
  '28': {
    title: 'Final Virtue', nickname: '最后的美德', survivalClass: '2 · Safe / Unsecure / Low Entity Count',
    layout: 'field', decor: 'field', wallTex: 'concrete', floorTex: 'carpet_light', ceilTex: 'ceiling_tile',
    wallColor: 0x6b7567, floorColor: 0x607b52, ceilColor: 0x9aa08e,
    background: 0x344230, fog: 66, ambient: { color: 0xd4e5c2, intensity: 0.32 }, audio: 'wind-field',
    exitTo: '29', exitLabel: '穿过黑色沥青边缘', exitColor: [0.95, 1.15, 0.3], exitChance: 0.14,
    entities: [],
    extraItems: [{ type: 'almond_water_blue', per1000m2: 0.06 }],
  },
  '29': {
    title: 'Hyperian', nickname: '海岛城邦', survivalClass: '2 · Safe / Secure / Unconfirmed Entities',
    layout: 'ocean', decor: 'ocean', wallTex: 'concrete', floorTex: 'carpet_light', ceilTex: 'ceiling_tile',
    wallColor: 0x3d5962, floorColor: 0x3d766d, ceilColor: 0x79a2a2,
    background: 0x183c4b, fog: 70, ambient: { color: 0xb9e7ee, intensity: 0.34 }, audio: 'ocean',
    exitTo: '30', exitLabel: '岛上观测站的白门', exitColor: [0.28, 1.35, 1.5], exitChance: 0.13,
    entities: [{ type: 'faceling', officialPer1000m2: 0.9 }, { type: 'hound', officialPer1000m2: 1.35 }, { type: 'observer', officialPer1000m2: 0.7 }],
    extraItems: [{ type: 'canned_food', per1000m2: 0.10 }, { type: 'canned_tuna', per1000m2: 0.06 }],
  },
  '30': {
    title: 'Shifted Beyond Reality', nickname: '现实之外', survivalClass: '4 · Unsafe / Unstable / Memory Hazard',
    layout: 'memory', decor: 'memory', wallTex: 'concrete', floorTex: 'concrete', ceilTex: 'ceiling_tile',
    wallColor: 0x484252, floorColor: 0x55505f, ceilColor: 0x6f687a,
    background: 0x1c1725, fog: 33, ambient: { color: 0xc7afd8, intensity: 0.18 }, audio: 'dark',
    exitTo: '31', exitLabel: '不会反射自己的镜门', exitColor: [1.3, 0.38, 1.25], exitChance: 0.14,
    entities: [{ type: 'observer', officialPer1000m2: 3.0 }, { type: 'smiler', officialPer1000m2: 1.45 }, { type: 'skin_stealer', officialPer1000m2: 1.0 }, { type: 'wretch', officialPer1000m2: 0.8 }],
    extraItems: [{ type: 'liquid_pain', per1000m2: 0.04 }, { type: 'painkillers', per1000m2: 0.05 }],
  },
  '31': {
    title: 'The Roller Rink', nickname: '滚轴溜冰场', survivalClass: '1 · Safe / Secure / Unconfirmed Entities',
    layout: 'rink', decor: 'rink', wallTex: 'concrete', floorTex: 'carpet_light', ceilTex: 'ceiling_tile',
    wallColor: 0x4d5260, floorColor: 0x8c708a, ceilColor: 0x7c8399,
    background: 0x30273e, fog: 54, ambient: { color: 0xf0c7ee, intensity: 0.34 }, audio: 'party',
    exitTo: '32', exitLabel: '电影院后方的黑色安全门', exitColor: [1.2, 0.38, 1.35], exitChance: 0.12,
    entities: [{ type: 'faceling', officialPer1000m2: 1.35 }],
    extraItems: [{ type: 'soft_drink', per1000m2: 0.10 }, { type: 'chocolate_bar', per1000m2: 0.06 }],
  },
  '32': {
    title: 'Forest of the Skeleton Queen', nickname: '骸骨女王之森', survivalClass: '4 · Unsafe / Unsecure / High Entity Count',
    layout: 'forest', decor: 'forest', wallTex: 'concrete', floorTex: 'carpet_light', ceilTex: 'ceiling_tile',
    wallColor: 0x303b31, floorColor: 0x3c5038, ceilColor: 0x1c261e,
    background: 0x0c140d, fog: 32, ambient: { color: 0xa8c2a1, intensity: 0.13 }, audio: 'wind-field',
    exitTo: '33', exitLabel: '骸骨树根下的商场扶梯', exitColor: [0.65, 1.1, 0.48], exitChance: 0.13,
    entities: [{ type: 'skin_stealer', officialPer1000m2: 2.0 }, { type: 'death_rat', officialPer1000m2: 1.4 }, { type: 'hound', officialPer1000m2: 1.2 }, { type: 'watcher', officialPer1000m2: 0.8 }],
    extraItems: [{ type: 'antibiotics', per1000m2: 0.05 }, { type: 'bandages', per1000m2: 0.06 }],
  },
  '33': {
    title: 'The Infinite Mall', nickname: '无限商场', survivalClass: '3 · Unsafe / Unstable / Entity Infestation',
    layout: 'mall', decor: 'mall', wallTex: 'concrete', floorTex: 'carpet_light', ceilTex: 'ceiling_tile',
    wallColor: 0x6a6e73, floorColor: 0x9a9b95, ceilColor: 0xb0b5b8,
    background: 0x252a2e, fog: 48, ambient: { color: 0xdce2df, intensity: 0.29 }, audio: 'electrical',
    exitTo: '34', exitLabel: '商场货运区的下水道井盖', exitColor: [0.38, 1.1, 1.25], exitChance: 0.15,
    entities: [{ type: 'hound', officialPer1000m2: 1.35 }, { type: 'death_rat', officialPer1000m2: 2.0 }, { type: 'skin_stealer', officialPer1000m2: 1.0 }, { type: 'smiler', officialPer1000m2: 1.2 }, { type: 'duller', officialPer1000m2: 0.75 }],
    extraItems: [{ type: 'microwave_meal', per1000m2: 0.08 }, { type: 'chocolate_bar', per1000m2: 0.08 }],
  },
  '34': {
    title: 'Sewer System', nickname: '下水道系统', survivalClass: '4 · Unsafe / Unsecure / Entity Infestation',
    layout: 'sewer', decor: 'sewer', height: 2.0, wallTex: 'concrete', floorTex: 'concrete', ceilTex: 'concrete',
    wallColor: 0x5b514d, floorColor: 0x443c39, ceilColor: 0x514947,
    background: 0x11100f, fog: 24, ambient: { color: 0x8b918b, intensity: 0.055 }, audio: 'dark', darkness: true,
    exitTo: '35', exitLabel: '积水井下的停车场检修通道', exitColor: [0.25, 0.95, 1.2], exitChance: 0.12,
    entities: [
      { type: 'smiler', officialPer1000m2: 2.8 },
      { type: 'death_rat', officialPer1000m2: 3.4 },
      { type: 'hound', officialPer1000m2: 1.2 },
      { type: 'skin_stealer', officialPer1000m2: 0.35 },
    ],
    extraItems: [
      { type: 'flashlight', per1000m2: 0.10 },
      { type: 'almond_water_expired', per1000m2: 0.08 },
      { type: 'almond_water_blue', per1000m2: 0.05 },
      { type: 'firesalt', per1000m2: 0.05 },
      { type: 'lightning_in_a_bottle', per1000m2: 0.03 },
      { type: 'bandages', per1000m2: 0.08 },
      { type: 'painkillers', per1000m2: 0.05 },
    ],
  },
};

function reserveRect(g, i0, j0, w, d) {
  for (let j = j0; j < j0 + d; j++) for (let i = i0; i < i0 + w; i++) g.reserve(i, j);
}

function materialTable(id, s) {
  kit.mats({
    ['L' + id + ':wall']: { tex: s.wallTex, repeatMeters: s.wallTex === 'metal' ? 2.4 : 2.1, roughness: 0.88, color: s.wallColor },
    ['L' + id + ':floor']: { tex: s.floorTex, repeatMeters: 2.2, roughness: 0.96, color: s.floorColor },
    ['L' + id + ':ceil']: { tex: s.ceilTex, repeatMeters: 1.6, roughness: 0.98, color: s.ceilColor },
    ['L' + id + ':brick']: { tex: 'l3_brick_brown', repeatMeters: 1.55, roughness: 0.96, color: 0x6b5650 },
  });
}

function chooseCell(g, rng, used) {
  const list = g.cells(c => !c.reserved && c.i > 0 && c.i < N - 1 && c.j > 0 && c.j < N - 1 && !used.has(c.i + ':' + c.j));
  if (!list.length) return null;
  const c = list[Math.min(list.length - 1, Math.floor(rng() * list.length))];
  used.add(c.i + ':' + c.j);
  g.reserve(c.i, c.j);
  return c;
}

function parity(v) { return ((v % 2) + 2) % 2; }

function clampCell(v) { return Math.max(1, Math.min(N - 2, v)); }

// 路线完全由 levelSeed 决定：联机双方得到同一出生点和出口，重新开局时
// 又会换一条路线。出口至少跨越两个完整区块，最远可达四个区块。
function levelPlan(levelSeed, s) {
  const rng = U.rng(levelSeed == null ? 0 : levelSeed, 'L' + s.id + ':route-v2');
  const spawn = SPAWN_CELLS[Math.floor(rng() * SPAWN_CELLS.length) % SPAWN_CELLS.length];
  const dir = EXIT_DIRS[Math.floor(rng() * EXIT_DIRS.length) % EXIT_DIRS.length];
  const radius = 2 + Math.floor(rng() * 3);
  const exit = SPAWN_CELLS[Math.floor(rng() * SPAWN_CELLS.length) % SPAWN_CELLS.length];
  return {
    spawnI: spawn[0], spawnJ: spawn[1],
    exitCx: dir[0] * radius, exitCz: dir[1] * radius,
    exitI: exit[0], exitJ: exit[1],
  };
}

function openAndReserve(g, i, j, radius = 1) {
  const ci = clampCell(i);
  const cj = clampCell(j);
  const i0 = Math.max(0, ci - radius);
  const j0 = Math.max(0, cj - radius);
  const i1 = Math.min(N - 1, ci + radius);
  const j1 = Math.min(N - 1, cj + radius);
  g.carve(i0, j0, i1 - i0 + 1, j1 - j0 + 1, { room: true });
  reserveRect(g, i0, j0, i1 - i0 + 1, j1 - j0 + 1);
}

function carveToCenter(g, i, j) {
  const ci = clampCell(i);
  const cj = clampCell(j);
  const mid = 3;
  g.carve(Math.min(ci, mid), cj, Math.abs(ci - mid) + 1, 1, { room: true });
  g.carve(mid, Math.min(cj, mid), 1, Math.abs(cj - mid) + 1, { room: true });
}

// 这些层不再全部共用一张“随机墙迷宫”。先给每种主题一个可辨认的空间骨架，
// 再在骨架上撒装饰。所有 carve 都发生在 gridWalls 之前，避免出现视觉上开了
// 但实际还有碰撞墙的穿模/卡墙问题。
function shapeGrid(g, s, cx, cz) {
  const p = parity(cx + cz);
  switch (s.layout) {
    case 'hub':
      g.carve(1, 1, 6, 6, { room: true });
      g.carve(p ? 0 : 3, p ? 3 : 0, p ? 8 : 2, p ? 2 : 8, { room: true });
      break;
    case 'ship':
      if (p) {
        g.carve(1, 3, 6, 2, { room: true });
        g.carve(3, 1, 2, 6, { room: true });
      } else {
        g.carve(2, 1, 4, 6, { room: true });
        g.carve(1, 2, 6, 4, { room: true });
      }
      break;
    case 'spring':
      g.carve(1, 1, 6, 6, { room: true });
      g.carve(0, 3, 8, 2, { room: true });
      break;
    case 'memory':
      // 四个“记忆房间”由十字走廊串起来；比均匀迷宫更容易形成回头路。
      g.carve(1, 1, 2, 2, { room: true });
      g.carve(5, 1, 2, 2, { room: true });
      g.carve(1, 5, 2, 2, { room: true });
      g.carve(5, 5, 2, 2, { room: true });
      g.carve(3, 1, 2, 6, { room: true });
      g.carve(1, 3, 6, 2, { room: true });
      break;
    case 'mall':
      // 中央十字通道 + 四个店铺岛，出口更像在商场里找货运区。
      g.carve(0, 3, 8, 2, { room: true });
      g.carve(3, 0, 2, 8, { room: true });
      g.carve(1, 1, 2, 2, { room: true });
      g.carve(5, 1, 2, 2, { room: true });
      g.carve(1, 5, 2, 2, { room: true });
      g.carve(5, 5, 2, 2, { room: true });
      break;
    case 'sewer':
      if (p) {
        g.carve(0, 3, 8, 2, { room: true });
        g.carve(3, 1, 2, 6, { room: true });
      } else {
        g.carve(3, 0, 2, 8, { room: true });
        g.carve(1, 3, 6, 2, { room: true });
      }
      break;
    case 'open':
    case 'field':
    case 'ocean':
    case 'rink':
      g.carve(0, 0, N, N, { room: true });
      break;
    default:
      break;
  }
}

function glowStrip(b, x, y, z, w, d, color, rotY = 0, glow = 0.45) {
  b.box(x, y, z, w, 0.035, d, 'kit:glow', { color, glow, solid: false, rotY });
}

function arch(b, x, z, rotY, w, h, color) {
  const t = 0.12;
  b.box(x - w / 2 + t / 2, 0, z, t, h, t, 'kit:prop', { color, solid: false, rotY });
  b.box(x + w / 2 - t / 2, 0, z, t, h, t, 'kit:prop', { color, solid: false, rotY });
  b.box(x, h - t, z, w, t, t, 'kit:prop', { color, solid: false, rotY });
}

// 出口不再是一块随机发光地板：每层只在远离出生点的目标区块放一个
// 可辨认的主题地标。所有部件都不注册碰撞，真正的触发器仍由 kit.exit 管理，
// 这样既不会卡在门框里，也不会因为装饰挡住换层触发。
function exitLandmark(b, s, x, z) {
  if (s.decor === 'sewer') {
    kit.prop.hole(b, x, z, 0, { r: 0.62, rimColor: 0x243437 });
    arch(b, x, z, 0, 1.8, 1.85, 0x687478);
    glowStrip(b, x, 0.08, z, 0.9, 0.05, s.exitColor, 0, 0.75);
    kit.prop.sign(b, x, z - 0.42, 0, { y: 2.0, w: 1.5, h: 0.3, color: 0x4ad2dd, backColor: 0x10282d, solid: false });
    kit.prop.pipe(b, x - 0.85, z, 0, { axis: 'z', length: 2.2, r: 0.12, color: 0x77716d, solid: false });
    return;
  }
  arch(b, x, z, 0, 2.2, 2.2, 0x969da3);
  kit.prop.door(b, x, z, 0, {
    style: s.decor === 'memory' ? 'metal' : 'wood', w: 1.25, h: 2.1,
    solid: false, wall: false, sign: false,
  });
  glowStrip(b, x, 2.0, z - 0.05, 1.45, 0.05, s.exitColor, 0, 0.9);
  kit.prop.sign(b, x, z - 0.55, 0, { y: 2.35, w: 1.45, h: 0.3, color: s.exitColor, backColor: 0x1a160a, solid: false });
  for (let k = 0; k < 3; k++) {
    b.cylinder(x - 0.9 + k * 0.9, 0.025, z + 0.68, 0.08, 0.035, 'kit:glow', {
      segments: 8, color: s.exitColor, glow: 0.5, solid: false,
    });
  }
}

// Level 34 的出生区块做成一个小型“下水道补给站”。位置从未保留的格子里选，
// 因而随机出生点改变后也不会与玩家、出口或其他地标重叠。
function sewerPlayset(b, s, g, used, cx, cz) {
  if (s.id !== '34' || cx !== 0 || cz !== 0) return;
  const cells = [];
  for (let k = 0; k < 4; k++) {
    const c = chooseCell(g, U.rng(k + 34, 'L34:station:' + cx + ':' + cz), used);
    if (c) cells.push(c);
  }
  if (!cells.length) return;
  const vend = cells[0];
  const crate = cells[1] || cells[0];
  const puddle = cells[2] || cells[0];
  const pipe = cells[3] || cells[0];
  kit.prop.vending(b, vend.x, vend.z, Math.PI, {
    color: 0x2f6f6f, glow: 0x5ce8dc, light: true, intensity: 0.25, solid: false,
    items: ['flashlight', 'bandages', 'almond_water_blue', 'firesalt'],
  });
  kit.prop.sign(b, vend.x, vend.z - 0.5, Math.PI, {
    y: 2.0, w: 1.15, h: 0.28, color: 0x5ce8dc, backColor: 0x10282d, solid: false,
  });
  kit.prop.crate(b, crate.x, crate.z, 0, { size: 0.78, color: 0x6f5134, solid: false });
  kit.prop.puddle(b, puddle.x, puddle.z, 0, { rx: 0.82, rz: 0.48, color: 0x244343, ringColor: 0x42bfc0 });
  kit.prop.pipe(b, pipe.x, pipe.z, 0, { axis: 'z', length: 2.2, r: 0.14, color: 0x77716d, solid: false });
  b.light({ x: vend.x, y: 1.7, z: vend.z, color: 0x42d6d0, intensity: 0.3, range: 3.4, flicker: 0.35 });
}

function landmark(b, s, g, rng, used, cx, cz) {
  // 只有出生区块放大型地标；远处区块保留轻量装饰，避免大地图三角面和重复物件爆炸。
  if (cx !== 0 || cz !== 0) return;
  const c = chooseCell(g, rng, used);
  if (!c) return;
  const x = c.x, z = c.z;
  const id = s.id;
  if (s.decor === 'moon') {
    arch(b, x, z, 0, 2.4, 2.1, 0x98a4aa);
    glowStrip(b, x, 1.15, z + 0.07, 1.55, 0.04, [0.35, 1.1, 1.5], 0, 0.9);
    kit.prop.sign(b, x, z - 0.08, 0, { y: 2.28, w: 1.0, h: 0.28, color: 0x6bd4e8, backColor: 0x182327, solid: false });
    kit.prop.pipe(b, x + 0.78, z, 0, { axis: 'y', length: 1.35, r: 0.05, color: 0x68777d, solid: false });
  } else if (s.decor === 'arcade') {
    for (const dx of [-0.9, 0, 0.9]) {
      b.box(x + dx, 0, z, 0.62, 1.05, 0.42, 'kit:prop', { color: 0x222532, solid: false, rotY: Math.PI });
      glowStrip(b, x + dx, 0.86, z - 0.23, 0.38, 0.03, dx === 0 ? [1.2, 0.25, 0.8] : [0.22, 0.75, 1.2], 0, 0.8);
    }
    kit.prop.vending(b, x, z + 0.82, Math.PI, { color: 0x3b4150, solid: false });
    kit.prop.sign(b, x, z - 0.7, Math.PI, { y: 1.65, w: 1.4, h: 0.34, color: 0xf06df5, backColor: 0x201327, solid: false });
  } else if (s.decor === 'ship') {
    b.box(x, 0, z, 2.3, 0.75, 0.52, 'kit:prop', { color: 0x8c9698, solid: false });
    b.box(x, 0.75, z, 2.0, 0.34, 0.46, 'kit:glass', { color: 0x72b4bd, solid: false });
    for (const dx of [-0.72, 0.72]) b.box(x + dx, 0.18, z, 0.12, 0.26, 0.6, 'kit:prop', { color: 0x4e5b60, solid: false });
    glowStrip(b, x, 1.12, z, 1.6, 0.05, [0.22, 1.1, 0.8], 0, 0.8);
    kit.prop.sign(b, x, z - 0.35, 0, { y: 1.42, w: 1.2, h: 0.3, color: 0x6ff0a8, backColor: 0x123527, solid: false });
  } else if (s.decor === 'spring') {
    kit.prop.puddle(b, x, z, 0, { rx: 1.2, rz: 0.8, color: 0x5fc9bd, ringColor: 0xa9f4d3 });
    for (const dx of [-0.65, 0, 0.65]) b.cylinder(x + dx, 0.03, z + 0.62, 0.18, 0.12, 'kit:prop', { segments: 8, color: 0x788b83, solid: false });
    kit.prop.pipe(b, x + 0.95, z - 0.2, 0, { axis: 'y', length: 1.2, r: 0.06, color: 0x6e7d74, solid: false });
  } else if (s.decor === 'field') {
    b.cylinder(x, 0.02, z, 0.38, 0.08, 'kit:prop', { segments: 9, color: 0x6e7650, solid: false });
    for (let k = 0; k < 6; k++) {
      const a = k * Math.PI / 3;
      b.cylinder(x + Math.cos(a) * 0.28, 0.03, z + Math.sin(a) * 0.28, 0.035, 0.6, 'kit:prop', { segments: 5, color: 0x3b5e34, solid: false });
    }
    glowStrip(b, x, 0.52, z, 0.05, 0.65, [0.9, 1.2, 0.35], Math.PI / 2, 0.6);
  } else if (s.decor === 'ocean') {
    for (let k = -2; k <= 2; k++) {
      b.box(x + k * 0.52, 0.02, z, 0.42, 0.08, 1.8, 'kit:prop', { color: 0x755738, solid: false });
      glowStrip(b, x + k * 0.52, 0.09, z, 0.05, 1.5, [0.18, 0.8, 1.2], Math.PI / 2, 0.5);
    }
    b.cylinder(x + 1.25, 0.22, z, 0.22, 0.32, 'kit:prop', { segments: 10, color: 0xf2ac43, solid: false });
  } else if (s.decor === 'memory') {
    for (const dx of [-0.72, 0.72]) {
      b.box(x + dx, 0, z, 0.1, 1.8, 0.85, 'kit:glow', { color: dx < 0 ? [1.1, 0.2, 0.95] : [0.2, 0.85, 1.15], glow: 0.65, solid: false, rotY: 0.12 * dx });
    }
    b.box(x, 0.85, z, 1.5, 0.05, 0.05, 'kit:glow', { color: [1.1, 0.8, 0.3], glow: 0.8, solid: false });
    kit.prop.sign(b, x, z - 0.48, 0, { y: 1.7, w: 1.2, h: 0.3, color: 0xd1a9ff, backColor: 0x21182b, solid: false });
  } else if (s.decor === 'rink') {
    b.cylinder(x, 0.02, z, 1.25, 0.035, 'kit:glow', { segments: 32, color: [0.9, 0.25, 1.1], glow: 0.55, solid: false });
    for (const dx of [-0.85, 0, 0.85]) b.box(x + dx, 0.1, z, 0.55, 0.2, 0.42, 'kit:prop', { color: 0x373444, solid: false });
    kit.prop.sign(b, x, z - 0.4, 0, { y: 1.4, w: 1.5, h: 0.32, color: 0x55ddff, backColor: 0x162537, solid: false });
  } else if (s.decor === 'forest') {
    for (let k = 0; k < 5; k++) {
      const a = k * Math.PI * 0.4;
      const rr = 0.35 + (k % 2) * 0.28;
      b.cylinder(x + Math.cos(a) * rr, 0, z + Math.sin(a) * rr, 0.07, 0.7, 'kit:prop', { segments: 6, color: 0xb8b7a0, solid: false });
    }
    b.cylinder(x, 0.02, z, 0.24, 0.04, 'kit:glow', { segments: 10, color: [0.25, 1.0, 0.45], glow: 0.85, solid: false });
  } else if (s.decor === 'mall') {
    arch(b, x, z, 0, 2.5, 2.2, 0x777e84);
    for (const dx of [-0.72, 0.72]) b.box(x + dx, 0.75, z - 0.04, 0.55, 0.95, 0.08, 'kit:glass', { color: 0x8bd3dd, solid: false });
    kit.prop.vending(b, x, z + 0.55, Math.PI, { color: 0x5e6970, solid: false });
    kit.prop.sign(b, x, z - 0.12, 0, { y: 2.0, w: 1.5, h: 0.32, color: 0xff9c52, backColor: 0x322018, solid: false });
  } else if (s.decor === 'sewer') {
    kit.prop.hole(b, x, z, 0, { r: 0.55, rimColor: 0x29383a });
    kit.prop.pipe(b, x - 0.8, z, 0, { axis: 'z', length: 2.1, r: 0.12, color: 0x737672, solid: false });
    kit.prop.pipe(b, x + 0.8, z, 0, { axis: 'z', length: 2.1, r: 0.06, color: 0x9a6d42, solid: false });
    glowStrip(b, x, 0.05, z, 0.06, 1.3, [0.1, 0.65, 0.75], 0, 0.45);
  }
}

// 每个区块放一个主题结构，而不是只散落相同的小盒子。结构均为非碰撞视觉物，
// 迷宫通行仍只由 gridWalls 决定，因此不会把出口或走廊堵死。
function chunkSetpiece(b, s, g, rng, used, cx, cz) {
  const c = chooseCell(g, rng, used);
  if (!c) return;
  const x = c.x, z = c.z;
  const dist = Math.abs(cx) + Math.abs(cz);

  if (s.decor === 'moon') {
    // PlasticWorks / Bluehole：灰白月壤、矿井、传送带和冷蓝工作灯。
    kit.prop.hole(b, x - 0.55, z, 0, { r: 0.62, rimColor: 0x667076 });
    arch(b, x, z, 0, 2.35, 2.25, 0x849097);
    b.box(x + 0.62, 0.28, z, 1.65, 0.11, 0.48, 'kit:prop', { color: 0x4d5960, solid: false, rotY: 0.08 });
    for (let k = -2; k <= 2; k++) b.cylinder(x + 0.62 + k * 0.3, 0.31, z, 0.055, 0.42, 'kit:prop', { axis: 'z', segments: 8, color: 0x8a9296, solid: false });
    glowStrip(b, x, 2.15, z, 1.85, 0.05, [0.25, 0.95, 1.35], 0, 0.55);
  } else if (s.decor === 'arcade') {
    b.box(x, 0, z + 0.48, 2.55, 2.1, 0.08, 'kit:prop', { color: 0x6c2733, solid: false });
    for (let k = -1; k <= 1; k++) {
      b.box(x + k * 0.78, 0, z, 0.62, 1.15, 0.48, 'kit:prop', { color: 0x25242c, solid: false });
      glowStrip(b, x + k * 0.78, 0.82, z - 0.25, 0.4, 0.035, k === 0 ? [1.15, 0.24, 0.75] : [0.2, 0.75, 1.2], 0, 0.62);
    }
    kit.prop.pipe(b, x + 1.05, z + 0.35, 0, { axis: 'y', length: 1.7, r: 0.11, color: 0x655f5a, solid: false });
  } else if (s.decor === 'ship') {
    // 邮轮甲板栏杆、翻倒餐桌、绿色雾与一小片暗红积水。
    b.box(x, 0.62, z + 0.72, 2.45, 0.08, 0.08, 'kit:prop', { color: 0xb8c4c3, solid: false });
    for (const dx of [-1.05, -0.35, 0.35, 1.05]) b.box(x + dx, 0, z + 0.72, 0.055, 0.72, 0.055, 'kit:prop', { color: 0x9eacaa, solid: false });
    b.cylinder(x, 0.55, z, 0.62, 0.08, 'kit:prop', { segments: 14, color: 0x775244, solid: false, rotY: 0.16 });
    kit.prop.puddle(b, x - 0.75, z - 0.5, 0, { rx: 0.54, rz: 0.25, color: 0x5c151a, ringColor: 0x7b2024 });
    for (const dx of [-0.58, 0.58]) b.plane(x + dx, 0.25, z - 0.72, 0.42, 1.5, 'kit:glow', { facing: '+z', uv: 'solid', color: [0.2, 0.95, 0.42], glow: 0.18, solid: false });
  } else if (s.decor === 'spring') {
    kit.prop.puddle(b, x, z, 0, { rx: 1.28, rz: 0.88, color: 0x62b9aa, ringColor: 0xb1ead2 });
    for (const dx of [-0.48, 0.48]) {
      b.plane(x + dx, 0.25, z + 0.72, 0.55, 1.45, 'kit:glass', { facing: '+z', uv: 'solid', color: 0x80cfc2, opacity: 0.7, solid: false });
      b.cylinder(x + dx, 0, z + 0.8, 0.23, 0.32, 'kit:prop', { segments: 8, color: 0x7d8b84, solid: false });
    }
    for (let k = 0; k < 7; k++) {
      const a = k * Math.PI * 2 / 7;
      b.cylinder(x + Math.cos(a) * 1.05, 0, z + Math.sin(a) * 0.7, 0.12 + (k % 2) * 0.06, 0.2, 'kit:prop', { segments: 7, color: 0x6f7b73, solid: false });
    }
    b.light({ x, y: 1.25, z, color: 0x8be0c9, intensity: 0.38, range: 5.5, flicker: 0 });
  } else if (s.decor === 'field') {
    // 六枚符文巨石围成官方描述中的石阵。
    for (let k = 0; k < 6; k++) {
      const a = k * Math.PI / 3;
      const sx = x + Math.cos(a) * 1.05;
      const sz = z + Math.sin(a) * 1.05;
      b.box(sx, 0, sz, 0.28, 1.75 + (k % 2) * 0.22, 0.46, 'kit:prop', { color: 0x4d584d, solid: false, rotY: -a });
      glowStrip(b, sx, 0.78, sz - 0.24, 0.08, 0.42, [0.28, 0.75, 1.15], 0, 0.35);
    }
    b.cylinder(x, 0.02, z, 0.72, 0.04, 'kit:glow', { segments: 20, color: [0.28, 0.65, 1.0], glow: 0.25, solid: false });
  } else if (s.decor === 'ocean') {
    // 木屋、瞭望塔与小块农田，使岛屿不再只是绿色方块。
    b.box(x, 0, z, 1.5, 1.0, 1.18, 'kit:prop', { color: 0x75553a, solid: false });
    b.box(x, 1.02, z, 1.75, 0.12, 1.42, 'kit:prop', { color: 0x493423, solid: false, rotY: 0.18 });
    for (const dx of [-0.56, 0.56]) b.box(x + dx, 0, z + 0.78, 0.09, 1.75, 0.09, 'kit:prop', { color: 0x5d452f, solid: false });
    b.box(x, 1.45, z + 0.78, 1.38, 0.1, 0.78, 'kit:prop', { color: 0x765a3d, solid: false });
    for (let k = -2; k <= 2; k++) b.box(x + k * 0.3, 0.015, z - 0.84, 0.12, 0.035, 0.9, 'kit:prop', { color: k % 2 ? 0x476b36 : 0x6c5534, solid: false });
  } else if (s.decor === 'memory') {
    // 纸片般的二维“记忆”，两套错位家具强调假现实。
    for (let k = -1; k <= 1; k++) {
      const col = k === 0 ? [1.1, 0.72, 0.18] : (k < 0 ? [1.0, 0.2, 0.85] : [0.18, 0.82, 1.1]);
      b.plane(x + k * 0.72, 0.35 + Math.abs(k) * 0.2, z + k * 0.12, 0.55, 1.45, 'kit:glow', { facing: '+z', uv: 'solid', color: col, glow: 0.42, solid: false });
    }
    for (const dx of [-0.65, 0.65]) kit.prop.chair(b, x + dx, z - 0.68 + dx * 0.12, dx < 0 ? 0 : Math.PI, { color: 0x5f4d68, solid: false, detail: true });
  } else if (s.decor === 'rink') {
    // 木质滑道、星点灯与 DJ 台。
    b.cylinder(x, 0.02, z, 1.32, 0.04, 'kit:prop', { segments: 30, color: 0x9b7048, solid: false });
    b.cylinder(x, 0.065, z, 0.88, 0.025, 'kit:glow', { segments: 30, color: [0.95, 0.22, 1.1], glow: 0.5, solid: false });
    b.box(x, 0, z + 0.68, 1.6, 0.92, 0.52, 'kit:prop', { color: 0x292537, solid: false });
    for (const dx of [-0.42, 0.42]) b.cylinder(x + dx, 0.35, z + 0.38, 0.19, 0.06, 'kit:glow', { axis: 'z', segments: 14, color: dx < 0 ? [0.22, 0.8, 1.2] : [1.1, 0.25, 0.82], glow: 0.55, solid: false });
  } else if (s.decor === 'forest') {
    const h = 2.25;
    b.cylinder(x, 0, z, 0.26, h, 'kit:prop', { segments: 7, color: 0x281a13, solid: false });
    for (let k = -1; k <= 1; k++) {
      b.cylinder(x + k * 0.42, 1.18 + (k & 1) * 0.25, z + 0.18, 0.055, 0.62, 'kit:prop', { segments: 6, color: 0xc5c0a3, solid: false });
      b.box(x + k * 0.42, 1.08, z + 0.18, 0.34, 0.045, 0.055, 'kit:prop', { color: 0xc5c0a3, solid: false, rotY: k * 0.25 });
    }
    if (cx === 0 && cz === 0) b.plane(x, 0.2, z - 0.55, 0.7, 1.75, 'kit:glow', { facing: '+z', uv: 'solid', color: [1.15, 0.34, 0.08], glow: 0.32, solid: false });
  } else if (s.decor === 'mall') {
    // 店铺卷帘；离出生越远，积水、霉斑和植物腐蚀越明显。
    arch(b, x, z, 0, 2.45, 2.2, 0x777c7e);
    for (let k = 0; k < 7; k++) b.box(x, 0.28 + k * 0.24, z + 0.06, 2.05, 0.055, 0.04, 'kit:prop', { color: 0x555b5e, solid: false });
    if (dist >= 2) kit.prop.puddle(b, x - 0.55, z - 0.55, 0, { rx: 0.68, rz: 0.32, color: 0x40565a, ringColor: 0x617879 });
    const vines = Math.min(6, 1 + dist);
    for (let k = 0; k < vines; k++) b.cylinder(x - 0.9 + k * 0.34, 0, z - 0.12, 0.025, 0.45 + 0.12 * k, 'kit:prop', { segments: 4, color: 0x38563a, solid: false, caps: false });
  } else if (s.decor === 'sewer') {
    // 低矮砖石拱、中央污水沟与梯子，出口区会在其上叠加井盖地标。
    arch(b, x, z, 0, 2.35, 1.82, 0x67544d);
    b.box(x, 0.015, z, 0.78, 0.06, 2.5, 'kit:glass', { color: 0x294445, opacity: 0.68, solid: false });
    for (let k = 0; k < 6; k++) b.box(x + 0.95, 0.18 + k * 0.25, z + 0.58, 0.42, 0.045, 0.045, 'kit:prop', { color: 0x8b7a68, solid: false });
    b.box(x + 0.74, 0.12, z + 0.58, 0.045, 1.55, 0.045, 'kit:prop', { color: 0x8b7a68, solid: false });
    b.box(x + 1.16, 0.12, z + 0.58, 0.045, 1.55, 0.045, 'kit:prop', { color: 0x8b7a68, solid: false });
  }
}

function decorate(b, s, x, z, rng) {
  const id = s.id;
  const prop = 'L' + id + ':wall';
  const accent = 'kit:glow';
  if (s.decor === 'moon') {
    b.cylinder(x, 0.02, z, 0.75 + rng() * 0.6, 0.08, 'L' + id + ':floor', { segments: 12, color: 0x71777a, solid: false });
    b.box(x + (rng() - 0.5) * 0.7, 0.04, z + (rng() - 0.5) * 0.7, 0.32, 0.18, 0.28, prop, { color: 0x868b8c, solid: false, rotY: rng() * 6.28 });
    b.cylinder(x + 0.38, 0.12, z - 0.28, 0.035, 0.65, 'kit:prop', { axis: 'z', color: 0x707779, solid: false });
    glowStrip(b, x - 0.3, 0.08, z + 0.28, 0.18, 0.03, [0.35, 0.8, 1.1], 0, 0.25);
  } else if (s.decor === 'arcade') {
    b.box(x, 0, z, 0.72, 1.25, 0.48, 'kit:prop', { color: 0x252839, solid: false, rotY: Math.floor(rng() * 4) * Math.PI / 2 });
    b.box(x, 0.78, z - 0.26, 0.5, 0.28, 0.03, accent, { color: [0.75, 0.22, 1.1], glow: 0.8, solid: false });
    b.cylinder(x - 0.18, 0.52, z - 0.3, 0.025, 0.08, 'kit:glow', { color: [1.0, 0.45, 0.18], glow: 0.5, solid: false });
    b.light({ x, y: 1.1, z, color: 0xb86cff, intensity: 0.18, range: 2.8, flicker: 0 });
  } else if (s.decor === 'ship') {
    const rot = Math.floor(rng() * 4) * Math.PI / 2;
    b.cylinder(x, 0.72, z, 0.045, 1.2, 'kit:prop', { axis: 'x', segments: 6, color: 0xc8d2cf, solid: false, rotY: rot });
    b.box(x, 0, z, 0.9, 0.08, 0.08, 'kit:prop', { color: 0x82a8a8, solid: false, rotY: rot });
    for (const side of [-1, 1]) b.box(x + side * 0.35, 0.48, z, 0.18, 0.32, 0.025, 'kit:glass', { color: 0x55a3ad, solid: false, rotY: rot });
  } else if (s.decor === 'spring') {
    kit.prop.puddle(b, x, z, 0, { rx: 0.8 + rng() * 0.7, rz: 0.55 + rng() * 0.55, color: 0x6fbbb0 });
    b.cylinder(x + 0.55, 0, z - 0.2, 0.28, 0.22, 'kit:prop', { segments: 7, color: 0x69756f, solid: false });
    for (let k = 0; k < 3; k++) b.cylinder(x - 0.45 + k * 0.35, 0.03, z + 0.55, 0.12, 0.07, 'kit:prop', { segments: 7, color: 0x8b9b8c, solid: false });
  } else if (s.decor === 'field') {
    for (let k = 0; k < 3; k++) {
      const dx = (rng() - 0.5) * 0.8, dz = (rng() - 0.5) * 0.8;
      b.cylinder(x + dx, 0, z + dz, 0.035, 0.45 + rng() * 0.45, 'kit:prop', { segments: 4, rTop: 0.01, color: 0x26401e, solid: false, caps: false });
    }
    if (rng() < 0.45) b.cylinder(x + 0.25, 0.42, z - 0.12, 0.09, 0.045, 'kit:glow', { segments: 8, color: [0.9, 1.1, 0.3], glow: 0.7, solid: false });
  } else if (s.decor === 'ocean') {
    b.box(x, 0.03, z, 1.2, 0.08, 0.72, 'kit:prop', { color: 0x6e9a66, solid: false, rotY: rng() * 6.28 });
    b.plane(x, 0.12, z + 0.48, 0.9, 0.06, accent, { facing: '+z', uv: 'solid', color: [0.15, 0.8, 1.0], solid: false });
    b.cylinder(x + 0.45, 0.22, z - 0.3, 0.08, 0.35, 'kit:prop', { segments: 8, color: 0xe39b3c, solid: false });
  } else if (s.decor === 'memory') {
    const col = rng() < 0.5 ? [1.05, 0.25, 0.95] : [0.22, 0.85, 1.1];
    b.box(x, 0, z, 0.08, 1.9, 0.72, accent, { color: col, glow: 0.45, solid: false, rotY: rng() * 6.28 });
    b.box(x + 0.26, 0.75, z - 0.18, 0.32, 0.32, 0.03, accent, { color: col, glow: 0.6, solid: false, rotY: rng() * 6.28 });
  } else if (s.decor === 'rink') {
    b.plane(x, 0.025, z, 1.7, 1.15, accent, { facing: 'up', uv: 'solid', color: rng() < 0.5 ? [1.05, 0.24, 0.8] : [0.25, 0.75, 1.1], solid: false });
    b.box(x, 0.05, z, 1.75, 0.035, 0.045, 'kit:prop', { color: 0xf1d37a, solid: false });
    b.cylinder(x, 0.75, z, 0.035, 1.1, 'kit:glow', { color: [0.55, 0.75, 1.2], glow: 0.3, solid: false });
  } else if (s.decor === 'forest') {
    const h = 1.4 + rng() * 1.3;
    b.cylinder(x, 0, z, 0.15 + rng() * 0.12, h, 'kit:prop', { segments: 6, color: 0x3a2418, solid: false });
    b.cylinder(x, h, z, 0.6 + rng() * 0.35, 0.7, 'kit:prop', { segments: 7, color: 0x243b24, solid: false, caps: false });
    if (rng() < 0.28) b.cylinder(x, 0.02, z, 0.22, 0.04, accent, { segments: 8, color: [0.24, 0.9, 0.45], glow: 0.35, solid: false });
    if (rng() < 0.32) kit.prop.puddle(b, x + 0.32, z + 0.22, 0, { rx: 0.3, rz: 0.2, color: 0x314c38, ring: false });
  } else if (s.decor === 'mall') {
    b.box(x, 0, z, 1.35, 1.05, 0.55, 'kit:prop', { color: 0x777d82, solid: false, rotY: Math.floor(rng() * 4) * Math.PI / 2 });
    b.box(x, 1.08, z, 1.45, 0.12, 0.65, accent, { color: rng() < 0.5 ? [1.2, 0.32, 0.25] : [0.25, 0.8, 1.2], glow: 0.35, solid: false });
    kit.prop.chair(b, x - 0.55, z + 0.52, Math.PI, { color: 0x4b5054, solid: false, detail: false });
    kit.prop.chair(b, x + 0.55, z + 0.52, Math.PI, { color: 0x4b5054, solid: false, detail: false });
  } else if (s.decor === 'sewer') {
    const axis = rng() < 0.5 ? 'x' : 'z';
    b.cylinder(x, 1.35, z, 0.075, 1.8, 'kit:prop', { axis, segments: 7, color: 0x77716d, solid: false, caps: false });
    b.cylinder(x, 0.02, z, 0.42, 0.035, accent, { segments: 14, color: [0.12, 0.45, 0.55], glow: 0.18, solid: false });
    if (rng() < 0.6) kit.prop.puddle(b, x + 0.55, z - 0.35, 0, { rx: 0.55, rz: 0.25, color: 0x263c3b, ringColor: 0x416966 });
  }
}

function buildFor(spec) {
  function defineMaterials() { materialTable(spec.id, spec); }

  function buildChunk(ctx, cx, cz, rng) {
    defineMaterials();
    const H = spec.height || 2.8;
    const b = kit.builder(ctx, cx, cz, rng, { height: H });
    const plan = levelPlan(ctx && ctx.levelSeed, spec);
    const isSpawn = cx === 0 && cz === 0;
    const isExit = cx === plan.exitCx && cz === plan.exitCz;
    const gridOpts = {
      salt: 'L' + spec.id,
      boundaryDensity: spec.layout === 'open' || spec.layout === 'field' || spec.layout === 'ocean' ? 0.18 : 0.34,
      straightness: spec.layout === 'sewer' ? 0.82 : 0.66,
      minOpenings: 2,
      wallDensity: spec.layout === 'open' || spec.layout === 'field' || spec.layout === 'ocean' ? 0.12 : spec.layout === 'sewer' ? 0.55 : 0.36,
      roomChance: spec.layout === 'open' || spec.layout === 'field' || spec.layout === 'ocean' ? 0.08 : 0.30,
      maxRooms: spec.layout === 'sewer' ? 1 : 2,
      roomSize: spec.layout === 'sewer' ? [2, 2] : [2, 3],
      loopChance: spec.layout === 'sewer' ? 0.25 : 0.48,
      pillarChance: spec.layout === 'sewer' ? 0.01 : 0.035,
    };
    const g = kit.grid(b, N, N, gridOpts);
    shapeGrid(g, spec, cx, cz);
    if (isSpawn) {
      carveToCenter(g, plan.spawnI, plan.spawnJ);
      openAndReserve(g, plan.spawnI, plan.spawnJ, 1);
    }
    if (isExit) {
      // 出口区块在建墙前先挖出 3×3 的终点房，确保门永远可达且不嵌墙。
      carveToCenter(g, plan.exitI, plan.exitJ);
      openAndReserve(g, plan.exitI, plan.exitJ, 1);
    }

    kit.gridWalls(b, g, { height: H, matKey: 'L' + spec.id + (spec.decor === 'sewer' ? ':brick' : ':wall'), trim: false });
    kit.prop.floor(b, null, null, 0, { matKey: 'L' + spec.id + ':floor' });
    const openSky = spec.decor === 'field' || spec.decor === 'ocean' || spec.decor === 'forest';
    if (!openSky) kit.prop.ceiling(b, null, null, 0, { matKey: 'L' + spec.id + ':ceil', y: H });

    // 固定顺序消耗随机数，保证房主和客机的几何完全一致。
    for (let j = 0; j < N; j += 2) {
      for (let i = 0; i < N; i += 2) {
        const stateRoll = rng();
        const flickerRoll = rng();
        if (openSky || spec.darkness || spec.decor === 'spring') continue;
        const brokenCut = spec.decor === 'moon' ? 0.68 : spec.decor === 'forest' ? 0.56 : spec.darkness ? 0.72 : 0.05;
        const flickerCut = spec.decor === 'moon' ? 0.78 : spec.darkness ? 0.83 : 0.14;
        const broken = stateRoll < brokenCut;
        const flicker = !broken && stateRoll < flickerCut;
        const c = g.center(i, j);
        // 月面/森林/下水道不是“换了材质的办公室”：少摆几块完整灯板，
        // 留出黑暗和远处的主题灯，画面才会有层次。
        if ((spec.decor === 'moon' && stateRoll < 0.42) || (spec.decor === 'forest' && stateRoll < 0.22)) continue;
        kit.prop.lightPanel(b, c.x, c.z, 0, {
          y: H, state: broken ? 'broken' : flicker ? 'flicker' : 'on',
          flicker: flicker ? 0.25 + flickerRoll * 0.45 : 0,
          color: spec.lightColor || (spec.decor === 'moon' ? 0x75d9ef : spec.decor === 'ship' ? 0x9bf1d0 : 0xd4dedb),
          intensity: spec.darkness ? 0.26 : spec.decor === 'moon' ? 0.5 : 0.72,
          range: spec.darkness ? 4 : spec.decor === 'moon' ? 4.8 : 6,
        });
      }
    }

    const used = new Set();
    landmark(b, spec, g, rng, used, cx, cz);
    sewerPlayset(b, spec, g, used, cx, cz);
    chunkSetpiece(b, spec, g, rng, used, cx, cz);
    const decorCount = isSpawn
      ? 4
      : (spec.layout === 'open' || spec.layout === 'field' || spec.layout === 'ocean' || spec.layout === 'rink' ? 8 : 6);
    for (let k = 0; k < decorCount; k++) {
      const c = chooseCell(g, rng, used);
      if (c) decorate(b, spec, c.x, c.z, rng);
    }

    // 每层只有一个主出口，位于离出生点 2–4 个完整区块的确定性随机位置。
    if (isExit) {
      const c = g.center(plan.exitI, plan.exitJ);
      exitLandmark(b, spec, c.x, c.z);
      kit.exit(b, {
        to: spec.exitTo, kind: 'zone', x: c.x, z: c.z, radius: 0.9,
        label: spec.exitLabel + '（远端出口）',
      });
    }

    kit.gridSpawns(b, g, { safe: isSpawn });
    return b.finish();
  }

  const extraItems = spec.extraItems || [];
  const items = [
    { type: 'almond_water', per1000m2: 1.2 },
    { type: 'food_ration', per1000m2: 0.6 },
  ].concat(extraItems);

  return {
    id: spec.id,
    name: 'Level ' + spec.id,
    title: spec.title,
    nickname: spec.nickname,
    version: 'wikidot-en',
    survivalClass: spec.survivalClass,
    chunkSize: SIZE,
    env: {
      background: spec.background, fogColor: spec.background, fogNear: spec.darkness ? 2 : 5, fogFar: spec.fog,
      ambient: spec.ambient, sanityDrainMul: spec.id === '34' ? 2.0 : spec.id === '30' ? 1.6 : 1.0,
      hungerDrainMul: 1, audio: spec.audio, darkness: !!spec.darkness,
    },
    spawn(ctx) {
      const plan = levelPlan(ctx && ctx.levelSeed, spec);
      // 无论随机到南北哪一角，出生都朝向区块中心，不会第一眼盯着外墙。
      const yaw = plan.spawnJ < N / 2 ? Math.PI : 0;
      return { x: (plan.spawnI + 0.5) * CELL, y: 0, z: (plan.spawnJ + 0.5) * CELL, yaw };
    },
    buildChunk,
    entities: spec.entities,
    items,
    exits: [{ to: spec.exitTo, kind: 'zone', note: spec.exitLabel + '；每局位置不同，距离出生点 2–4 个区块。' }],
  };
}

for (const id of Object.keys(SPECS)) {
  SPECS[id].id = id;
  BR.levels.register(buildFor(SPECS[id]));
}
})();
