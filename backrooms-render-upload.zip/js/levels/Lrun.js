// Level ! · Run For Your Life
// 经典玩法：红色医院长廊、警报、障碍、追逐与远端出口。
(function () {
'use strict';
const BR = window.BR;
const kit = BR.kit;
const U = BR.util;

const S = 16;
const H = 3.1;
const Z0 = 4.1;
const Z1 = 11.9;
const EXIT_CHUNK = 16;
const EXIT_TARGETS = ['0', '1', '4', '5', '11'];

function defineMaterials() {
  kit.mats({
    'Lrun:wall': { tex: 'concrete', repeatMeters: 2.0, roughness: 0.96, color: 0x8f2828 },
    'Lrun:floor': { tex: 'concrete_wet', repeatMeters: 2.1, roughness: 0.94, color: 0x4b2423 },
    'Lrun:ceil': { tex: 'ceiling_tile', repeatMeters: 1.5, roughness: 0.98, color: 0x5a3331 },
    'Lrun:metal': { tex: 'metal', repeatMeters: 1.8, roughness: 0.58, metalness: 0.18, color: 0x57595b },
  });
}

function target(seed) {
  const rng = U.rng(seed == null ? 0 : seed, 'Lrun:exit-v2');
  return EXIT_TARGETS[Math.floor(rng() * EXIT_TARGETS.length) % EXIT_TARGETS.length];
}

function corridorShell(b) {
  const mid = (Z0 + Z1) / 2;
  const width = Z1 - Z0;
  kit.prop.floor(b, S / 2, mid, 0, { w: S, d: width, matKey: 'Lrun:floor' });
  kit.prop.ceiling(b, S / 2, mid, 0, { w: S, d: width, y: H, matKey: 'Lrun:ceil' });
  b.box(S / 2, 0, Z0, S, H, 0.18, 'Lrun:wall', { faces: 'sides', solid: true });
  b.box(S / 2, 0, Z1, S, H, 0.18, 'Lrun:wall', { faces: 'sides', solid: true });
}

function redLamp(b, x, z, broken, phase) {
  kit.prop.lightPanel(b, x, z, 0, {
    y: H, w: 1.3, d: 0.42, color: 0xff2424,
    state: broken ? 'broken' : 'flicker', flicker: broken ? 0 : 0.55 + phase * 0.35,
    intensity: broken ? 0.08 : 0.78, range: 6.2,
  });
  if (!broken) b.light({ x, y: H - 0.2, z, color: 0xff2424, intensity: 0.64, range: 5.8, flicker: 0.62 + phase * 0.25 });
}

function warningStripe(b, x, z, w) {
  for (let k = -3; k <= 3; k++) {
    b.box(x + k * w / 7, 0.018, z, w / 9, 0.025, 0.48, 'kit:glow', {
      color: k % 2 ? [1.2, 0.78, 0.08] : [0.05, 0.04, 0.025], glow: k % 2 ? 0.26 : 0, solid: false, rotY: -0.42,
    });
  }
}

function gurney(b, x, z, rot) {
  b.push(x, z, rot);
  b.box(0, 0.58, 0, 1.85, 0.12, 0.72, 'Lrun:metal', { solid: false });
  b.box(0, 0.7, 0, 1.7, 0.12, 0.62, 'kit:prop', { color: 0xc9c7b9, solid: false });
  for (const sx of [-0.72, 0.72]) for (const sz of [-0.25, 0.25]) b.cylinder(sx, 0.15, sz, 0.12, 0.08, 'kit:prop', { axis: 'z', segments: 10, color: 0x171717, solid: false });
  b.pop();
}

function glowDoorGap(b, x, z, rot) {
  b.box(x, 0.12, z, 0.07, 1.9, 0.62, 'kit:glow', { color: [1.3, 0.04, 0.02], glow: 0.5, solid: false, rotY: rot || 0 });
}

function obstacle(b, cx, rng, index) {
  const x = 2.5 + rng() * 11;
  const z = 6.0 + rng() * 4.0;
  const kind = Math.floor(rng() * 5);
  if (kind === 0) {
    gurney(b, x, z, rng() < 0.5 ? 0.18 : Math.PI - 0.18);
    warningStripe(b, x, z - 0.65, 2.1);
  } else if (kind === 1) {
    for (let k = 0; k < 3; k++) kit.prop.crate(b, x + (k - 1) * 0.7, z + (k % 2) * 0.38, k * 0.18, { size: 0.62 + k * 0.05, color: 0x594134, solid: false });
  } else if (kind === 2) {
    b.box(x, 0, z, 0.16, 1.8, 3.0, 'Lrun:metal', { solid: false, rotY: 0.22 });
    glowDoorGap(b, x + 0.4, z, 0.22);
  } else if (kind === 3) {
    for (let k = -2; k <= 2; k++) kit.prop.pipe(b, x, z + k * 0.5, 0, { axis: 'z', length: 2.4, r: 0.07 + Math.abs(k) * 0.01, color: 0x5c5d5e, solid: false });
    kit.prop.puddle(b, x - 0.8, z, 0, { rx: 0.74, rz: 0.42, color: 0x461616, ringColor: 0x7d1f1f });
  } else {
    const side = index % 2 ? Z0 + 0.28 : Z1 - 0.28;
    kit.prop.door(b, x, side, index % 2 ? 0 : Math.PI, { style: 'metal', w: 1.12, h: 2.2, wall: false, sign: false, solid: false });
    glowDoorGap(b, x, side + (index % 2 ? 0.06 : -0.06), index % 2 ? 0 : Math.PI);
  }
  b.spawn(x + (rng() - 0.5) * 2.2, z + (rng() - 0.5) * 1.5, 'dark');
}

function startRoom(b, rng) {
  corridorShell(b);
  b.box(0.12, 0, (Z0 + Z1) / 2, 0.24, H, Z1 - Z0, 'Lrun:metal', { solid: true });
  kit.prop.door(b, 1.0, Z0 + 0.1, Math.PI / 2, { style: 'metal', w: 1.3, h: 2.25, wall: false, sign: false, solid: false });
  kit.prop.sign(b, 3.4, Z0 + 0.14, Math.PI / 2, { y: 2.25, w: 1.2, h: 0.46, color: [1.3, 0.08, 0.03], backColor: 0x1c0808, solid: false });
  for (let k = 0; k < 4; k++) redLamp(b, 3.0 + k * 3.1, 8, k === 0, rng());
  kit.prop.vending(b, 5.2, Z1 - 0.55, 0, { color: 0x632526, glow: 0xff3838, light: true, intensity: 0.26, solid: false, items: ['almond_water', 'food_ration', 'bandages'] });
  kit.prop.crate(b, 7.0, Z1 - 0.6, 0, { size: 0.72, color: 0x5b4434, solid: false });
  for (let x = 2; x < 15; x += 2) b.spawn(x, 8, 'floor', { safe: true });
  warningStripe(b, 14.1, 8, 2.4);
}

function corridor(b, cx, rng) {
  corridorShell(b);
  for (let k = 0; k < 4; k++) redLamp(b, 1.8 + k * 4.0, 8, rng() < 0.16, rng());
  for (let k = 0; k < 2; k++) obstacle(b, cx, rng, k + cx * 2);
  for (let x = 1.2; x < S; x += 2.2) b.spawn(x, 5.2 + rng() * 5.6, rng() < 0.65 ? 'dark' : 'floor');
  if (cx % 3 === 0) {
    kit.prop.sign(b, 8, Z0 + 0.13, Math.PI / 2, { y: 2.28, w: 1.25, h: 0.38, color: [1.25, 0.08, 0.03], backColor: 0x180707, solid: false });
    warningStripe(b, 8, 8, 3.0);
  }
}

function exitRoom(b, ctx, rng) {
  corridorShell(b);
  for (let k = 0; k < 4; k++) redLamp(b, 1.8 + k * 3.8, 8, false, rng());
  const x = 13.7, z = 8;
  b.box(15.86, 0, z, 0.24, H, Z1 - Z0, 'Lrun:metal', { solid: true });
  kit.prop.door(b, x, z, -Math.PI / 2, { style: 'metal', w: 1.6, h: 2.45, wall: false, sign: false, solid: false });
  b.box(x - 0.08, 2.42, z, 0.06, 0.08, 1.9, 'kit:glow', { color: [0.25, 1.35, 0.52], glow: 0.9, solid: false });
  kit.prop.sign(b, x - 0.12, z, -Math.PI / 2, { y: 2.7, w: 1.5, h: 0.34, color: [0.25, 1.35, 0.52], backColor: 0x0c2114, solid: false });
  kit.exit(b, { to: target(ctx && ctx.levelSeed), kind: 'zone', x, z, radius: 1.05, label: '冲出 Level ! 的绿色安全门', marker: { color: [0.25, 1.35, 0.52], pulse: true } });
  for (let x2 = 1; x2 < 12; x2 += 1.6) b.spawn(x2, 5.0 + rng() * 6, 'dark');
}

function filler(ctx, cx, cz, rng) {
  const b = kit.builder(ctx, cx, cz, rng, { height: H });
  b.box(S / 2, -1, S / 2, S, H + 2, S, 'kit:prop', { color: 0x030202, solid: true });
  return b.finish();
}

function buildChunk(ctx, cx, cz, rng) {
  defineMaterials();
  if (cz !== 0 || cx < 0 || cx > EXIT_CHUNK) return filler(ctx, cx, cz, rng);
  const b = kit.builder(ctx, cx, cz, rng, { height: H });
  if (cx === 0) startRoom(b, rng);
  else if (cx === EXIT_CHUNK) exitRoom(b, ctx, rng);
  else corridor(b, cx, rng);
  return b.finish();
}

BR.levels.register({
  id: 'run', name: 'Level !', title: 'Run For Your Life', nickname: '逃命层',
  version: 'classic-fandom', survivalClass: '5 · Unsafe / Unsecure / Hostile Infestation', chunkSize: S,
  env: {
    background: 0x170303, fogColor: 0x170303, fogNear: 3, fogFar: 30,
    ambient: { color: 0xffc0b5, intensity: 0.17 }, sanityDrainMul: 2.15, hungerDrainMul: 1.28,
    audio: 'chase', darkness: false,
  },
  spawn() { return { x: 2.5, y: 0, z: 8, yaw: -Math.PI / 2 }; },
  buildChunk,
  entities: [
    { type: 'hound', officialPer1000m2: 4.2 },
    { type: 'smiler', officialPer1000m2: 3.2 },
    { type: 'skin_stealer', officialPer1000m2: 2.0 },
    { type: 'wretch', officialPer1000m2: 2.0 },
    { type: 'bacteria', officialPer1000m2: 1.4 },
    { type: 'deathmoth_female', officialPer1000m2: 1.2 },
  ],
  items: [
    { type: 'almond_water', per1000m2: 1.35 },
    { type: 'food_ration', per1000m2: 0.75 },
    { type: 'bandages', per1000m2: 0.10 },
    { type: 'lightning_in_a_bottle', per1000m2: 0.04 },
  ],
  exits: [{ to: '0', kind: 'zone', note: '跑完整条红色医院长廊后从绿色安全门随机前往一个已开放层级。' }],
  enter() { BR.hud.toast('警报响了——别回头，沿红色长廊一直跑！', 4200); },
});
})();
