// Level ! · Run For Your Life
// 经典玩法：红色医院长廊、警报、障碍、追逐与远端出口。
(function () {
'use strict';
const BR = window.BR;
const kit = BR.kit;
const U = BR.util;

const S = 16;
const H = 3.25;
const Z0 = 3.3;
const Z1 = 12.7;
const EXIT_CHUNK = 18;

function defineMaterials() {
  kit.mats({
    'Lrun:wall': { tex: 'concrete', repeatMeters: 2.0, roughness: 0.96, color: 0x8f2828 },
    'Lrun:floor': { tex: 'concrete_wet', repeatMeters: 2.1, roughness: 0.94, color: 0x4b2423 },
    'Lrun:ceil': { tex: 'ceiling_tile', repeatMeters: 1.5, roughness: 0.98, color: 0x5a3331 },
    'Lrun:metal': { tex: 'metal', repeatMeters: 1.8, roughness: 0.58, metalness: 0.18, color: 0x57595b },
    'Lrun:door': { tex: 'metal', repeatMeters: 1.2, roughness: 0.7, metalness: 0.12, color: 0x746463 },
    'Lreality:road': { tex: 'concrete_wet', repeatMeters: 3.2, roughness: 0.98, color: 0x575b5c },
    'Lreality:grass': { tex: 'concrete', repeatMeters: 2.6, roughness: 1, color: 0x6d7d4d },
    'Lreality:house': { tex: 'concrete', repeatMeters: 2.1, roughness: 0.95, color: 0xd3c4aa },
  });
}

function corridorShell(b) {
  const mid = (Z0 + Z1) / 2;
  const width = Z1 - Z0;
  kit.prop.floor(b, S / 2, mid, 0, { w: S, d: width, matKey: 'Lrun:floor' });
  kit.prop.ceiling(b, S / 2, mid, 0, { w: S, d: width, y: H, matKey: 'Lrun:ceil' });
  b.box(S / 2, 0, Z0, S, H, 0.18, 'Lrun:wall', { faces: 'sides', solid: true });
  b.box(S / 2, 0, Z1, S, H, 0.18, 'Lrun:wall', { faces: 'sides', solid: true });
}

function redLamp(b, x, z, broken, phase) {
  kit.prop.lightPanel(b, x, z, 0, {
    y: H, w: 1.3, d: 0.42, color: 0xff2424,
    state: broken ? 'broken' : 'flicker', flicker: broken ? 0 : 0.55 + phase * 0.35,
    intensity: broken ? 0.08 : 0.78, range: 6.2,
  });
  if (!broken) b.light({ x, y: H - 0.2, z, color: 0xff2424, intensity: 0.64, range: 5.8, flicker: 0.62 + phase * 0.25 });
}

function warningStripe(b, x, z, w) {
  for (let k = -3; k <= 3; k++) {
    b.box(x + k * w / 7, 0.018, z, w / 9, 0.025, 0.48, 'kit:glow', {
      color: k % 2 ? [1.2, 0.78, 0.08] : [0.05, 0.04, 0.025], glow: k % 2 ? 0.26 : 0, solid: false, rotY: -0.42,
    });
  }
}

function gurney(b, x, z, rot) {
  b.push(x, z, rot);
  b.box(0, 0.12, 0, 1.86, 0.72, 0.72, 'Lrun:metal', { solid: true });
  b.box(0, 0.72, 0, 1.76, 0.12, 0.64, 'kit:prop', { color: 0xc9c7b9, solid: true });
  for (const sx of [-0.72, 0.72]) for (const sz of [-0.25, 0.25]) b.cylinder(sx, 0.15, sz, 0.12, 0.08, 'kit:prop', { axis: 'z', segments: 10, color: 0x171717, solid: false });
  b.pop();
}

function glowDoorGap(b, x, z, rot) {
  b.box(x, 0.12, z, 0.07, 1.9, 0.62, 'kit:glow', { color: [1.3, 0.04, 0.02], glow: 0.5, solid: false, rotY: rot || 0 });
}

function hospitalDoors(b, cx, rng) {
  // 每块左右各 6 扇病房门。门后仍是实墙，既有“无穷医院”的视觉，也不会穿出地图。
  for (let k = 0; k < 6; k++) {
    const x = 1.15 + k * 2.72;
    for (const side of [-1, 1]) {
      const z = side < 0 ? Z0 + 0.105 : Z1 - 0.105;
      const rot = side < 0 ? 0 : Math.PI;
      b.box(x, 0.05, z, 1.18, 2.34, 0.12, 'Lrun:door', { solid: false, rotY: rot });
      b.box(x, 2.39, z, 1.28, 0.12, 0.15, 'Lrun:metal', { solid: false });
      b.box(x + 0.4, 1.08, z + side * 0.075, 0.07, 0.07, 0.04, 'kit:glow', {
        color: (cx + k) % 5 === 0 ? [1.2, 0.05, 0.03] : [0.58, 0.18, 0.12], glow: 0.35, solid: false,
      });
      if ((cx * 7 + k * 3 + (side > 0 ? 1 : 0)) % 11 === 0) {
        glowDoorGap(b, x - 0.48, z + side * 0.11, rot);
      }
    }
  }
  // 医院护墙板与方向灯带。
  for (const side of [-1, 1]) {
    const z = side < 0 ? Z0 + 0.2 : Z1 - 0.2;
    b.box(S / 2, 1.02, z, S, 0.085, 0.08, 'Lrun:metal', { color: 0x867171, solid: false });
  }
}

function obstacle(b, cx, rng, index) {
  const x = 2.5 + rng() * 11;
  const z = 6.0 + rng() * 4.0;
  const kind = Math.floor(rng() * 5);
  if (kind === 0) {
    gurney(b, x, z, rng() < 0.5 ? 0.18 : Math.PI - 0.18);
    warningStripe(b, x, z - 0.65, 2.1);
  } else if (kind === 1) {
    for (let k = 0; k < 3; k++) kit.prop.crate(b, x + (k - 1) * 0.7, z + (k % 2) * 0.38, k * 0.18, { size: 0.62 + k * 0.05, color: 0x594134, solid: true });
  } else if (kind === 2) {
    b.box(x, 0, z, 0.16, 1.8, 3.0, 'Lrun:metal', { solid: true, rotY: 0.22 });
    glowDoorGap(b, x + 0.4, z, 0.22);
  } else if (kind === 3) {
    for (let k = -2; k <= 2; k++) kit.prop.pipe(b, x, z + k * 0.5, 0, { axis: 'z', length: 2.4, r: 0.07 + Math.abs(k) * 0.01, color: 0x5c5d5e, solid: false });
    b.solid(x - 1.2, 0, z - 1.1, x + 1.2, 0.45, z + 1.1);
    kit.prop.puddle(b, x - 0.8, z, 0, { rx: 0.74, rz: 0.42, color: 0x461616, ringColor: 0x7d1f1f });
  } else {
    // 翻倒的隔离柜只占半边，留出可跑的缝，但本体是真碰撞。
    const side = index % 2 ? Z0 + 1.25 : Z1 - 1.25;
    b.box(x, 0, side, 2.2, 1.3, 0.62, 'Lrun:metal', { color: 0x6f6b67, solid: true, rotY: index % 2 ? 0.18 : -0.18 });
    glowDoorGap(b, x + 0.65, side, index % 2 ? 0.18 : -0.18);
  }
  // 追兵放在障碍旁的可跑区域，不要直接生成在实体碰撞盒里面。
  const spawnZ = z < 8 ? Math.min(Z1 - 0.75, z + 1.8) : Math.max(Z0 + 0.75, z - 1.8);
  b.spawn(x + (rng() - 0.5) * 1.5, spawnZ, 'dark');
}

function startRoom(b, rng) {
  corridorShell(b);
  hospitalDoors(b, 0, rng);
  b.box(0.12, 0, (Z0 + Z1) / 2, 0.24, H, Z1 - Z0, 'Lrun:metal', { solid: true });
  kit.prop.door(b, 1.0, Z0 + 0.1, Math.PI / 2, { style: 'metal', w: 1.3, h: 2.25, wall: false, sign: false, solid: false });
  kit.prop.sign(b, 3.4, Z0 + 0.14, Math.PI / 2, { y: 2.25, w: 1.2, h: 0.46, color: [1.3, 0.08, 0.03], backColor: 0x1c0808, solid: false });
  for (let k = 0; k < 4; k++) redLamp(b, 3.0 + k * 3.1, 8, k === 0, rng());
  kit.prop.vending(b, 5.2, Z1 - 0.55, 0, { color: 0x632526, glow: 0xff3838, light: true, intensity: 0.26, solid: true, items: ['almond_water', 'food_ration', 'bandages'] });
  kit.prop.crate(b, 7.0, Z1 - 0.6, 0, { size: 0.72, color: 0x5b4434, solid: true });
  for (let x = 2; x < 15; x += 2) b.spawn(x, 8, 'floor', { safe: true });
  warningStripe(b, 14.1, 8, 2.4);
}

function corridor(b, cx, rng) {
  corridorShell(b);
  hospitalDoors(b, cx, rng);
  for (let k = 0; k < 4; k++) redLamp(b, 1.8 + k * 4.0, 8, rng() < 0.16, rng());
  for (let k = 0; k < 2; k++) obstacle(b, cx, rng, k + cx * 2);
  for (let x = 1.2; x < S; x += 2.2) b.spawn(x, 5.2 + rng() * 5.6, rng() < 0.65 ? 'dark' : 'floor');
  if (cx % 3 === 0) {
    kit.prop.sign(b, 8, Z0 + 0.13, Math.PI / 2, { y: 2.28, w: 1.25, h: 0.38, color: [1.25, 0.08, 0.03], backColor: 0x180707, solid: false });
    warningStripe(b, 8, 8, 3.0);
  }
}

function exitRoom(b, ctx, rng) {
  corridorShell(b);
  hospitalDoors(b, EXIT_CHUNK, rng);
  for (let k = 0; k < 4; k++) redLamp(b, 1.8 + k * 3.8, 8, false, rng());
  const x = 13.7, z = 8;
  b.box(15.86, 0, z, 0.24, H, Z1 - Z0, 'Lrun:metal', { solid: true });
  kit.prop.door(b, x, z, -Math.PI / 2, { style: 'metal', w: 1.6, h: 2.45, wall: false, sign: false, solid: false });
  b.box(x - 0.08, 2.42, z, 0.06, 0.08, 1.9, 'kit:glow', { color: [0.25, 1.35, 0.52], glow: 0.9, solid: false });
  kit.prop.sign(b, x - 0.12, z, -Math.PI / 2, { y: 2.7, w: 1.5, h: 0.34, color: [0.25, 1.35, 0.52], backColor: 0x0c2114, solid: false });
  kit.exit(b, { to: 'reality', sealed: false, kind: 'zone', x, z, radius: 1.05, label: '冲出 Level !，回到现实', marker: { color: [0.25, 1.35, 0.52], pulse: true } });
  for (let x2 = 1; x2 < 12; x2 += 1.6) b.spawn(x2, 5.0 + rng() * 6, 'dark');
}

function filler(ctx, cx, cz, rng) {
  const b = kit.builder(ctx, cx, cz, rng, { height: H });
  b.box(S / 2, -1, S / 2, S, H + 2, S, 'kit:prop', { color: 0x030202, solid: true });
  return b.finish();
}

function buildChunk(ctx, cx, cz, rng) {
  defineMaterials();
  if (cz !== 0 || cx < 0 || cx > EXIT_CHUNK) return filler(ctx, cx, cz, rng);
  const b = kit.builder(ctx, cx, cz, rng, { height: H });
  if (cx === 0) startRoom(b, rng);
  else if (cx === EXIT_CHUNK) exitRoom(b, ctx, rng);
  else corridor(b, cx, rng);
  return b.finish();
}

BR.levels.register({
  id: 'run', name: 'Level !', title: 'Run For Your Life', nickname: '逃命层',
  version: 'classic-fandom', survivalClass: '5 · Unsafe / Unsecure / Hostile Infestation', chunkSize: S,
  env: {
    background: 0x170303, fogColor: 0x170303, fogNear: 3, fogFar: 30,
    ambient: { color: 0xffc0b5, intensity: 0.17 }, sanityDrainMul: 2.15, hungerDrainMul: 1.28,
    audio: 'chase', darkness: false,
  },
  spawn() { return { x: 2.5, y: 0, z: 8, yaw: -Math.PI / 2 }; },
  buildChunk,
  forceAutoSpawn: true,
  forceSpawnFactor: 0.42,
  entities: [
    { type: 'hound', officialPer1000m2: 4.2 },
    { type: 'smiler', officialPer1000m2: 3.2 },
    { type: 'skin_stealer', officialPer1000m2: 2.0 },
    { type: 'wretch', officialPer1000m2: 2.0 },
    { type: 'bacteria', officialPer1000m2: 1.4 },
    { type: 'deathmoth_female', officialPer1000m2: 1.2 },
  ],
  items: [
    { type: 'almond_water', per1000m2: 1.35 },
    { type: 'food_ration', per1000m2: 0.75 },
    { type: 'bandages', per1000m2: 0.10 },
    { type: 'lightning_in_a_bottle', per1000m2: 0.04 },
  ],
  exits: [{ to: 'reality', kind: 'zone', note: '跑完整条红色医院长廊后冲进绿色安全门，播放逃离动画并回到现实。' }],
  enter() { BR.hud.toast('警报响了——别回头，沿红色长廊一直跑！', 4200); },
});

// 不放进 LEVEL_ORDER：只能从 Level ! 的终点进入，主页层级列表无法直接选择。
let realityOverlayTimer = 0;
function showRealitySequence() {
  clearTimeout(realityOverlayTimer);
  let root = document.getElementById('run-reality-sequence');
  if (!root) {
    const style = document.createElement('style');
    style.id = 'run-reality-style';
    style.textContent =
      '#run-reality-sequence{position:fixed;inset:0;z-index:120;background:#150000;overflow:hidden;pointer-events:none;opacity:1}' +
      '#run-reality-sequence .rr-door{position:absolute;left:50%;top:50%;width:12vw;height:68vh;transform:translate(-50%,-50%) perspective(600px) rotateY(-2deg);background:#f8fff8;box-shadow:0 0 8vw 3vw #fff,0 0 28vw 10vw #70ffac;animation:rrdoor 2.2s ease-in forwards}' +
      '#run-reality-sequence .rr-lines{position:absolute;inset:-20%;background:repeating-linear-gradient(90deg,transparent 0 8vw,rgba(255,20,20,.25) 8.2vw 8.5vw);filter:blur(3px);animation:rrrush 1.8s linear forwards}' +
      '#run-reality-sequence .rr-eye{position:absolute;inset:0;background:#fff;opacity:0;animation:rrblink 4.8s ease forwards}' +
      '#run-reality-sequence .rr-text{position:absolute;inset:0;display:grid;place-content:center;text-align:center;color:#131313;font:800 clamp(28px,5vw,74px)/1.12 system-ui;letter-spacing:.18em;opacity:0;animation:rrtext 5.4s ease forwards}' +
      '#run-reality-sequence .rr-text small{display:block;margin-top:18px;font-size:.25em;letter-spacing:.5em;font-weight:600}' +
      '@keyframes rrdoor{0%{width:8vw;filter:blur(1px)}65%{width:24vw}100%{width:160vw;height:180vh;filter:blur(12px)}}' +
      '@keyframes rrrush{0%{transform:scaleX(1);opacity:.8}100%{transform:scaleX(5);opacity:0}}' +
      '@keyframes rrblink{0%,38%{opacity:0}48%,72%{opacity:1}100%{opacity:0}}' +
      '@keyframes rrtext{0%,58%{opacity:0;transform:scale(.92)}72%,91%{opacity:1;transform:scale(1)}100%{opacity:0}}';
    document.head.appendChild(style);
    root = document.createElement('div');
    root.id = 'run-reality-sequence';
    root.innerHTML = '<div class="rr-lines"></div><div class="rr-door"></div><div class="rr-eye"></div><div class="rr-text">现实<small>YOU ESCAPED</small></div>';
  }
  if (root.parentNode) root.parentNode.removeChild(root);
  document.body.appendChild(root);
  void root.offsetWidth;
  realityOverlayTimer = setTimeout(() => { if (root.parentNode) root.parentNode.removeChild(root); }, 5600);
}

function buildReality(ctx, cx, cz, rng) {
  defineMaterials();
  const b = kit.builder(ctx, cx, cz, rng, { height: 8 });
  kit.prop.floor(b, S / 2, S / 2, 0, { w: S, d: S, matKey: 'Lreality:grass' });
  b.box(S / 2, 0.008, S / 2, 4.6, 0.025, S, 'Lreality:road', { solid: false });
  for (const z of [2, 8, 14]) b.box(S / 2, 0.04, z, 0.12, 0.02, 1.6, 'kit:glow', { color: [1.25, 1.1, 0.42], glow: 0.12, solid: false });
  if (cx === 0 && cz === 0) {
    b.box(12.6, 0, 8, 5.2, 3.0, 5.4, 'Lreality:house', { solid: true });
    b.box(10.05, 0, 8, 0.15, 2.25, 1.18, 'Lrun:door', { color: 0x724b32, solid: false });
    b.box(12.5, 3.0, 8, 5.8, 0.22, 6.0, 'kit:prop', { color: 0x784b36, solid: true, rotY: 0.04 });
    kit.prop.streetlight(b, 5.55, 5.2, 0, { h: 4.3, color: 0x50545a, light: true, intensity: 0.45, solid: true });
  } else if ((Math.abs(cx * 17 + cz * 11) % 4) === 0) {
    kit.prop.streetlight(b, 5.55, 4 + rng() * 8, 0, { h: 4.3, color: 0x50545a, light: true, intensity: 0.35, solid: true });
  }
  for (let k = 0; k < 8; k++) b.spawn(6 + rng() * 4, 1 + rng() * 14, 'floor', { safe: true });
  return b.finish();
}

BR.levels.register({
  id: 'reality', name: 'Reality', title: '现实', nickname: '你逃出来了',
  version: 'special-ending', survivalClass: '终局 · Safe / Secure / No Return', chunkSize: S,
  env: {
    background: 0xa8c9df, fogColor: 0xa8c9df, fogNear: 24, fogFar: 110,
    ambient: { color: 0xfff0d1, intensity: 0.72 }, sanityDrainMul: 0, hungerDrainMul: 0,
    audio: 'wind-field', darkness: false,
  },
  spawn() { return { x: 7.8, y: 0, z: 13.4, yaw: 0 }; },
  buildChunk: buildReality,
  entities: [], items: [], exits: [],
  enter() {
    showRealitySequence();
    setTimeout(() => { if (BR.game.levelId === 'reality') BR.hud.toast('你回到了现实。这里没有返回后室的入口。', 5200); }, 4700);
  },
  leave() {
    clearTimeout(realityOverlayTimer);
    const root = document.getElementById('run-reality-sequence');
    if (root && root.parentNode) root.parentNode.removeChild(root);
  },
});
})();
