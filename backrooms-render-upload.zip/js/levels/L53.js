// Level 53 - "Alone". 参考 https://backrooms-wiki.wikidot.com/level-53
// 单栋住宅而非无限复制的房间；红色正门是通往 Level 0 的游戏连通出口。
(function () {
'use strict';
const BR = window.BR;
const kit = BR.kit;
kit.mats({
  'L53:wall': { tex: 'l13_wall_plaster', repeatMeters: 2.4, roughness: 0.92, color: 0xf0ede5 },
  'L53:floor': { tex: 'l19_floor_attic', repeatMeters: 1.8, roughness: 0.9, color: 0xc6a378 },
  'L53:ceil': { tex: 'ceiling_tile', repeatMeters: 2.0, roughness: 0.98, color: 0xe9e6dc },
  'L53:archive': { tex: 'l53_home_reference', type: 'basic', repeatMeters: 1 },
});
const SIZE = 24;

function buildChunk(ctx, cx, cz, rng) {
  const b = kit.builder(ctx, cx, cz, rng, { height: 2.85 });
  if (cx !== 0 || cz !== 0) return b.finish();
  // 围墙分段留正门，内部分成客厅、厨房、卧室；碰撞与墙片相同。
  b.box(12, 0, 12, 17.5, 0.10, 16.0, 'L53:floor', { solid: false });
  b.box(12, 2.82, 12, 17.5, 0.08, 16.0, 'L53:ceil', { solid: false });
  b.box(3.25, 0, 12, 0.23, 2.85, 16, 'L53:wall', { solid: true });
  b.box(20.75, 0, 12, 0.23, 2.85, 16, 'L53:wall', { solid: true });
  b.box(12, 0, 20, 17.5, 2.85, 0.23, 'L53:wall', { solid: true });
  b.box(7.6, 0, 4, 8.7, 2.85, 0.23, 'L53:wall', { solid: true });
  b.box(16.4, 0, 4, 8.7, 2.85, 0.23, 'L53:wall', { solid: true });
  // 餐厅和卧室的隔墙各有真正可通过的 1.8 m 门洞。
  b.box(8.0, 0, 10.4, 9.3, 2.8, 0.18, 'L53:wall', { solid: true });
  b.box(17.8, 0, 10.4, 5.9, 2.8, 0.18, 'L53:wall', { solid: true });
  b.box(16.0, 0, 16.8, 0.18, 2.8, 6.3, 'L53:wall', { solid: true });
  kit.prop.desk(b, 7.1, 7.2, 0, { color: 0x947654, solid: true, detail: true });
  kit.prop.chair(b, 7.1, 8.1, Math.PI, { color: 0x534836, solid: true, detail: true });
  kit.prop.cabinet(b, 18.5, 7.1, Math.PI, { color: 0x9b8564, solid: true, detail: true });
  kit.prop.bed(b, 18.0, 16.6, Math.PI, { color: 0x897a71, solid: true, detail: true });
  // 有生活痕迹的客厅：沙发、茶几和电视，不在住宅里硬塞售货机。
  b.box(9.2, 0, 13.0, 2.5, 0.68, 0.82, 'kit:prop', { color: 0x717f77, solid: true, bevel: 0.12 });
  b.box(9.2, 0.65, 13.42, 2.5, 0.55, 0.22, 'kit:prop', { color: 0x5e7169, solid: true });
  b.box(9.2, 0, 11.62, 1.35, 0.4, 0.58, 'kit:prop', { color: 0x7f664c, solid: true, bevel: 0.05 });
  b.box(7.4, 1.15, 10.29, 1.6, 0.92, 0.08, 'kit:glass', { color: 0x39494d, solid: false });
  b.box(5.0, 0, 7.1, 0.88, 1.95, 0.85, 'kit:prop', { color: 0xd8d7cf, solid: true, bevel: 0.04 });
  // 橱柜上的灯和窗外恒定的清晨光，来自页面描述；玻璃/光照不是障碍。
  b.box(12.2, 1.2, 20.12, 2.6, 1.1, 0.025, 'kit:glass', { color: 0xa9d8e7, opacity: 0.67, solid: false });
  b.box(12.2, 1.2, 19.99, 2.75, 1.2, 0.09, 'kit:prop', { color: 0xe6dfd2, solid: false });
  // Wiki 的厨房实景图用作厨房墙上的档案画面；场景家具仍是可碰撞 3D 构件。
  b.plane(7.2, 0.55, 10.28, 2.4, 1.55, 'L53:archive', { facing: '+z', uv: 'stretch', solid: false });
  b.light({ x: 12, y: 2.55, z: 13.5, color: 0xffe9c2, intensity: 0.7, range: 10 });
  b.light({ x: 10, y: 2.5, z: 6.7, color: 0xffedce, intensity: 0.5, range: 8 });
  kit.prop.door(b, 12, 4.05, Math.PI, { style: 'wood', color: 0x9e322a, w: 1.45, h: 2.2, wall: false, solid: false });
  kit.exit(b, { to: '0', kind: 'zone', x: 12, z: 5.15, radius: 0.8, label: '红色正门 · 返回 Level 0', marker: { color: [1.0, 0.38, 0.28], pulse: true } });
  for (const [x, z] of [[10.5, 16.5], [12.5, 15.5], [9.5, 13], [11.2, 7.2]]) b.spawn(x, z, 'room', { safe: true });
  return b.finish();
}

BR.levels.register({
  id: '53', name: 'Level 53', title: 'Alone', nickname: '孤独的家', version: 'wikidot-en',
  survivalClass: '0 · Safe / Habitable', chunkSize: SIZE,
  env: { background: 0xa9c4cb, fogColor: 0xa9c4cb, fogNear: 4, fogFar: 32,
    ambient: { color: 0xffecd0, intensity: 0.44 }, audio: 'silence', sanityDrainMul: 0.8 },
  spawn() { return { x: 11.5, y: 0, z: 16.0, yaw: 0 }; },
  buildChunk,
  entities: [{ type: 'faceling', officialPer1000m2: 0.10 }],
  items: [{ type: 'food_ration', per1000m2: 0.4 }, { type: 'water_bottle', per1000m2: 0.4 }],
  exits: [{ to: '0', kind: 'zone', note: '住宅正门；游戏连通出口，并非原文中的固定逐层路径。' }],
});
})();
