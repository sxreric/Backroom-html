// 迁跃浆果 Warpberries（Object 74）
// 来源版本：wikidot-en（data/lore-choices.json 里随机选中）
// URL：https://backrooms-wiki.wikidot.com/object-74
// 许可：CC BY-SA 3.0。注释只用自己的话转述设定。
// 只用这一版（wikidot-cn 的普通纸箱、分布在 Level 1/2 不借）：
//   · 外观：看起来吃起来都像前厅的草莓，带籽；装在盒子里，一盒原本 7 颗；颜色大小没另外写；永远不会烂
//   · 效果：吃下立刻穿过地板，被传送到另一张随机地图；联机时由房主抽签，所有玩家一起过去；
//     页面没提传送持续多久，也没提对饥饿、精神、身体的影响或副作用
//   · 同站 Level 1 页：可以用来逃出必死的局面，但里面的化学物质会让人在新到的层级困很久，只能当最后手段
// 无 hp/饥饿/san 数值（页面明确没提）。
// 游戏规则：单机随机切到另一张已开放地图；联机由房主抽签并广播，所有玩家用同一层级和种子一起切换。
(function () {
'use strict';
const BR = window.BR;
const K = BR.itemKit;
if (!K) { console.error('[items] warpberries 需要先加载 js/items/_kit.js'); return; }

// "一盒原本有 7 颗"：一盒分 7 次吃完
const PER_BOX = 7;

function berry(x, z, tilt, rotY) {
  const T = window.THREE;
  const body = new T.ConeGeometry(0.011, 0.022, 6).rotateX(Math.PI);   // 尖朝下的草莓
  const calyx = new T.CircleGeometry(0.009, 5).rotateX(-Math.PI / 2).translate(0, 0.0112, 0);
  return [K.paint(body, 0xd62a2a), K.paint(calyx, 0x3f8f3a)].map(g => g.rotateZ(tilt).rotateY(rotY).translate(x, 0.028, z));
}

function randomLevel() {
  const cur = String(BR.game && BR.game.levelId || '');
  const order = Array.isArray(BR.LEVEL_ORDER) ? BR.LEVEL_ORDER : [];
  const pool = order.map(String).filter(id => id !== cur && BR.levels && typeof BR.levels.has === 'function' && BR.levels.has(id));
  if (!pool.length) return cur;
  return pool[Math.floor(Math.random() * pool.length)];
}

function warpLocal(to) {
  if (!to || !BR.world || typeof BR.world.goTo !== 'function') return false;
  if (BR.gfx && typeof BR.gfx.flash === 'function') BR.gfx.flash('#000000', 0.9, 1);
  K.toast('脚下一空，迁跃浆果把你带到了 Level ' + to + '……', 2600);
  BR.world.goTo(String(to), { kind: 'noclip' }).catch(err => console.error('[items] 迁跃浆果换层失败', err));
  return true;
}

function multiplayer() {
  return !!(BR.coop && BR.coop.active);
}

function triggerWarp(player) {
  if (!multiplayer()) return warpLocal(randomLevel());
  if (BR.coop.role === 'guest') {
    // 客机不自己决定目标层，避免每个人随机到不同地图；房主收到后统一抽签。
    const ok = typeof BR.coop.emit === 'function' && BR.coop.emit('warpberryRequest', { type: 'warpberries' });
    if (!ok) {
      K.toast('联机同步还没准备好，迁跃浆果没有消耗', 2600);
      return false;
    }
    K.toast('迁跃浆果生效了，等待房主带大家一起跃迁……', 2200);
    return true;
  }
  const to = randomLevel();
  // 事件通道会广播给房间内所有客机；房主本机立即执行，客机收到 warpberryAll 后跟随。
  if (typeof BR.coop.emit === 'function') BR.coop.emit('warpberryAll', { to });
  warpLocal(to);
  return true;
}

// 房主处理客机吃下浆果的请求；只允许房主选目标并广播一次。
BR.bus.on('net:warpberryRequest', () => {
  if (!multiplayer() || BR.coop.role !== 'host') return;
  const to = randomLevel();
  if (typeof BR.coop.emit === 'function') BR.coop.emit('warpberryAll', { to });
  warpLocal(to);
});

// 收到房主的统一跃迁指令。world.goTo 会沿用房主同步的 seed，地图布局保持一致。
BR.bus.on('net:warpberryAll', (p) => {
  if (!multiplayer() || BR.coop.role !== 'guest' || !p || p.to == null) return;
  const to = String(p.to);
  if (!BR.levels || !BR.levels.has(to)) return;
  warpLocal(to);
});

BR.itemTypes.register({
  type: 'warpberries', en: 'Warpberries', zh: '迁跃浆果', version: 'wikidot-en',
  category: 'food',
  stack: 5,
  desc: '一盒像草莓的浆果，一直很新鲜。',
  perBox: PER_BOX,
  icon: K.icon((g, h) => {
    h.poly(g, [[6, 34], [58, 34], [54, 60], [10, 60]], '#c9a46a', 'rgba(90,60,30,0.8)');
    const b = (x, y, r) => {
      h.poly(g, [[x - r, y - r * 0.4], [x + r, y - r * 0.4], [x, y + r * 1.3]], '#d62a2a', 'rgba(110,10,10,0.6)');
      g.fillStyle = '#ffe27a';
      [[-0.4, 0.1], [0.35, 0.05], [0, 0.55], [-0.15, -0.1], [0.2, 0.4]].forEach(s => g.fillRect(x + s[0] * r, y + s[1] * r, 1.4, 1.4));
      h.poly(g, [[x - r * 0.8, y - r * 0.45], [x, y - r * 1.05], [x + r * 0.8, y - r * 0.45]], '#3f8f3a');
    };
    b(18, 26, 8); b(34, 22, 9); b(48, 27, 8); b(26, 36, 7); b(42, 37, 7);
    g.fillStyle = '#b48c52';
    g.fillRect(8, 40, 48, 3);
  }),
  effect: {},
  build() {
    const W = 0.09, D = 0.06, H = 0.032, t = 0.003;
    const kraft = 0xc9a46a;
    const solid = [
      K.paint(K.box(W, t, D, 0, 0), 0xb48c52),
      K.paint(K.box(W, H, t, 0, 0, D / 2), kraft), K.paint(K.box(W, H, t, 0, 0, -D / 2), kraft),
      K.paint(K.box(t, H, D, W / 2, 0, 0), kraft), K.paint(K.box(t, H, D, -W / 2, 0, 0), kraft),
    ];
    const spots = [[-0.03, -0.014, 0.3, 0.2], [-0.01, -0.016, -0.2, 1.3], [0.011, -0.013, 0.25, 2.2], [0.031, -0.015, -0.3, 0.7],
      [-0.02, 0.014, 0.2, 1.8], [0, 0.016, -0.25, 2.9], [0.021, 0.013, 0.3, 0.4]];
    for (const s of spots) solid.push(...berry(s[0], s[1], s[2], s[3]));
    return K.assemble({ name: 'warpberries', scale: 2.0, solid });
  },
  use(player) {
    K.sound('eat');
    // 先确认联机事件能发出，再减少盒内颗数；发送失败时不应白白扣掉物品。
    if (multiplayer() && BR.coop.role === 'guest') {
      const sent = triggerWarp(player);
      if (!sent) return false;
      return K.portion(player, 'warpberries', PER_BOX);
    }
    const done = K.portion(player, 'warpberries', PER_BOX);
    triggerWarp(player);
    return done;
  },
});
})();
