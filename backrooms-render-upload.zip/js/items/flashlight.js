// 手电筒：每局给玩家一把，使用键可开关；手电灯光复用 gfx 的动态灯光池。
(function () {
'use strict';
const BR = window.BR;
const K = BR.itemKit;
if (!K) { console.error('[items] flashlight 需要先加载 js/items/_kit.js'); return; }

let on = false;
let givenThisGame = false;

function setLight(v) {
  on = !!v;
  if (BR.gfx && typeof BR.gfx.setPlayerLight === 'function') BR.gfx.setPlayerLight(on);
}

function giveAtLevelStart() {
  if (givenThisGame || !BR.player || typeof BR.player.addItem !== 'function') return;
  if (typeof BR.player.countOf === 'function' && BR.player.countOf('flashlight') > 0) {
    givenThisGame = true;
    return;
  }
  const n = BR.player.addItem('flashlight', 1);
  if (n > 0) {
    givenThisGame = true;
    K.toast('你获得了手电筒，使用它照亮前方', 2400);
  }
}

BR.bus.on('game:start', () => {
  givenThisGame = false;
  setLight(false);
});
BR.bus.on('game:home', () => {
  givenThisGame = false;
  setLight(false);
});
BR.bus.on('level:enter', giveAtLevelStart);

BR.itemTypes.register({
  type: 'flashlight', en: 'Flashlight', zh: '手电筒', version: 'gameplay',
  category: 'tool',
  stack: 1,
  desc: '一把可靠的手电筒。使用键可以开关，灯光会照亮前方。',
  icon: K.icon((g, h) => {
    // 参考常见游戏物品图标的轮廓：斜放的圆柱握把、宽灯头、浅蓝镜片、侧面开关和一小段光束。
    // 这里用 Canvas 重新绘制，不引用外部图片，缩放到背包小格时仍能一眼认出来。
    g.save();
    g.translate(31, 32);
    g.rotate(-0.38);
    g.fillStyle = 'rgba(152,221,255,0.2)';
    g.beginPath();
    g.moveTo(10, -13); g.lineTo(31, -22); g.lineTo(31, 22); g.lineTo(10, 13); g.closePath(); g.fill();
    h.rr(g, -22, -8, 35, 16, 5);
    g.fillStyle = '#e5ad36'; g.fill();
    g.strokeStyle = '#fff0a2'; g.lineWidth = 2; g.stroke();
    g.fillStyle = '#343a46';
    h.rr(g, 8, -12, 13, 24, 4); g.fill();
    g.fillStyle = '#a8eaff';
    g.beginPath(); g.ellipse(21, 0, 4.5, 9, 0, 0, Math.PI * 2); g.fill();
    g.strokeStyle = '#f3fdff'; g.lineWidth = 1.5; g.stroke();
    g.fillStyle = '#596474';
    h.rr(g, -17, -8, 5, 16, 2); g.fill();
    g.fillStyle = '#202632';
    h.rr(g, -4, -12, 7, 4, 2); g.fill();
    g.fillStyle = '#fff5bd';
    h.rr(g, -2.5, -11, 4, 2.5, 1); g.fill();
    g.restore();
  }),
  effect: {},
  build() {
    const T = window.THREE;
    return K.assemble({
      name: 'flashlight', scale: 1.35,
      solid: [
        K.paint(K.cyl(0.031, 0.034, 0.105, 10, 0.015), 0x303843),
        K.paint(K.cyl(0.037, 0.037, 0.012, 10, 0.12), 0x596573),
        K.paint(K.cyl(0.030, 0.030, 0.018, 10, 0.132), 0x202833),
      ],
      glow: [
        [K.cyl(0.024, 0.024, 0.006, 12, 0.151), 0xeafaff],
        [new T.ConeGeometry(0.075, 0.22, 12, 1, true).rotateX(Math.PI / 2).translate(0, 0.15, -0.11), 0x9cddff, 0.12],
      ],
    });
  },
  use() {
    setLight(!on);
    K.sound('click');
    K.toast(on ? '手电筒已打开' : '手电筒已关闭', 1100);
    return false;
  },
});
})();
