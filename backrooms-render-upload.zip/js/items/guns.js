// 管理员武器物品：模型只作为轻量可拾取 / 可丢弃物接入物品系统。
// 编号按用户最终选择重新排列：
//   /gun 1 = 2 号突击步枪
//   /gun 2 = 3 号紧凑手枪
//   /gun 3 = 4 号防御卡宾枪
//   /gun 4 = 5 号泵动霰弹枪
//   /gun 5 = 备选 3 号全尺寸 SMG
// 模型来源：3DAssets.dev 的 Tactical Shooter Hill Town 系列，页面标注 CC0。
(function () {
'use strict';
const BR = window.BR;
const T = window.THREE;
const K = BR.itemKit;
if (!T || !K || !BR.itemTypes) {
  console.error('[items] guns 需要 THREE、BR.itemKit 和 BR.itemTypes');
  return;
}

// 武器状态和显示模型分离：子弹、装填和射速由状态机控制，命中由房主判定。
// spread 是弧度；同一发的种子在各端一致，画出的弹道与房主判定使用相同散布。
const SPECS = [
  { index: 1, type: 'weapon_attacker_rifle', en: 'Attacker Assault Rifle', zh: '突击步枪', model: 'weapon_attacker_rifle', size: 0.98, color: '#c99e55', icon: 'rifle', damage: 25, range: 60, cooldown: 0.105, mag: 30, reserve: 120, reload: 2.0, auto: true, spread: 0.020, recoil: 0.010, ammo: 'ammo_rifle' },
  { index: 2, type: 'weapon_compact_pistol', en: 'Compact Pistol', zh: '紧凑手枪', model: 'weapon_compact_pistol', size: 0.55, color: '#b5bac5', icon: 'pistol', damage: 34, range: 48, cooldown: 0.22, mag: 15, reserve: 60, reload: 1.35, auto: false, spread: 0.014, recoil: 0.019, ammo: 'ammo_pistol' },
  { index: 3, type: 'weapon_defender_carbine', en: 'Defender Carbine', zh: '防御卡宾枪', model: 'weapon_defender_carbine', size: 0.92, color: '#738493', icon: 'carbine', damage: 37, range: 58, cooldown: 0.19, mag: 20, reserve: 80, reload: 1.8, auto: false, spread: 0.012, recoil: 0.016, ammo: 'ammo_carbine' },
  { index: 4, type: 'weapon_pump_shotgun', en: 'Pump Action Shotgun', zh: '泵动霰弹枪', model: 'weapon_pump_shotgun', size: 1.02, color: '#806346', icon: 'shotgun', damage: 12, range: 30, cooldown: 0.82, mag: 6, reserve: 30, reload: 2.35, auto: false, spread: 0.115, pellets: 7, recoil: 0.04, ammo: 'ammo_shells' },
  { index: 5, type: 'weapon_full_smg', en: 'Full Size SMG', zh: '全尺寸冲锋枪', model: 'weapon_full_smg', size: 0.86, color: '#687786', icon: 'smg', damage: 17, range: 46, cooldown: 0.075, mag: 40, reserve: 160, reload: 1.9, auto: true, spread: 0.033, recoil: 0.008, ammo: 'ammo_smg' },
];

const byIndex = new Map(SPECS.map(s => [s.index, s]));
const byType = new Map(SPECS.map(s => [s.type, s]));
let equipped = null;
const localStates = new Map();
const remoteStates = new Map();
let nextShotId = 0;

function nowMs() { return (window.performance && performance.now) ? performance.now() : Date.now(); }
function freshState(spec) { return { mag: spec.mag, reserve: spec.reserve, reloadUntil: 0, lastShotAt: -1e9, lastShotId: 0, rev: 0, lastServerRev: -1, pending: new Set() }; }
function localState(spec) {
  if (!localStates.has(spec.type)) localStates.set(spec.type, freshState(spec));
  return localStates.get(spec.type);
}
function remoteState(spec, owner) {
  const key = String(owner) + ':' + spec.type;
  if (!remoteStates.has(key)) remoteStates.set(key, freshState(spec));
  return remoteStates.get(key);
}
function finishReload(spec, state, now) {
  if (!state.reloadUntil || now < state.reloadUntil) return false;
  const count = Math.min(spec.mag - state.mag, state.reserve);
  state.mag += count;
  state.reserve -= count;
  state.reloadUntil = 0;
  state.rev++;
  return count > 0;
}
function snapshot(spec, state) {
  const now = nowMs();
  finishReload(spec, state, now);
  return { type: spec.type, mag: state.mag, reserve: state.reserve, reloading: state.reloadUntil > now, reloadMs: Math.max(0, state.reloadUntil - now), rev: state.rev, lastShotId: state.lastShotId };
}
function startReload(spec, state) {
  const now = nowMs();
  finishReload(spec, state, now);
  if (state.reloadUntil || state.mag >= spec.mag || state.reserve <= 0) return false;
  state.reloadUntil = now + spec.reload * 1000;
  state.rev++;
  return true;
}
function ammoState(type) {
  const spec = byType.get(String(type || currentType()));
  return spec ? snapshot(spec, localState(spec)) : null;
}
function refreshControls() {
  if (BR.input && typeof BR.input.refreshButtons === 'function') BR.input.refreshButtons();
}

function equip(type) {
  const spec = byType.get(String(type));
  if (!spec) return false;
  equipped = spec.type;
  if (BR.player) BR.player.weaponType = spec.type;
  localState(spec);
  if (BR.bus && typeof BR.bus.emit === 'function') BR.bus.emit('weapon:equip', { type: spec.type, index: spec.index });
  refreshControls();
  return true;
}

function unequip() {
  if (!equipped && !(BR.player && BR.player.weaponType)) return false;
  equipped = null;
  if (BR.player) BR.player.weaponType = null;
  if (BR.bus && typeof BR.bus.emit === 'function') BR.bus.emit('weapon:equip', { type: null, index: 0 });
  refreshControls();
  return true;
}

function aimFrom(p) {
  p = p || BR.player;
  if (!p) return null;
  const yaw = Number(p.yaw) || 0, pitch = Number(p.pitch) || 0;
  const cp = Math.cos(pitch);
  return {
    origin: { x: Number(p.x) || 0, y: Number(p.y) || 1.62, z: Number(p.z) || 0 },
    dir: { x: -Math.sin(yaw) * cp, y: Math.sin(pitch), z: -Math.cos(yaw) * cp },
  };
}

function cylinderHit(o, d, e, reach) {
  const px = o.x - e.x, pz = o.z - e.z, r = Math.max(0.08, Number(e.r) || 0.35);
  const a = d.x * d.x + d.z * d.z;
  const b = px * d.x + pz * d.z;
  const c = px * px + pz * pz - r * r;
  let lo = 0, hi = reach;
  if (a < 1e-9) {
    if (c > 0) return -1;
  } else {
    const disc = b * b - a * c;
    if (disc < 0) return -1;
    const s = Math.sqrt(disc);
    lo = Math.max(0, (-b - s) / a);
    hi = Math.min(reach, (-b + s) / a);
    if (lo > hi) return -1;
  }
  const y0 = Number(e.y) || 0, y1 = y0 + Math.max(0.2, Number(e.h) || 1.6);
  if (Math.abs(d.y) < 1e-9) return o.y >= y0 && o.y <= y1 ? lo : -1;
  const ya = (y0 - o.y) / d.y, yb = (y1 - o.y) / d.y;
  lo = Math.max(lo, Math.min(ya, yb), 0);
  hi = Math.min(hi, Math.max(ya, yb), reach);
  return lo <= hi ? lo : -1;
}

function trace(origin, dir, reach) {
  let wall = reach;
  if (BR.phys && typeof BR.phys.raycast === 'function') {
    const hit = BR.phys.raycast(origin.x, origin.y, origin.z, dir.x, dir.y, dir.z, reach);
    if (hit && Number.isFinite(hit.dist)) wall = Math.max(0, hit.dist);
  }
  let best = null, bestT = wall;
  const list = K.livingEntities ? K.livingEntities() : [];
  for (const e of list) {
    const t = cylinderHit(origin, dir, e, bestT);
    if (t >= 0 && t < bestT) { best = e; bestT = t; }
  }
  return { entity: best, dist: bestT, wall };
}

function shotSeed(id) { return (Math.imul((id | 0) ^ 0x9e3779b9, 1664525) + 1013904223) >>> 0; }
function bulletDirections(spec, dir, seed, aimed) {
  let n = seed >>> 0;
  const rand = () => { n = (Math.imul(n, 1664525) + 1013904223) >>> 0; return n / 4294967296; };
  const spread = spec.spread * (aimed ? 0.38 : 1);
  const count = spec.pellets || 1;
  const out = [];
  for (let i = 0; i < count; i++) {
    const a = rand() * Math.PI * 2, r = Math.sqrt(rand()) * spread;
    // 构造与瞄准方向垂直的局部平面，避免仰视或俯视时散布畸变。
    const sx = Math.cos(a) * r, sy = Math.sin(a) * r;
    const side = Math.hypot(dir.z, dir.x) || 1;
    const ux = dir.z / side, uz = -dir.x / side;
    const vx = -dir.y * uz, vy = side, vz = dir.y * ux;
    const x = dir.x + ux * sx + vx * sy, y = dir.y + vy * sy, z = dir.z + uz * sx + vz * sy;
    const len = Math.hypot(x, y, z) || 1;
    out.push({ x: x / len, y: y / len, z: z / len });
  }
  return out;
}

function showShot(origin, dir, hit, distance, spec) {
  const start = 0.45;
  const reach = Math.max(start + 0.05, Number(distance) || 18);
  const x = origin.x + dir.x * start, y = origin.y + dir.y * start, z = origin.z + dir.z * start;
  if (BR.effects && typeof BR.effects.addFx === 'function') {
    const flash = new T.Mesh(
      new T.SphereGeometry(0.055, 8, 6),
      new T.MeshBasicMaterial({ color: hit ? 0xfff0a0 : 0xffc452, transparent: true, opacity: 0.95 })
    );
    flash.position.set(x, y, z);
    BR.effects.addFx({ obj: flash, seconds: 0.08, tick(o, t) { o.scale.setScalar(1 + t * 3); o.material.opacity = 0.95 * (1 - t); } });

    // 可见曳光弹：不是把伤害当作“看不见的射线”，而是在枪口到命中点之间画一条很短的亮线。
    // 线只留 0.07 秒，既能看见弹道，又不会在 Level 0 里留下大量常驻几何体。
    const end = new T.Vector3(
      origin.x + dir.x * reach,
      origin.y + dir.y * reach,
      origin.z + dir.z * reach,
    );
    const tracer = new T.Line(
      new T.BufferGeometry().setFromPoints([new T.Vector3(x, y, z), end]),
      new T.LineBasicMaterial({ color: hit ? 0xfff2ad : 0xffc45a, transparent: true, opacity: 0.9, depthWrite: false }),
    );
    tracer.renderOrder = 50;
    BR.effects.addFx({ obj: tracer, seconds: 0.07, tick(o, t) { o.material.opacity = 0.9 * (1 - t); } });
    if (hit) {
      const impact = new T.Mesh(
        new T.SphereGeometry(0.07, 8, 6),
        new T.MeshBasicMaterial({ color: 0xffe4a0, transparent: true, opacity: 0.9, depthWrite: false }),
      );
      impact.position.copy(end);
      BR.effects.addFx({ obj: impact, seconds: 0.12, tick(o, t) { o.scale.setScalar(1 + t * 4); o.material.opacity = 0.9 * (1 - t); } });
    }
  }
  if (BR.audio && typeof BR.audio.play === 'function') {
    try { BR.audio.play('gun_fire', { x: origin.x, y: origin.y, z: origin.z }, { volume: 0.65, rate: spec && spec.index === 4 ? 0.78 : spec && spec.index === 2 ? 1.3 : 1 }); } catch (err) { /* audio is optional */ }
  }
}

function resolveShot(spec, packet) {
  const aim = packet && packet.origin && packet.dir ? packet : aimFrom(BR.player);
  if (!aim) return null;
  const directions = bulletDirections(spec, aim.dir, shotSeed(packet.shotId), packet.aimed === true);
  let best = null, bestDist = spec.range, hits = 0;
  for (const dir of directions) {
    const result = trace(aim.origin, dir, spec.range);
    if (result.dist < bestDist) { bestDist = result.dist; best = result.entity; }
    if (result.entity && K.damageEntity && K.damageEntity(result.entity, spec.damage)) hits++;
  }
  if (BR.entities && typeof BR.entities.makeNoise === 'function') BR.entities.makeNoise(1, 2.8);
  if (BR.bus && typeof BR.bus.emit === 'function') BR.bus.emit('weapon:fire', { type: spec.type, hit: hits > 0, target: best && best.id || null, remote: packet.remote === true });
  return { hit: hits > 0, dist: bestDist, origin: aim.origin, dir: directions[0], shotId: packet.shotId };
}

function remoteFire(type, packet) {
  const spec = byType.get(String(type));
  if (!spec || !packet || !packet.sourceId || !Number.isSafeInteger(packet.shotId) || packet.shotId <= 0) return null;
  const state = remoteState(spec, packet.sourceId);
  const now = nowMs();
  finishReload(spec, state, now);
  if (packet.shotId <= state.lastShotId || state.reloadUntil || state.mag <= 0 || now - state.lastShotAt < spec.cooldown * 1000 - 8) return { rejected: true, ammo: snapshot(spec, state) };
  state.lastShotAt = now;
  state.lastShotId = packet.shotId;
  state.rev++;
  state.mag--;
  const result = resolveShot(spec, Object.assign({}, packet, { remote: true }));
  if (result) showShot(result.origin, result.dir, result.hit, result.dist, spec);
  return Object.assign(result || {}, { ammo: snapshot(spec, state) });
}

function fire(type) {
  const spec = byType.get(String(type));
  if (!spec || currentType() !== spec.type || !BR.player || BR.player.dead) return false;
  const selected = BR.player.inventory && BR.player.inventory[BR.player.selected];
  if (!selected || selected.type !== spec.type) return false;
  const state = localState(spec), now = nowMs();
  finishReload(spec, state, now);
  if (state.reloadUntil || now - state.lastShotAt < spec.cooldown * 1000 - 8) return false;
  if (state.mag <= 0) {
    if (!startReload(spec, state)) K.toast('弹药耗尽', 1100);
    else if (BR.coop && BR.coop.active && BR.coop.role === 'guest' && (!BR.coop.requestGunReload || !BR.coop.requestGunReload({ type: spec.type }))) state.reloadUntil = 0;
    return false;
  }
  const aim = aimFrom(BR.player);
  if (!aim) return false;
  const shotId = ++nextShotId;
  const coop = BR.coop;
  const guest = !!(coop && coop.active && coop.role === 'guest');
  const packet = { type: spec.type, origin: aim.origin, dir: aim.dir, aimed: !!BR.player.aiming, shotId };
  if (guest && (!coop.requestGunFire || !coop.requestGunFire(packet))) return false;
  state.lastShotAt = now;
  state.mag--;
  if (guest) state.pending.add(shotId);
  const visualDir = bulletDirections(spec, aim.dir, shotSeed(shotId), packet.aimed)[0];
  if (guest) {
    const impact = trace(aim.origin, visualDir, spec.range);
    showShot(aim.origin, visualDir, false, impact.dist, spec);
  } else {
    const result = resolveShot(spec, packet);
    if (result) {
      showShot(result.origin, result.dir, result.hit, result.dist, spec);
      if (coop && coop.active && coop.role === 'host' && coop.broadcastGunShot) coop.broadcastGunShot(Object.assign({}, packet, result));
    }
  }
  BR.player.pitch = Math.min(1.48, BR.player.pitch + spec.recoil * (packet.aimed ? 0.55 : 1));
  if (BR.input && typeof BR.input.haptic === 'function') BR.input.haptic(spec.index === 4 ? 28 : 12);
  return false;
}

function reload(type) {
  const spec = byType.get(String(type || currentType()));
  if (!spec || !BR.player || BR.player.dead || currentType() !== spec.type) return false;
  const state = localState(spec);
  if (!startReload(spec, state)) return false;
  const coop = BR.coop;
  if (coop && coop.active && coop.role === 'guest' && (!coop.requestGunReload || !coop.requestGunReload({ type: spec.type }))) {
    state.reloadUntil = 0;
    return false;
  }
  if (BR.audio && BR.audio.play) BR.audio.play('gun_reload', undefined, { volume: 0.5 });
  return true;
}

function remoteReload(type, sourceId) {
  const spec = byType.get(String(type));
  if (!spec || !sourceId) return null;
  const state = remoteState(spec, sourceId);
  startReload(spec, state);
  return snapshot(spec, state);
}

function reconcile(ammo, shotId, rejected) {
  const spec = ammo && byType.get(String(ammo.type));
  if (!spec || !Number.isInteger(ammo.mag) || !Number.isInteger(ammo.reserve)) return;
  const state = localState(spec);
  if (!Number.isInteger(ammo.rev) || ammo.rev < state.lastServerRev) return;
  if (rejected && Number.isInteger(shotId)) state.pending.delete(shotId);
  if (!rejected && Number.isInteger(shotId)) {
    for (const id of state.pending) if (id <= shotId) state.pending.delete(id);
  }
  if (ammo.rev === state.lastServerRev && !rejected) return;
  state.lastServerRev = ammo.rev;
  state.mag = Math.max(0, Math.min(spec.mag, ammo.mag - state.pending.size));
  state.reserve = Math.max(0, Math.min(999, ammo.reserve));
  state.reloadUntil = ammo.reloading ? nowMs() + Math.max(0, Math.min(10000, Number(ammo.reloadMs) || 0)) : 0;
}

function remoteShot(packet) {
  if (!packet || !packet.origin || !packet.dir) return;
  showShot(packet.origin, packet.dir, !!packet.hit, packet.dist, byType.get(String(packet.type)));
}

function addAmmo(type, count) {
  const spec = byType.get(String(type));
  if (!spec || !Number.isInteger(count) || count <= 0 || count > 100) return false;
  const coop = BR.coop;
  if (coop && coop.active && coop.role === 'guest' && (!coop.requestGunAmmo || !coop.requestGunAmmo({ type: spec.type, count }))) return false;
  const state = localState(spec);
  state.reserve = Math.min(999, state.reserve + count);
  return true;
}

function addRemoteAmmo(type, count, sourceId) {
  const spec = byType.get(String(type));
  if (!spec || !sourceId || !Number.isInteger(count) || count <= 0) return null;
  const state = remoteState(spec, sourceId);
  state.reserve = Math.min(999, state.reserve + count);
  state.rev++;
  return snapshot(spec, state);
}

function clearRemote(sourceId) {
  const prefix = String(sourceId) + ':';
  for (const key of remoteStates.keys()) if (key.startsWith(prefix)) remoteStates.delete(key);
}

function update(dt, input) {
  const spec = byType.get(String(currentType()));
  if (!spec) return;
  finishReload(spec, localState(spec), nowMs());
  if (!spec.auto || !input || !input.enabled || !input.held || !input.held('use')) return;
  if (BR.player && BR.player.handleActions && BR.game && BR.game.screen === 'playing') fire(spec.type);
}

function fallback(spec) {
  const root = new T.Group();
  root.name = spec.type + '-fallback';
  const body = new T.Mesh(
    new T.BoxGeometry(spec.size * 0.72, 0.09, 0.18).translate(0, 0.13, 0),
    new T.MeshStandardMaterial({ color: spec.color, roughness: 0.58, metalness: 0.45 })
  );
  const barrel = new T.Mesh(
    new T.CylinderGeometry(0.025, 0.025, spec.size * 0.45, 8).rotateZ(Math.PI / 2).translate(spec.size * 0.38, 0.13, 0),
    new T.MeshStandardMaterial({ color: 0x1b2026, roughness: 0.35, metalness: 0.8 })
  );
  root.add(body, barrel);
  return root;
}

function fitModel(model, target) {
  model.updateMatrixWorld(true);
  const box = new T.Box3().setFromObject(model);
  if (box.isEmpty()) return model;
  const size = box.getSize(new T.Vector3());
  const longest = Math.max(size.x, size.y, size.z);
  if (longest > 1e-5) model.scale.multiplyScalar(target / longest);
  model.updateMatrixWorld(true);
  const fitted = new T.Box3().setFromObject(model);
  const center = fitted.getCenter(new T.Vector3());
  model.position.x -= center.x;
  model.position.z -= center.z;
  model.position.y -= fitted.min.y - 0.025;
  return model;
}

function loadModelInto(root, spec, placeholder) {
  const add = model => {
    if (!model || root.userData.weaponModel) return;
    root.userData.weaponModel = true;
    if (placeholder.parent === root) root.remove(placeholder);
    root.add(fitModel(model, spec.size));
  };
  const sync = BR.assets && typeof BR.assets.modelSync === 'function'
    ? BR.assets.modelSync(spec.model) : null;
  if (sync) {
    add(sync);
    return;
  }
  if (BR.assets && typeof BR.assets.model === 'function') {
    BR.assets.model(spec.model).then(add).catch(err => console.warn('[items] 武器模型加载失败', spec.type, err));
  }
}

function build(spec) {
  const root = new T.Group();
  root.name = spec.type;
  const placeholder = fallback(spec);
  root.add(placeholder);
  loadModelInto(root, spec, placeholder);
  return root;
}

function icon(spec) {
  return K.icon((g, h) => {
    const bg = g.createLinearGradient(0, 0, 64, 64);
    bg.addColorStop(0, '#303944');
    bg.addColorStop(1, '#0e1218');
    h.fillRR(g, 2, 2, 60, 60, 13, bg, '#b4bdc7');
    g.save();
    g.translate(31, 34);
    g.rotate(-0.12);
    g.shadowColor = 'rgba(0,0,0,.8)';
    g.shadowBlur = 3; g.shadowOffsetY = 3;
    const metal = '#d8dee5', dark = '#1a2027', accent = spec.color;
    if (spec.icon === 'pistol') {
      h.fillRR(g, -22, -8, 32, 11, 3, metal, '#11161c');
      h.fillRR(g, -2, 3, 10, 17, 3, dark, '#05070a');
      h.fillRR(g, 9, -5, 19, 6, 2, dark, '#05070a');
      h.fillRR(g, -16, 4, 9, 3, 1, accent, null);
      g.fillStyle = '#f4f7fa'; g.fillRect(2, -6, 7, 2);
    } else {
      // 侧面轮廓：枪托、机匣、弹匣、护木、枪管和准星分开画，五种枪型一眼可区分。
      if (spec.icon === 'shotgun') {
        h.poly(g, [[-27,-5],[-17,-8],[-8,-5],[-8,3],[-18,4],[-28,1]], '#70472b', '#25170e');
        h.fillRR(g, -9, -7, 24, 12, 3, accent, '#10151a');
        h.fillRR(g, 10, -4, 22, 6, 2, '#232a32', '#0c1015');
        h.fillRR(g, -1, 5, 16, 5, 2, '#5b3a25', '#1c120b');
      } else {
        h.poly(g, [[-28,-5],[-17,-7],[-8,-5],[-8,4],[-18,4],[-28,1]], '#3a4650', '#10151a');
        h.fillRR(g, -10, -8, 24, 13, 3, accent, '#10151a');
        h.fillRR(g, -1, 4, 9, 17, 2, dark, '#05070a');
        h.fillRR(g, 11, -4, 25, 6, 2, '#242d36', '#080c11');
        h.fillRR(g, 4, 7, 9, 5, 1, '#333e48', '#0c1116');
      }
      g.fillStyle = '#eef3f7'; g.fillRect(4, -9, 11, 2);
      g.fillStyle = '#f4cf68'; g.fillRect(33, -6, 3, 10);
    }
    g.shadowColor = 'transparent';
    g.restore();
    h.text(g, String(spec.index), 11, 12, 13, '#fff4ba', 'bold');
  });
}

SPECS.forEach(spec => {
  BR.itemTypes.register({
    type: spec.type,
    en: spec.en,
    zh: spec.zh,
    version: 'weapons-1',
    category: 'weapon',
    stack: 1,
    desc: '管理员武器 #' + spec.index + '。使用键 / 左键 / 手机「使用」开火；装弹键 / 手机「装弹」换弹。',
    icon: icon(spec),
    effect: {},
    build() { return build(spec); },
    use() {
      if (currentType() === spec.type) return fire(spec.type);
      equip(spec.type);
      return false;
    },
  });
});

// 弹药盒是普通物品：能通过 /give 取得，也能放进背包、丢下交给队友。
SPECS.forEach(spec => {
  BR.itemTypes.register({
    type: spec.ammo,
    en: spec.en + ' Ammo',
    zh: spec.zh + '弹药',
    category: 'supply',
    stack: 10,
    desc: '使用后给' + spec.zh + '补充 ' + (spec.mag * 2) + ' 发备用子弹。',
    icon: K.icon((g, h) => {
      h.fillRR(g, 6, 6, 52, 52, 7, '#584832', '#d9b873');
      h.fillRR(g, 13, 15, 38, 30, 3, '#a38756', '#261e14');
      g.fillStyle = '#efcb70';
      for (let i = 0; i < 4; i++) h.fillRR(g, 17 + i * 8, 20, 5, 18, 2, '#efcb70', '#523f1f');
      h.text(g, String(spec.index), 10, 12, 12, '#fff4ba', 'bold');
    }),
    effect: {},
    build() {
      const root = new T.Group();
      root.add(new T.Mesh(new T.BoxGeometry(0.28, 0.16, 0.2).translate(0, 0.1, 0), new T.MeshStandardMaterial({ color: 0x756245, roughness: 0.9 })));
      return root;
    },
    use() {
      if (!addAmmo(spec.type, spec.mag * 2)) return false;
      K.toast(spec.zh + '备用弹药 +' + spec.mag * 2, 1400);
      return true;
    },
  });
});

function currentType() { return equipped || (BR.player && BR.player.weaponType) || null; }

function clearEquipped() {
  equipped = null;
  localStates.clear();
  remoteStates.clear();
  nextShotId = 0;
  // 只清装备状态，不动背包；下一局玩家仍可重新选择背包里的枪。
  if (BR.player) BR.player.weaponType = null;
  if (BR.bus && typeof BR.bus.emit === 'function') BR.bus.emit('weapon:equip', { type: null, index: 0 });
  refreshControls();
}

BR.bus.on('game:start', clearEquipped);
BR.bus.on('game:home', clearEquipped);

BR.guns = {
  list: SPECS.slice(),
  typeFromIndex(value) {
    const n = Number.parseInt(String(value || '').trim(), 10);
    const spec = byIndex.get(n);
    return spec ? spec.type : null;
  },
  spec(value) {
    return byType.get(String(value)) || byIndex.get(Number(value)) || null;
  },
  isGun(type) { return byType.has(String(type)); },
  equip,
  unequip,
  current: currentType,
  fire,
  reload,
  update,
  state: ammoState,
  addAmmo,
  addRemoteAmmo,
  clearRemote,
  remoteFire,
  remoteReload,
  remoteShot,
  reconcile,
  model(type) {
    const spec = byType.get(String(type));
    return spec ? build(spec) : null;
  },
};
})();
