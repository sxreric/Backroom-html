// 管理员武器物品：模型只作为轻量可拾取 / 可丢弃物接入物品系统。
// 编号按用户最终选择重新排列：
//   /gun 1 = 2 号突击步枪
//   /gun 2 = 3 号紧凑手枪
//   /gun 3 = 4 号防御卡宾枪
//   /gun 4 = 5 号泵动霰弹枪
//   /gun 5 = 备选 3 号全尺寸 SMG
// 模型来源：3DAssets.dev 的 Tactical Shooter Hill Town 系列，页面标注 CC0。
(function () {
'use strict';
const BR = window.BR;
const T = window.THREE;
const K = BR.itemKit;
if (!T || !K || !BR.itemTypes) {
  console.error('[items] guns 需要 THREE、BR.itemKit 和 BR.itemTypes');
  return;
}

const SPECS = [
  { index: 1, type: 'weapon_attacker_rifle', en: 'Attacker Assault Rifle', zh: '突击步枪', model: 'weapon_attacker_rifle', size: 0.98, color: '#c99e55', icon: 'rifle', damage: 35, range: 60, cooldown: 0.24 },
  { index: 2, type: 'weapon_compact_pistol', en: 'Compact Pistol', zh: '紧凑手枪', model: 'weapon_compact_pistol', size: 0.55, color: '#b5bac5', icon: 'pistol', damage: 20, range: 48, cooldown: 0.18 },
  { index: 3, type: 'weapon_defender_carbine', en: 'Defender Carbine', zh: '防御卡宾枪', model: 'weapon_defender_carbine', size: 0.92, color: '#738493', icon: 'carbine', damage: 30, range: 58, cooldown: 0.30 },
  { index: 4, type: 'weapon_pump_shotgun', en: 'Pump Action Shotgun', zh: '泵动霰弹枪', model: 'weapon_pump_shotgun', size: 1.02, color: '#806346', icon: 'shotgun', damage: 45, range: 36, cooldown: 0.75 },
  { index: 5, type: 'weapon_full_smg', en: 'Full Size SMG', zh: '全尺寸冲锋枪', model: 'weapon_full_smg', size: 0.86, color: '#687786', icon: 'smg', damage: 24, range: 52, cooldown: 0.12 },
];

const byIndex = new Map(SPECS.map(s => [s.index, s]));
const byType = new Map(SPECS.map(s => [s.type, s]));
let equipped = null;
let localShotAt = -1e9;
const remoteShotAt = new Map();

function equip(type) {
  const spec = byType.get(String(type));
  if (!spec) return false;
  equipped = spec.type;
  if (BR.player) BR.player.weaponType = spec.type;
  if (BR.bus && typeof BR.bus.emit === 'function') BR.bus.emit('weapon:equip', { type: spec.type, index: spec.index });
  K.toast('已装备：' + spec.zh, 1300);
  return true;
}

function unequip() {
  if (!equipped && !(BR.player && BR.player.weaponType)) return false;
  equipped = null;
  if (BR.player) BR.player.weaponType = null;
  if (BR.bus && typeof BR.bus.emit === 'function') BR.bus.emit('weapon:equip', { type: null, index: 0 });
  return true;
}

function aimFrom(p) {
  p = p || BR.player;
  if (!p) return null;
  const yaw = Number(p.yaw) || 0, pitch = Number(p.pitch) || 0;
  const cp = Math.cos(pitch);
  return {
    origin: { x: Number(p.x) || 0, y: Number(p.y) || 1.62, z: Number(p.z) || 0 },
    dir: { x: -Math.sin(yaw) * cp, y: Math.sin(pitch), z: -Math.cos(yaw) * cp },
  };
}

function cylinderHit(o, d, e, reach) {
  const px = o.x - e.x, pz = o.z - e.z, r = Math.max(0.08, Number(e.r) || 0.35);
  const a = d.x * d.x + d.z * d.z;
  const b = px * d.x + pz * d.z;
  const c = px * px + pz * pz - r * r;
  let lo = 0, hi = reach;
  if (a < 1e-9) {
    if (c > 0) return -1;
  } else {
    const disc = b * b - a * c;
    if (disc < 0) return -1;
    const s = Math.sqrt(disc);
    lo = Math.max(0, (-b - s) / a);
    hi = Math.min(reach, (-b + s) / a);
    if (lo > hi) return -1;
  }
  const y0 = Number(e.y) || 0, y1 = y0 + Math.max(0.2, Number(e.h) || 1.6);
  if (Math.abs(d.y) < 1e-9) return o.y >= y0 && o.y <= y1 ? lo : -1;
  const ya = (y0 - o.y) / d.y, yb = (y1 - o.y) / d.y;
  lo = Math.max(lo, Math.min(ya, yb), 0);
  hi = Math.min(hi, Math.max(ya, yb), reach);
  return lo <= hi ? lo : -1;
}

function trace(origin, dir, reach) {
  let wall = reach;
  if (BR.phys && typeof BR.phys.raycast === 'function') {
    const hit = BR.phys.raycast(origin.x, origin.y, origin.z, dir.x, dir.y, dir.z, reach);
    if (hit && Number.isFinite(hit.dist)) wall = Math.max(0, hit.dist);
  }
  let best = null, bestT = wall;
  const list = K.livingEntities ? K.livingEntities() : [];
  for (const e of list) {
    const t = cylinderHit(origin, dir, e, bestT);
    if (t >= 0 && t < bestT) { best = e; bestT = t; }
  }
  return { entity: best, dist: bestT, wall };
}

function showShot(origin, dir, hit, distance) {
  const start = 0.45;
  const reach = Math.max(start + 0.05, Number(distance) || 18);
  const x = origin.x + dir.x * start, y = origin.y + dir.y * start, z = origin.z + dir.z * start;
  if (BR.effects && typeof BR.effects.addFx === 'function') {
    const flash = new T.Mesh(
      new T.SphereGeometry(0.055, 8, 6),
      new T.MeshBasicMaterial({ color: hit ? 0xfff0a0 : 0xffc452, transparent: true, opacity: 0.95 })
    );
    flash.position.set(x, y, z);
    BR.effects.addFx({ obj: flash, seconds: 0.08, tick(o, t) { o.scale.setScalar(1 + t * 3); o.material.opacity = 0.95 * (1 - t); } });

    // 可见曳光弹：不是把伤害当作“看不见的射线”，而是在枪口到命中点之间画一条很短的亮线。
    // 线只留 0.07 秒，既能看见弹道，又不会在 Level 0 里留下大量常驻几何体。
    const end = new T.Vector3(
      origin.x + dir.x * reach,
      origin.y + dir.y * reach,
      origin.z + dir.z * reach,
    );
    const tracer = new T.Line(
      new T.BufferGeometry().setFromPoints([new T.Vector3(x, y, z), end]),
      new T.LineBasicMaterial({ color: hit ? 0xfff2ad : 0xffc45a, transparent: true, opacity: 0.9, depthWrite: false }),
    );
    tracer.renderOrder = 50;
    BR.effects.addFx({ obj: tracer, seconds: 0.07, tick(o, t) { o.material.opacity = 0.9 * (1 - t); } });
    if (hit) {
      const impact = new T.Mesh(
        new T.SphereGeometry(0.07, 8, 6),
        new T.MeshBasicMaterial({ color: 0xffe4a0, transparent: true, opacity: 0.9, depthWrite: false }),
      );
      impact.position.copy(end);
      BR.effects.addFx({ obj: impact, seconds: 0.12, tick(o, t) { o.scale.setScalar(1 + t * 4); o.material.opacity = 0.9 * (1 - t); } });
    }
  }
  if (BR.audio && typeof BR.audio.play === 'function') {
    try { BR.audio.play('click', undefined, { volume: 0.55, rate: 1.65 }); } catch (err) { /* audio is optional */ }
  }
}

function authoritativeFire(type, packet) {
  const spec = byType.get(String(type));
  if (!spec) return { hit: false, entity: null };
  const p = packet || {};
  const key = String(p.sourceId || 'local');
  const now = (window.performance && performance.now) ? performance.now() : Date.now();
  const last = remoteShotAt.get(key) || -1e9;
  if (now - last < spec.cooldown * 1000) return { hit: false, entity: null, throttled: true };
  remoteShotAt.set(key, now);
  const aim = p.origin && p.dir ? p : aimFrom(BR.player);
  if (!aim) return { hit: false, entity: null };
  const hit = trace(aim.origin, aim.dir, spec.range);
  // 开枪是全场最响的动作之一：房主上的实体 AI 会在短时间内听到它，
  // 客机的 gunFire 也会走到这里，所以不会出现“只有房主开枪才吸怪”。
  if (BR.entities && typeof BR.entities.makeNoise === 'function') BR.entities.makeNoise(1, 2.8);
  if (hit.entity && K.damageEntity) K.damageEntity(hit.entity, spec.damage);
  BR.bus.emit('weapon:fire', { type: spec.type, hit: !!hit.entity, target: hit.entity ? hit.entity.id : null, remote: key !== 'local' });
  return { hit: !!hit.entity, entity: hit.entity, dist: hit.dist, origin: aim.origin, dir: aim.dir };
}

function fire(type) {
  const spec = byType.get(String(type));
  if (!spec) return false;
  const now = (window.performance && performance.now) ? performance.now() : Date.now();
  if (now - localShotAt < spec.cooldown * 1000) return false;
  localShotAt = now;
  const aim = aimFrom(BR.player);
  if (!aim) return false;
  const coop = BR.coop;
  const guest = !!(coop && coop.active && coop.role === 'guest');
  if (guest && typeof coop.requestGunFire === 'function') {
    coop.requestGunFire({ type: spec.type, origin: aim.origin, dir: aim.dir });
    showShot(aim.origin, aim.dir, false, spec.range);
    return false;
  }
  const result = authoritativeFire(spec.type, { origin: aim.origin, dir: aim.dir, sourceId: 'local' });
  showShot(aim.origin, aim.dir, result.hit, result.dist || spec.range);
  if (coop && coop.active && coop.role === 'host' && typeof coop.broadcastGunShot === 'function') {
    coop.broadcastGunShot({ type: spec.type, origin: aim.origin, dir: aim.dir, hit: result.hit, dist: result.dist });
  }
  return false;
}

function remoteFire(type, packet) {
  const result = authoritativeFire(type, Object.assign({}, packet, { sourceId: packet && packet.sourceId || 'remote' }));
  if (result.origin && result.dir) showShot(result.origin, result.dir, result.hit, result.dist);
  return result;
}

function remoteShot(packet) {
  if (!packet || !packet.origin || !packet.dir) return;
  showShot(packet.origin, packet.dir, !!packet.hit, packet.dist);
}

function fallback(spec) {
  const root = new T.Group();
  root.name = spec.type + '-fallback';
  const body = new T.Mesh(
    new T.BoxGeometry(spec.size * 0.72, 0.09, 0.18).translate(0, 0.13, 0),
    new T.MeshStandardMaterial({ color: spec.color, roughness: 0.58, metalness: 0.45 })
  );
  const barrel = new T.Mesh(
    new T.CylinderGeometry(0.025, 0.025, spec.size * 0.45, 8).rotateZ(Math.PI / 2).translate(spec.size * 0.38, 0.13, 0),
    new T.MeshStandardMaterial({ color: 0x1b2026, roughness: 0.35, metalness: 0.8 })
  );
  root.add(body, barrel);
  return root;
}

function fitModel(model, target) {
  model.updateMatrixWorld(true);
  const box = new T.Box3().setFromObject(model);
  if (box.isEmpty()) return model;
  const size = box.getSize(new T.Vector3());
  const longest = Math.max(size.x, size.y, size.z);
  if (longest > 1e-5) model.scale.multiplyScalar(target / longest);
  model.updateMatrixWorld(true);
  const fitted = new T.Box3().setFromObject(model);
  const center = fitted.getCenter(new T.Vector3());
  model.position.x -= center.x;
  model.position.z -= center.z;
  model.position.y -= fitted.min.y - 0.025;
  return model;
}

function loadModelInto(root, spec, placeholder) {
  const add = model => {
    if (!model || root.userData.weaponModel) return;
    root.userData.weaponModel = true;
    if (placeholder.parent === root) root.remove(placeholder);
    root.add(fitModel(model, spec.size));
  };
  const sync = BR.assets && typeof BR.assets.modelSync === 'function'
    ? BR.assets.modelSync(spec.model) : null;
  if (sync) {
    add(sync);
    return;
  }
  if (BR.assets && typeof BR.assets.model === 'function') {
    BR.assets.model(spec.model).then(add).catch(err => console.warn('[items] 武器模型加载失败', spec.type, err));
  }
}

function build(spec) {
  const root = new T.Group();
  root.name = spec.type;
  const placeholder = fallback(spec);
  root.add(placeholder);
  loadModelInto(root, spec, placeholder);
  return root;
}

function icon(spec) {
  return K.icon((g, h) => {
    const bg = g.createLinearGradient(0, 0, 64, 64);
    bg.addColorStop(0, '#303944');
    bg.addColorStop(1, '#0e1218');
    h.fillRR(g, 2, 2, 60, 60, 13, bg, '#b4bdc7');
    g.save();
    g.translate(31, 34);
    g.rotate(-0.12);
    g.shadowColor = 'rgba(0,0,0,.8)';
    g.shadowBlur = 3; g.shadowOffsetY = 3;
    const metal = '#d8dee5', dark = '#1a2027', accent = spec.color;
    if (spec.icon === 'pistol') {
      h.fillRR(g, -22, -8, 32, 11, 3, metal, '#11161c');
      h.fillRR(g, -2, 3, 10, 17, 3, dark, '#05070a');
      h.fillRR(g, 9, -5, 19, 6, 2, dark, '#05070a');
      h.fillRR(g, -16, 4, 9, 3, 1, accent, null);
      g.fillStyle = '#f4f7fa'; g.fillRect(2, -6, 7, 2);
    } else {
      // 侧面轮廓：枪托、机匣、弹匣、护木、枪管和准星分开画，五种枪型一眼可区分。
      if (spec.icon === 'shotgun') {
        h.poly(g, [[-27,-5],[-17,-8],[-8,-5],[-8,3],[-18,4],[-28,1]], '#70472b', '#25170e');
        h.fillRR(g, -9, -7, 24, 12, 3, accent, '#10151a');
        h.fillRR(g, 10, -4, 22, 6, 2, '#232a32', '#0c1015');
        h.fillRR(g, -1, 5, 16, 5, 2, '#5b3a25', '#1c120b');
      } else {
        h.poly(g, [[-28,-5],[-17,-7],[-8,-5],[-8,4],[-18,4],[-28,1]], '#3a4650', '#10151a');
        h.fillRR(g, -10, -8, 24, 13, 3, accent, '#10151a');
        h.fillRR(g, -1, 4, 9, 17, 2, dark, '#05070a');
        h.fillRR(g, 11, -4, 25, 6, 2, '#242d36', '#080c11');
        h.fillRR(g, 4, 7, 9, 5, 1, '#333e48', '#0c1116');
      }
      g.fillStyle = '#eef3f7'; g.fillRect(4, -9, 11, 2);
      g.fillStyle = '#f4cf68'; g.fillRect(33, -6, 3, 10);
    }
    g.shadowColor = 'transparent';
    g.restore();
    h.text(g, String(spec.index), 11, 12, 13, '#fff4ba', 'bold');
  });
}

SPECS.forEach(spec => {
  BR.itemTypes.register({
    type: spec.type,
    en: spec.en,
    zh: spec.zh,
    version: 'weapons-1',
    category: 'weapon',
    stack: 1,
    desc: '管理员武器 #' + spec.index + '。选中后按 F、鼠标左键或手机「使用」开火；第一次使用会先装备。',
    icon: icon(spec),
    effect: {},
    build() { return build(spec); },
    use() {
      if (currentType() === spec.type) return fire(spec.type);
      equip(spec.type);
      return false;
    },
  });
});

function currentType() { return equipped || (BR.player && BR.player.weaponType) || null; }

function clearEquipped() {
  equipped = null;
  localShotAt = -1e9;
  // 只清装备状态，不动背包；下一局玩家仍可重新选择背包里的枪。
  if (BR.player) BR.player.weaponType = null;
  if (BR.bus && typeof BR.bus.emit === 'function') BR.bus.emit('weapon:equip', { type: null, index: 0 });
}

BR.bus.on('game:start', clearEquipped);
BR.bus.on('game:home', clearEquipped);

BR.guns = {
  list: SPECS.slice(),
  typeFromIndex(value) {
    const n = Number.parseInt(String(value || '').trim(), 10);
    const spec = byIndex.get(n);
    return spec ? spec.type : null;
  },
  spec(value) {
    return byType.get(String(value)) || byIndex.get(Number(value)) || null;
  },
  isGun(type) { return byType.has(String(type)); },
  equip,
  unequip,
  current: currentType,
  fire,
  remoteFire,
  remoteShot,
  model(type) {
    const spec = byType.get(String(type));
    return spec ? build(spec) : null;
  },
};
})();
