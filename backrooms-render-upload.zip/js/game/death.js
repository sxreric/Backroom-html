// 后室 · 死亡结算：死因、存活时长、当前层级、到过的最深层级；「继续」原地重生 /「返回主页」
// 接口见 ARCHITECTURE.md 第 12 节 BR.death。DOM 由本文件在 #ui 里创建（class 前缀 death-），样式在 css/game.css
// 补充约定（与 hud.pause 对称）：
//   show() 把 BR.game.screen 从 playing/paused 切到 'dead'，并置 BR.input.enabled = false ——
//     input 关闭时会退出指针锁定；否则锁定状态下鼠标事件全落在画布上，结算按钮根本点不到
//   「继续」：收起 → screen 'dead' 回 'playing' 并打开输入 → emit 'death:continue'（respawnInPlace 由监听方调）
//     → 同步调 BR.input.lock()：桌面指针锁定只能在用户手势的调用栈里请求
//   「返回主页」：收起 → emit 'game:home'。不锁指针（主页要用鼠标点菜单），输入保持禁用
//   弹出后 ARM_MS 内按钮不响应：死的那一下玩家往往正在连点，免得误触直接重生或丢掉整局
//   game:start / game:home 时自动收起；player:respawn（别的路径复活）时收起并恢复 screen 和输入
//   联机时在按钮组下面补一个开关麦（.death-mic，惰性创建，不带 death-btn 类），同样受 ARM_MS 保护
//   空格是游戏里的「互动」，死前常在连按：结算显示期间拦掉空格的 keydown / keypress / keyup（按钮在 keyup 合成 click），
//     万一还是合成了 click，空格后 SPACE_CLICK_MS 内键盘来的 click（detail 为 0）也不认（按下 Enter 时清掉这个时刻：Enter 合成的照认）。只认 Enter 和点击：
//     焦点不在结算按钮上（点过面板空白处）时按 Enter 也等于「继续」。input.js 在 screen 为 'dead' 时也拦空格，两层都拦
//   额外只读：visible
(function () {
'use strict';
const BR = window.BR;

// ---------- 常量 ----------
const ARM_MS = 800;
// 空格按下 / 松开后这么久内、由键盘合成的 click 一律不认
const SPACE_CLICK_MS = 400;
const STYLE_RE = /(^|\/)css\/game\.css([?#]|$)/;
const SELF_RE = /js\/game\/death\.js([?#].*)?$/;
// currentScript 只在脚本同步执行期间有值，必须在顶层取
const SCRIPT_SRC = (document.currentScript && document.currentScript.src) || '';

// ---------- 状态 ----------
const dom = { ready: false };
const S = { visible: false, armAt: 0, armTimer: 0, pending: null, waiting: false, spaceAt: -1e9, keysOn: false };

// ---------- 小工具 ----------
function nowMs() { return window.performance && performance.now ? performance.now() : Date.now(); }
function num(v, d) { return typeof v === 'number' && isFinite(v) ? v : d; }
function str(v) { return v == null ? '' : String(v); }

function mk(tag, cls, parent, text) {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (text != null) n.textContent = text;
  if (parent) parent.appendChild(n);
  return n;
}

// 结算按钮用 input 的轻点判定：死的时候玩家往往正按着摇杆，浏览器不合成 click；input 没载入时退回 click
function tap(el, fn) {
  if (BR.input && typeof BR.input.tap === 'function') BR.input.tap(el, fn);
  else el.addEventListener('click', fn);
}

function isTouch() {
  if (BR.input && typeof BR.input.isTouch === 'boolean') return BR.input.isTouch;
  try { return !!(window.matchMedia && window.matchMedia('(pointer: coarse)').matches); }
  catch (err) { return false; }
}

function pad2(n) { return (n < 10 ? '0' : '') + n; }
function fmtClock(sec) {
  const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60;
  return pad2(h) + ':' + pad2(m) + ':' + pad2(s);
}
// 屏幕阅读器念 "00:12:34" 不直观，另给一句人话
function fmtWords(sec) {
  const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60;
  return (h ? h + ' 小时 ' : '') + (h || m ? m + ' 分 ' : '') + s + ' 秒';
}

// 与 hud.js 同样的写法，结算和左上角显示的层级名保持一致
function levelLabel(id) {
  if (!id) return '未知层级';
  const def = BR.levels.get(id);
  const name = (def && def.name) || ('Level ' + id);
  return def && def.title ? name + ' · ' + def.title : name;
}

// 调用方给的 deepest 可能比当前层还浅（刚换层还没来得及更新），按 LEVEL_ORDER 取更深的；
// 不在顺序表里的（dev 层等）无法比较，照调用方给的显示
function deeperOf(cur, deepest) {
  if (!deepest) return cur;
  const order = BR.LEVEL_ORDER || [];
  const ic = order.indexOf(cur), id = order.indexOf(deepest);
  if (ic < 0 || id < 0) return deepest;
  return ic > id ? cur : deepest;
}

// ---------- DOM ----------
function ensureStylesheet() {
  const links = document.getElementsByTagName('link');
  for (let i = 0; i < links.length; i++) {
    if (/stylesheet/i.test(links[i].rel) && STYLE_RE.test(links[i].getAttribute('href') || '')) return;
  }
  // 和 hud.js 共用一份 css：谁先建 DOM 谁补 <link>，另一个检测到就不重复插
  const l = document.createElement('link');
  l.rel = 'stylesheet';
  l.href = SELF_RE.test(SCRIPT_SRC) ? SCRIPT_SRC.replace(SELF_RE, 'css/game.css') : 'css/game.css';
  l.setAttribute('data-owner', 'death');
  (document.head || document.documentElement).appendChild(l);
}

function host() { return document.getElementById('ui') || document.body; }

function buildStat(parent, label) {
  const row = mk('div', 'death-stat', parent);
  mk('dt', 'death-stat-label', row, label);
  return mk('dd', 'death-stat-val', row, '--');
}

function buildBtn(parent, cls, main, sub) {
  const b = mk('button', 'death-btn ' + cls, parent);
  b.type = 'button';
  mk('span', 'death-btn-main', b, main);
  if (sub) mk('span', 'death-btn-sub', b, sub);
  b.setAttribute('aria-label', sub ? main + '：' + sub : main);
  return b;
}

function build() {
  const root = dom.root = mk('div', 'death-root');
  root.hidden = true;
  root.setAttribute('role', 'dialog');
  root.setAttribute('aria-modal', 'true');
  root.setAttribute('aria-label', '死亡结算');

  // 左上角录像机 OSD，纯装饰
  const osd = mk('div', 'death-osd', root);
  osd.setAttribute('aria-hidden', 'true');
  mk('span', 'death-osd-stop', osd, '■ STOP');
  dom.osdTime = mk('span', 'death-osd-time', osd, '00:00:00');

  const panel = dom.panel = mk('div', 'death-panel', root);
  mk('div', 'death-tag', panel, 'SIGNAL LOST · 信号中断');
  mk('div', 'death-title', panel, '你死了');

  const cause = mk('div', 'death-cause', panel);
  mk('span', 'death-cause-label', cause, '死因');
  dom.cause = mk('span', 'death-cause-text', cause, '');

  const stats = mk('dl', 'death-stats', panel);
  dom.time = buildStat(stats, '存活时长');
  dom.level = buildStat(stats, '当前层级');
  dom.deepest = buildStat(stats, '到过的最深层级');

  const actions = mk('div', 'death-actions', panel);
  dom.btnContinue = buildBtn(actions, 'death-btn-continue', '继续', '原地重生，保留背包');
  dom.btnHome = buildBtn(actions, 'death-btn-home', '返回主页', '');
  dom.hint = mk('div', 'death-hint', panel, '按 Enter 继续');

  tap(dom.btnContinue, onContinue);
  tap(dom.btnHome, onHome);
}

// ---------- 联机开关麦 ----------
function micCoop() {
  const c = BR.coop;
  return c && c.active && typeof c.setMic === 'function' ? c : null;
}

// 联机时结算不停世界，死后常要喊队友，但结算层盖住了右上角的麦克风按钮：只在联机时创建，文案与 coop.js 一致
function syncMic() {
  if (!dom.ready) return;
  const c = micCoop();
  if (!c && !dom.mic) return;
  if (!dom.mic) {
    // 不带 death-btn 类：结算主按钮保持「继续」「返回主页」两个
    const b = dom.mic = mk('button', 'death-mic');
    b.type = 'button';
    mk('span', 'death-mic-ico', b, '🎙');
    dom.micTxt = mk('span', 'death-mic-txt', b, '');
    dom.panel.insertBefore(b, dom.hint);
    tap(b, onMic);
  }
  const on = !!(c && c.mic), busy = !!(c && c.micBusy);
  dom.mic.hidden = !c;
  dom.mic.classList.toggle('death-mic-on', on);
  dom.mic.classList.toggle('death-mic-busy', busy);
  dom.micTxt.textContent = busy ? '申请麦克风…' : on ? '开麦中' : '已闭麦';
  dom.mic.setAttribute('aria-pressed', on ? 'true' : 'false');
  dom.mic.setAttribute('aria-label', busy ? '正在申请麦克风，点击取消' : on ? '麦克风已打开，点击闭麦' : '麦克风已关闭，点击开麦');
}

function onMic(e) {
  // 和主按钮一样等 ARM_MS：死的那一下连点不能顺手把麦开了；空格点出来的也不认
  if (!S.visible || nowMs() < S.armAt || spaceClick(e)) return;
  const c = micCoop();
  if (!c) return;
  // 申请途中再点 = 取消，和 coop.js 的麦克风按钮一致
  const r = c.setMic(!(c.mic || c.micBusy));
  syncMic();
  if (r && typeof r.then === 'function') r.then(syncMic, syncMic);
}

function ensureDom() {
  if (!dom.ready) {
    if (!document.body) return false;
    ensureStylesheet();
    build();
    dom.ready = true;
    installKeys();
  }
  return true;
}

// ---------- 键盘：拦空格，只认 Enter ----------
function isSpaceKey(e) {
  return e.code === 'Space' || e.key === ' ' || e.key === 'Spacebar' || e.keyCode === 32;
}
function isEnterKey(e) {
  return e.key === 'Enter' || e.code === 'Enter' || e.code === 'NumpadEnter';
}

function isTyping(el) {
  if (!el || el.nodeType !== 1) return false;
  if (el.isContentEditable) return true;
  const tag = el.tagName;
  if (tag === 'TEXTAREA' || tag === 'SELECT') return true;
  if (tag !== 'INPUT') return false;
  return !/^(button|checkbox|radio|range|color|file|image|reset|submit)$/i.test(el.type || '');
}

// 键盘合成的 click（detail 为 0）紧跟在空格后面：是空格点出来的，不认。脚本 el.click() 也是 0，但不会刚按过空格
function spaceClick(e) {
  return !!e && e.type === 'click' && e.detail === 0 && nowMs() - S.spaceAt < SPACE_CLICK_MS;
}

function onKey(e) {
  if (!S.visible || isTyping(e.target)) return;
  if (isSpaceKey(e)) {
    S.spaceAt = nowMs();
    if (e.cancelable) e.preventDefault();
    return;
  }
  if (e.type !== 'keydown' || !isEnterKey(e) || e.repeat || e.ctrlKey || e.metaKey || e.altKey) return;
  // Enter 是真想点：它合成的 click 哪怕紧跟在空格后面也要认（2026-10-02 返修：空格松开 150 ms 内按 Enter，第一下被当成空格点的拦掉了）
  S.spaceAt = -1e9;
  // 焦点在结算里的按钮上：按钮自己合成 click，走 tap 的 click 分支
  const a = document.activeElement;
  if (a && a !== dom.root && dom.root.contains(a)) return;
  // 焦点丢了（点过面板空白处）或在结算外面：Enter 照样是「继续」，也不让外面拿着焦点的按钮被回车点到
  if (e.cancelable) e.preventDefault();
  onContinue();
}

function installKeys() {
  if (S.keysOn) return;
  S.keysOn = true;
  // 捕获阶段，赶在按钮自己处理之前；keypress 是老内核合成 click 的时机
  ['keydown', 'keypress', 'keyup'].forEach(n => document.addEventListener(n, onKey, true));
}

// ---------- 显示 / 收起 ----------
function arm() {
  if (!S.visible || !dom.ready) return;
  dom.root.classList.add('death-armed');
  // 桌面把焦点给「继续」，回车即可重生（按键也算用户手势，能锁指针）；触屏不给，免得出焦点框
  if (!isTouch() && typeof dom.btnContinue.focus === 'function') {
    try { dom.btnContinue.focus({ preventScroll: true }); } catch (err) { dom.btnContinue.focus(); }
  }
}

function show(info) {
  const d = info || {};
  if (!ensureDom()) {
    // 脚本放在 <head> 里、body 还没有时先记下，DOM 就绪再弹
    S.pending = d;
    if (!S.waiting) {
      S.waiting = true;
      document.addEventListener('DOMContentLoaded', () => {
        S.waiting = false;
        const p = S.pending;
        S.pending = null;
        if (p) show(p);
      }, { once: true });
    }
    return;
  }
  S.pending = null;

  const g = BR.game;
  const levelId = str(d.levelId) || str(g.levelId);
  const deepest = deeperOf(levelId, str(d.deepest) || str(g.deepest));
  const sec = Math.max(0, Math.floor(num(d.time, num(g.time, 0))));

  dom.cause.textContent = str(d.cause) || '未知原因';
  dom.time.textContent = fmtClock(sec);
  dom.time.setAttribute('aria-label', fmtWords(sec));
  dom.osdTime.textContent = fmtClock(sec);
  dom.level.textContent = levelLabel(levelId);
  dom.deepest.textContent = levelLabel(deepest);
  dom.hint.hidden = isTouch();
  syncMic();

  // 挪到 #ui 最后：和暂停菜单同为 z-index 60，后挂的盖在上面
  const h = host(), root = dom.root;
  if (root.parentNode !== h || h.lastChild !== root) h.appendChild(root);
  root.hidden = false;
  root.classList.remove('death-in', 'death-armed');
  void root.offsetWidth;   // 强制回流，连续两次 show 入场动画也能从头播
  root.classList.add('death-in');
  root.scrollTop = 0;
  S.visible = true;

  clearTimeout(S.armTimer);
  S.armAt = nowMs() + ARM_MS;
  S.armTimer = setTimeout(arm, ARM_MS);

  if (g.screen === 'playing' || g.screen === 'paused') g.screen = 'dead';
  if (BR.input) BR.input.enabled = false;
}

function hide() {
  clearTimeout(S.armTimer);
  S.pending = null;
  S.visible = false;
  if (!dom.ready) return;
  dom.root.hidden = true;
  dom.root.classList.remove('death-in', 'death-armed');
  const a = document.activeElement;
  if (a && dom.root.contains(a) && typeof a.blur === 'function') a.blur();
}

// 从结算回到游戏：收起，并把 show() 改过的 screen / 输入还原
function release() {
  hide();
  const g = BR.game;
  if (g.screen === 'dead') g.screen = 'playing';
  // 只在确实回到游玩画面时开输入：换层载入中等状态交给集成层
  if (BR.input && g.screen === 'playing') BR.input.enabled = true;
}

// ---------- 按钮 ----------
function onContinue(e) {
  if (!S.visible || nowMs() < S.armAt || spaceClick(e)) return;
  release();
  BR.bus.emit('death:continue');
  // 必须留在这次点击的同步调用栈里；触屏设备 input.lock 自己会跳过。监听方若改回主页就不锁
  const inp = BR.input;
  if (inp && typeof inp.lock === 'function' && BR.game.screen !== 'home') inp.lock();
}

function onHome(e) {
  if (!S.visible || nowMs() < S.armAt || spaceClick(e)) return;
  hide();
  BR.bus.emit('game:home');
}

// ---------- 事件 ----------
BR.bus.on('game:start', hide);
BR.bus.on('game:home', hide);
BR.bus.on('player:respawn', () => { if (S.visible) release(); });
// 麦克风状态变了（coop.js 发）；没有这个事件时，点击后等 setMic 的结果回来再刷新一次
BR.bus.on('coop:mic', () => { if (S.visible) syncMic(); });

// ---------- 导出 ----------
function init() {
  // 脚本放在 <head> 里时 body 还没有，等 DOM 就绪再建
  if (!ensureDom()) document.addEventListener('DOMContentLoaded', ensureDom, { once: true });
  return BR.death;
}

BR.death = {
  init, show, hide,
  get visible() { return S.visible; },
};
})();
